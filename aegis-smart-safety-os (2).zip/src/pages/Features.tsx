import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  ArrowLeft, Cpu, Radio, Shield, QrCode, Lock, Compass, MapPin, 
  AlertTriangle, Check, ArrowRight, Heart, Users
} from 'lucide-react';

export default function Features() {
  const { setPage, theme } = useApp();
  const isDark = theme === 'dark';

  const [activeFeature, setActiveFeature] = useState<string>('ai-risk');

  const technicalBreakdowns = {
    'ai-risk': {
      title: 'AI Travel Risk Scoring Model',
      description: 'Our heuristic threat engine analyzes situational parameters to predict emergency scenarios before they occur. It recalculates safety scores in real time based on active feeds.',
      points: [
        'Heuristic calculation of crime concentration metrics based on coordinate proximity.',
        'Continuous evaluation of meteorological threats and active civil hazards.',
        'Automatic path recommendation to steer tourists around active alert radii.',
        'Uses server-side Gemini models to generate contextual advice tailored to your coordinates.'
      ],
      icon: Cpu,
      color: 'text-blue-500',
      bg: 'bg-blue-600/10'
    },
    'geofencing': {
      title: 'Smart Spatial Geofencing',
      description: 'Perimeter monitoring algorithms establish continuous geofences around registered historical zones and high-hazard corridors.',
      points: [
        'Instant alerts dispatched when crossing out of approved Tourist Safe Zones.',
        'Automatic high-priority distress flags activated upon entering crime hotspots.',
        'Completely local GPS simulation to test and audit perimeter alarms before walking.',
        'No permanent logging of GPS tracks — calculations are run transiently in RAM.'
      ],
      icon: Radio,
      color: 'text-purple-500',
      bg: 'bg-purple-600/10'
    },
    'blockchain': {
      title: 'Decentralized Identity (DID) Ledger',
      description: 'Your physical passport details, national origins, and life-saving medical emergency data are sealed securely as decentralized credentials.',
      points: [
        'Self-sovereign digital wallet assigned to every registered tourist profile.',
        'Cryptographic hashes verify passport validity without revealing cleartext info.',
        'Medical emergency cards accessible securely by certified first responders during active SOS.',
        'Immutable audit logs register every security verification event on-chain.'
      ],
      icon: QrCode,
      color: 'text-pink-500',
      bg: 'bg-pink-600/10'
    }
  };

  const selected = technicalBreakdowns[activeFeature as keyof typeof technicalBreakdowns] || technicalBreakdowns['ai-risk'];
  const SelectedIcon = selected.icon;

  return (
    <div className={`min-h-screen py-16 px-6 transition-colors duration-300 ${isDark ? 'mesh-background text-white' : 'mesh-background-light text-slate-900'}`}>
      <div className="max-w-6xl mx-auto space-y-16">
        
        {/* Navigation back and header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-8">
          <button 
            onClick={() => setPage('landing')}
            className="inline-flex items-center space-x-2 text-sm font-semibold text-blue-500 hover:text-blue-400 cursor-pointer w-fit"
            id="back-to-home-btn"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Return Home</span>
          </button>
          
          <div className="flex items-center space-x-3 text-xs font-mono">
            <span className="opacity-50">API THREAT FEED:</span>
            <span className="h-2.5 w-2.5 bg-emerald-500 rounded-full animate-pulse"></span>
            <span className="font-extrabold text-emerald-400">SYNCED</span>
          </div>
        </div>

        {/* Hero Section */}
        <div className="space-y-6 max-w-3xl">
          <div className="bg-purple-600/10 text-purple-400 px-3 py-1 rounded-full text-xs font-bold w-fit border border-purple-500/20">
            SYSTEM CAPABILITIES
          </div>
          <h1 className="text-4xl md:text-5xl font-black tracking-tight leading-none">
            Deep-Tech Capabilities <br />
            <span className="text-gradient">For Maximum Security</span>
          </h1>
          <p className="text-slate-400 text-sm md:text-base leading-relaxed">
            Sentinel Tourist combines high-grade cryptography with smart telemetry to create a robust circle of safety around you. Explore the features that make our system the most advanced tourist protector on Earth.
          </p>
        </div>

        {/* Feature Interactive Tabbed Visualizer */}
        <div className="grid lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Feature Selector */}
          <div className="lg:col-span-4 space-y-3">
            {[
              { id: 'ai-risk', name: 'AI Safety Heuristics', desc: 'Predictive threat level modeler', icon: Cpu },
              { id: 'geofencing', name: 'Smart Spatial Geofencing', desc: 'Automated hazard boundaries', icon: Radio },
              { id: 'blockchain', name: 'Decentralized ID Ledger', desc: 'Cryptographic passport verification', icon: QrCode }
            ].map((f) => {
              const Icon = f.icon;
              const isSelected = activeFeature === f.id;
              return (
                <button
                  key={f.id}
                  onClick={() => setActiveFeature(f.id)}
                  className={`w-full text-left p-5 rounded-2xl border transition-all duration-200 cursor-pointer flex items-start space-x-4 ${
                    isSelected 
                      ? 'bg-blue-600 border-blue-500 text-white shadow-lg glow-blue' 
                      : isDark 
                        ? 'border-white/5 bg-slate-900/40 hover:bg-slate-900/60 text-slate-300' 
                        : 'border-slate-900/5 bg-white/50 hover:bg-white/80 text-slate-800'
                  }`}
                >
                  <div className={`p-2 rounded-xl ${isSelected ? 'bg-white/10 text-white' : 'bg-blue-500/10 text-blue-400'} shrink-0`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm tracking-wide">{f.name}</h3>
                    <p className={`text-[11px] mt-0.5 ${isSelected ? 'text-white/70' : 'text-slate-500'}`}>{f.desc}</p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Right Feature Details Display */}
          <div className={`lg:col-span-8 p-8 md:p-10 rounded-3xl border relative overflow-hidden ${isDark ? 'glass-card' : 'glass-card-light'}`}>
            <div className="absolute top-0 right-0 p-6 opacity-5">
              <SelectedIcon className="h-48 w-48" />
            </div>

            <div className="relative space-y-8">
              <div className="flex items-center space-x-4">
                <div className={`p-3.5 rounded-2xl ${selected.bg} ${selected.color} shrink-0`}>
                  <SelectedIcon className="h-7 w-7" />
                </div>
                <h2 className="text-2xl md:text-3xl font-black tracking-tight">{selected.title}</h2>
              </div>

              <p className={`text-sm leading-relaxed ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>
                {selected.description}
              </p>

              <div className="border-t border-white/5 pt-6 space-y-4">
                <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400">Technical Directives:</h4>
                <div className="grid sm:grid-cols-2 gap-4">
                  {selected.points.map((p, idx) => (
                    <div key={idx} className="flex items-start space-x-3 text-xs leading-relaxed">
                      <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span className={isDark ? 'text-slate-300' : 'text-slate-600'}>{p}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action buttons inside visualizer */}
              <div className="pt-6 border-t border-white/5 flex flex-wrap gap-4">
                <button 
                  onClick={() => setPage('register')}
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl transition-all glow-blue flex items-center space-x-2 cursor-pointer"
                >
                  <span>Verify My Identity Now</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
                <button 
                  onClick={() => setPage('services')}
                  className={`px-6 py-3 text-xs font-bold rounded-xl border transition-all cursor-pointer ${isDark ? 'border-white/10 hover:bg-white/5' : 'border-slate-900/10 hover:bg-slate-900/5'}`}
                >
                  Learn About Integrations
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Grid of Auxiliary Capabilities */}
        <div className="space-y-8 pt-8 border-t border-white/5">
          <h3 className="text-2xl font-black tracking-tight">Full System Interoperability</h3>
          
          <div className="grid md:grid-cols-4 gap-6">
            <div className={`p-6 rounded-2xl border ${isDark ? 'glass-card' : 'glass-card-light'}`}>
              <Lock className="h-5 w-5 text-blue-500 mb-3" />
              <h4 className="font-bold text-sm mb-1.5">End-to-End Encryption</h4>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                All data transmission between tourist devices and emergency responders is secured with AES-GCM 256-bit cryptography.
              </p>
            </div>

            <div className={`p-6 rounded-2xl border ${isDark ? 'glass-card' : 'glass-card-light'}`}>
              <Heart className="h-5 w-5 text-purple-500 mb-3" />
              <h4 className="font-bold text-sm mb-1.5">Medical Telemetry Logs</h4>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Stores emergency-specific vital information (blood type, diabetic status, severe allergies) directly attached to your QR signature.
              </p>
            </div>

            <div className={`p-6 rounded-2xl border ${isDark ? 'glass-card' : 'glass-card-light'}`}>
              <Compass className="h-5 w-5 text-pink-500 mb-3" />
              <h4 className="font-bold text-sm mb-1.5">Consulate Coordinates</h4>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Integrates embassy coordinates to dynamically highlight shelter sites during extreme civil emergencies.
              </p>
            </div>

            <div className={`p-6 rounded-2xl border ${isDark ? 'glass-card' : 'glass-card-light'}`}>
              <Users className="h-5 w-5 text-indigo-500 mb-3" />
              <h4 className="font-bold text-sm mb-1.5">Unified Alarm Dispatch</h4>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Triggers alarms simultaneously on the dashboard interfaces of municipal police forces, ambulances, and national consulates.
              </p>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className={`p-10 rounded-3xl border text-center space-y-6 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
          <h3 className="text-2xl font-black">Register in the Global Tourist Safe Zone</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
            Protect your next travel. Configure your digital ID, connect an emergency ledger pocket, and activate smart hazard spatial tracking.
          </p>
          <button 
            onClick={() => setPage('register')}
            className="px-8 py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition-all cursor-pointer inline-block glow-blue"
          >
            Issue My Digital ID
          </button>
        </div>

      </div>
    </div>
  );
}
