import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Shield, AlertTriangle, Check, Send, MapPin, PhoneCall, Radio, LogOut } from 'lucide-react';

export default function PoliceDashboard() {
  const { 
    user, sosAlerts, acceptSos, resolveSos, messages, sendSupportMsg, logout, theme 
  } = useApp();

  const isDark = theme === 'dark';
  const [selectedCaseId, setSelectedCaseId] = useState<string | null>(null);
  const [chatMessage, setChatMessage] = useState('');

  // Auto-select the first pending/accepted SOS case on mount
  useEffect(() => {
    const activeCases = sosAlerts.filter(s => s.status !== 'resolved');
    if (activeCases.length > 0 && !selectedCaseId) {
      setSelectedCaseId(activeCases[0].id);
    }
  }, [sosAlerts]);

  const activeCases = sosAlerts.filter(s => s.status !== 'resolved');
  const selectedCase = sosAlerts.find(s => s.id === selectedCaseId);

  // Send messaging text specifically to the active tourist
  const handleSendChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim() || !selectedCase) return;
    await sendSupportMsg(selectedCase.touristId, chatMessage);
    setChatMessage('');
  };

  // Filter messages specifically involving the selected tourist
  const activeTouristMsgs = messages.filter(
    m => selectedCase && (m.senderId === selectedCase.touristId || m.receiverId === selectedCase.touristId)
  );

  return (
    <div className={`min-h-screen flex flex-col md:flex-row transition-colors duration-300 ${isDark ? 'mesh-background text-white' : 'mesh-background-light text-slate-900'}`}>
      
      {/* Sidebar Controls */}
      <aside className={`w-full md:w-64 border-b md:border-b-0 md:border-r flex flex-col justify-between ${isDark ? 'glass border-white/10' : 'glass-light border-slate-900/10'}`}>
        <div>
          <div className="p-6 border-b border-white/5 flex items-center space-x-3">
            <div className="bg-blue-600 p-2 rounded-xl text-white">
              <Shield className="h-5 w-5" />
            </div>
            <div>
              <p className="font-extrabold text-sm tracking-tight text-gradient">AEGIS TOURIST</p>
              <span className="text-[9px] uppercase tracking-wider opacity-60">Police Dispatch</span>
            </div>
          </div>

          <div className="p-6 border-b border-white/5">
            <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Liaison Officer</p>
            <p className="text-sm font-extrabold mt-1 text-slate-200">{user?.name}</p>
            <span className="text-[10px] bg-blue-500/10 text-blue-400 px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider mt-2 inline-block">
              Precinct Unit
            </span>
          </div>

          <div className="p-4 space-y-2">
            <p className="text-[10px] text-slate-500 font-black uppercase tracking-wider px-2">Alarms List ({activeCases.length})</p>
            
            <div className="space-y-1">
              {activeCases.map(c => (
                <button
                  key={c.id}
                  onClick={() => setSelectedCaseId(c.id)}
                  className={`w-full text-left p-3 rounded-xl text-xs transition-all cursor-pointer ${selectedCaseId === c.id ? 'bg-blue-600 text-white font-extrabold glow-blue' : 'text-slate-400 hover:bg-white/5'}`}
                >
                  <div className="flex justify-between items-center mb-1">
                    <span className="truncate max-w-[120px]">{c.touristName}</span>
                    <span className={`text-[8px] uppercase px-1.5 py-0.5 rounded font-black ${c.status === 'pending' ? 'bg-red-500 text-white animate-pulse' : 'bg-emerald-500 text-slate-950'}`}>
                      {c.status}
                    </span>
                  </div>
                  <p className="text-[10px] font-mono opacity-80">{c.nationality}</p>
                </button>
              ))}

              {activeCases.length === 0 && (
                <p className="text-[10px] text-slate-500 p-2 text-center">No active panic alarms triggered.</p>
              )}
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-white/5">
          <button 
            onClick={logout}
            className="w-full flex items-center justify-center space-x-2 py-3 bg-red-950/20 border border-red-500/20 rounded-xl hover:bg-red-950/30 text-red-400 text-xs font-bold transition-all cursor-pointer"
          >
            <LogOut className="h-4 w-4" />
            <span>End Session</span>
          </button>
        </div>
      </aside>

      {/* Main Panel Content */}
      <main className="flex-1 flex flex-col overflow-y-auto p-8 space-y-8">
        
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-white/5 pb-6">
          <div>
            <h2 className="text-2xl font-black tracking-tight">Precinct Operations Center</h2>
            <p className="text-xs text-slate-400 mt-1">Receive spatial distress telemetry and deploy response units immediately.</p>
          </div>
        </header>

        {selectedCase ? (
          <div className="grid md:grid-cols-2 gap-8 items-start">
            
            {/* Case particulars card */}
            <div className={`p-8 rounded-3xl border space-y-6 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <span className="text-[10px] font-bold bg-red-500/10 text-red-400 px-2.5 py-1 rounded-full uppercase tracking-wider">
                    Distress Telemetry Locked
                  </span>
                  <h3 className="text-2xl font-black mt-2 text-slate-100">{selectedCase.touristName}</h3>
                  <p className="text-xs text-slate-400">Nationality: {selectedCase.nationality}</p>
                </div>

                <Radio className="h-6 w-6 text-red-500 animate-pulse glow-red" />
              </div>

              {/* Coordinates Map coordinates */}
              <div className="p-4 bg-white/5 rounded-2xl border border-white/5 font-mono text-xs text-slate-300 space-y-2">
                <p className="flex justify-between">
                  <span>LATITUDE:</span>
                  <span className="text-blue-400 font-bold">{selectedCase.lat.toFixed(5)}° N</span>
                </p>
                <p className="flex justify-between">
                  <span>LONGITUDE:</span>
                  <span className="text-blue-400 font-bold">{selectedCase.lng.toFixed(5)}° E</span>
                </p>
                <p className="text-xs mt-3 text-slate-400 font-sans border-t border-white/5 pt-2 italic">
                  Notes: "{selectedCase.notes}"
                </p>
              </div>

              {/* Emergency details */}
              <div className="grid sm:grid-cols-2 gap-4 text-xs">
                <div className="p-3 bg-red-500/5 border border-red-500/10 rounded-xl">
                  <span className="text-[9px] text-slate-400 font-bold uppercase block mb-1">Blood Type</span>
                  <p className="font-extrabold text-red-400 text-sm">{selectedCase.medicalInfo.bloodType}</p>
                </div>

                <div className="p-3 bg-white/5 border border-white/5 rounded-xl">
                  <span className="text-[9px] text-slate-400 font-bold uppercase block mb-1">Allergies/Conditions</span>
                  <p className="font-extrabold text-slate-200 text-xs truncate">
                    {selectedCase.medicalInfo.conditions.join(', ') || 'None Declared'}
                  </p>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex space-x-4 pt-4">
                {selectedCase.status === 'pending' ? (
                  <button 
                    onClick={() => acceptSos(selectedCase.id)}
                    className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow-lg glow-blue"
                  >
                    🚓 Dispatch Police Unit
                  </button>
                ) : (
                  <button 
                    onClick={() => resolveSos(selectedCase.id)}
                    className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow-lg glow-emerald"
                  >
                    ✅ Resolve Incident
                  </button>
                )}
              </div>
            </div>

            {/* Direct Officer-Tourist chat */}
            <div className={`p-8 rounded-3xl border flex flex-col justify-between min-h-[420px] ${isDark ? 'glass-card' : 'glass-card-light'}`}>
              <div className="border-b border-white/5 pb-4">
                <h4 className="font-extrabold text-sm uppercase tracking-wider text-purple-400">Live Secure Patrol Comms</h4>
                <p className="text-[10px] text-slate-400 mt-1">Direct end-to-end encrypted link with {selectedCase.touristName}.</p>
              </div>

              <div className="flex-1 overflow-y-auto space-y-4 max-h-[220px] py-4 pr-2">
                {activeTouristMsgs.map(m => (
                  <div key={m.id} className={`flex ${m.senderId === user?.id ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] p-3.5 rounded-2xl text-xs leading-relaxed ${m.senderId === user?.id ? 'bg-blue-600 text-white' : 'bg-white/5 border border-white/5 text-slate-200'}`}>
                      <p className="font-bold text-[8px] uppercase opacity-50 mb-1">{m.senderName}</p>
                      {m.message}
                    </div>
                  </div>
                ))}
                {activeTouristMsgs.length === 0 && (
                  <div className="text-center text-xs text-slate-500 py-12">
                    No active transmissions. Text the tourist above to coordinate search location.
                  </div>
                )}
              </div>

              <form onSubmit={handleSendChat} className="flex space-x-3 pt-4 border-t border-white/5">
                <input 
                  type="text"
                  required
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  className="flex-1 px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200"
                  placeholder="Send direct safety instructions..."
                />
                <button 
                  type="submit"
                  className="p-3.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl cursor-pointer"
                >
                  <Send className="h-4 w-4" />
                </button>
              </form>
            </div>

          </div>
        ) : (
          <div className="border border-dashed border-white/10 rounded-3xl p-16 text-center text-slate-500 text-sm flex flex-col justify-center items-center">
            <AlertTriangle className="h-10 w-10 text-slate-600 mb-3" />
            <p className="font-bold">Dispatch Ledger Idle</p>
            <p className="text-xs mt-1 max-w-sm">No active tourist panic alarms currently broadcasted in the precinct network.</p>
          </div>
        )}

      </main>
    </div>
  );
}
