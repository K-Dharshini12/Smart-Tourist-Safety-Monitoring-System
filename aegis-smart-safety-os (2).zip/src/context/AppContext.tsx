import React, { createContext, useContext, useState, useEffect } from 'react';

export type Role = 'tourist' | 'admin' | 'police' | 'hospital' | 'embassy';

export interface User {
  id: string;
  email: string;
  role: Role;
  name: string;
  phone: string;
  walletAddress?: string;
  nationality?: string;
  passportNumber?: string;
}

export interface Tourist {
  userId: string;
  currentLat: number;
  currentLng: number;
  riskScore: number;
  riskStatus: 'Safe' | 'Moderate' | 'High';
  safeZoneId: string | null;
  digitalId: string;
  verificationQr: string;
  blockchainWallet: string;
  status: 'active' | 'in_emergency' | 'offline';
  nationality: string;
  passportNumber: string;
  medicalConditions: string[];
  bloodType: string;
  emergencyContactName: string;
  emergencyContactPhone: string;
  embassyContact: string;
}

export interface Alert {
  id: string;
  type: 'weather' | 'crime' | 'hazard' | 'info';
  title: string;
  description: string;
  severity: 'low' | 'medium' | 'high';
  lat: number;
  lng: number;
  radius: number;
  active: boolean;
  createdAt: string;
}

export interface SOSAlert {
  id: string;
  touristId: string;
  touristName: string;
  nationality: string;
  lat: number;
  lng: number;
  status: 'pending' | 'accepted' | 'resolved';
  acceptedBy: { id: string; role: 'police' | 'hospital'; name: string } | null;
  medicalInfo: {
    bloodType: string;
    conditions: string[];
  };
  notes: string;
  createdAt: string;
}

export interface SafeZone {
  id: string;
  name: string;
  description: string;
  type: 'safe' | 'danger';
  lat: number;
  lng: number;
  radius: number;
}

export interface BlockchainRecord {
  txHash: string;
  blockNumber: number;
  timestamp: string;
  type: 'ID_CREATION' | 'IDENTITY_VERIFICATION' | 'SOS_LOG' | 'SECURITY_ALERT';
  details: string;
  walletAddress: string;
}

export interface SupportMessage {
  id: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  message: string;
  createdAt: string;
  read: boolean;
}

export interface ServiceEntity {
  id: string;
  name: string;
  type: 'police' | 'hospital' | 'embassy';
  phone: string;
  address: string;
  lat: number;
  lng: number;
  details?: string;
}

interface AppContextType {
  token: string | null;
  user: User | null;
  tourist: Tourist | null;
  activePage: string;
  activeTab: string; // Dashboard tab
  alerts: Alert[];
  sosAlerts: SOSAlert[];
  safeZones: SafeZone[];
  ledger: BlockchainRecord[];
  messages: SupportMessage[];
  services: ServiceEntity[];
  currentGps: { lat: number; lng: number };
  gpsZoneName: string;
  gpsDangerZoneName: string | null;
  isSimulatingGps: boolean;
  theme: 'light' | 'dark';
  
  // Actions
  login: (email: string, pass: string) => Promise<boolean>;
  register: (data: any) => Promise<boolean>;
  logout: () => void;
  setPage: (page: string) => void;
  setTab: (tab: string) => void;
  triggerSos: (notes?: string) => Promise<void>;
  acceptSos: (sosId: string) => Promise<void>;
  resolveSos: (sosId: string) => Promise<void>;
  sendSupportMsg: (receiverId: string, text: string) => Promise<void>;
  updateGps: (lat: number, lng: number) => Promise<void>;
  createGeofence: (zone: any) => Promise<void>;
  createAlert: (alert: any) => Promise<void>;
  verifyQR: (qrCode: string) => Promise<any>;
  toggleTheme: () => void;
  refreshData: () => Promise<void>;
  setGpsSimulation: (active: boolean) => void;
  resetPassword: (email: string) => Promise<string>;
  completeReset: (email: string, otp: string, pass: string) => Promise<void>;
  updateProfile: (profileData: any) => Promise<boolean>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [token, setToken] = useState<string | null>(localStorage.getItem('safety_jwt'));
  const [user, setUser] = useState<User | null>(null);
  const [tourist, setTourist] = useState<Tourist | null>(null);
  const [activePage, setActivePage] = useState<string>('landing');
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [sosAlerts, setSosAlerts] = useState<SOSAlert[]>([]);
  const [safeZones, setSafeZones] = useState<SafeZone[]>([]);
  const [ledger, setLedger] = useState<BlockchainRecord[]>([]);
  const [messages, setMessages] = useState<SupportMessage[]>([]);
  const [services, setServices] = useState<ServiceEntity[]>([]);
  const [currentGps, setCurrentGps] = useState({ lat: 48.8566, lng: 2.3522 });
  const [gpsZoneName, setGpsZoneName] = useState('Champs-Élysées Tourist Safe Zone');
  const [gpsDangerZoneName, setGpsDangerZoneName] = useState<string | null>(null);
  const [isSimulatingGps, setIsSimulatingGps] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>('dark');

  const headers = token ? { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' } : { 'Content-Type': 'application/json' };

  // Fetch critical system resources on load/auth change
  useEffect(() => {
    if (token) {
      fetchProfile();
      refreshData();
    } else {
      setUser(null);
      setTourist(null);
    }
  }, [token]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  const fetchProfile = async () => {
    try {
      const res = await fetch('/api/auth/me', { headers: { 'Authorization': `Bearer ${token}` } });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        if (data.tourist) {
          setTourist(data.tourist);
          setCurrentGps({ lat: data.tourist.currentLat, lng: data.tourist.currentLng });
        }
      } else {
        logout();
      }
    } catch (e) {
      console.error('Failed to fetch user profile', e);
    }
  };

  const refreshData = async () => {
    if (!token) return;
    const authHeaders = { 'Authorization': `Bearer ${token}` };
    try {
      const [zonesRes, alertsRes, servicesRes, ledgerRes, msgRes, sosRes] = await Promise.all([
        fetch('/api/geofencing/zones', { headers: authHeaders }),
        fetch('/api/safety/alerts', { headers: authHeaders }),
        fetch('/api/services/entities', { headers: authHeaders }),
        fetch('/api/blockchain/ledger', { headers: authHeaders }),
        fetch('/api/messages', { headers: authHeaders }),
        fetch('/api/sos/active', { headers: authHeaders })
      ]);

      if (zonesRes.ok) setSafeZones(await zonesRes.json());
      if (alertsRes.ok) setAlerts(await alertsRes.json());
      if (servicesRes.ok) setServices(await servicesRes.json());
      if (ledgerRes.ok) setLedger(await ledgerRes.json());
      if (msgRes.ok) setMessages(await msgRes.json());
      if (sosRes.ok) setSosAlerts(await sosRes.json());
    } catch (e) {
      console.error('Error synchronizing database metrics', e);
    }
  };

  const login = async (email: string, pass: string): Promise<boolean> => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password: pass })
      });
      if (res.ok) {
        const data = await res.json();
        localStorage.setItem('safety_jwt', data.token);
        setToken(data.token);
        // Set dynamic routing based on logged-in role
        setActiveTab('overview');
        setActivePage('dashboard');
        return true;
      }
      return false;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  const register = async (regData: any): Promise<boolean> => {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(regData)
      });
      if (res.ok) {
        const data = await res.json();
        localStorage.setItem('safety_jwt', data.token);
        setToken(data.token);
        setActivePage('dashboard');
        setActiveTab('overview');
        return true;
      }
      return false;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  const resetPassword = async (email: string): Promise<string> => {
    const res = await fetch('/api/auth/forgot-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email })
    });
    if (!res.ok) throw new Error('Error triggering password reset');
    const data = await res.json();
    return data.otp;
  };

  const completeReset = async (email: string, otp: string, pass: string): Promise<void> => {
    const res = await fetch('/api/auth/reset-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, otp, newPassword: pass })
    });
    if (!res.ok) throw new Error('Password reset validation failed');
  };

  const updateProfile = async (profileData: any): Promise<boolean> => {
    try {
      const res = await fetch('/api/auth/profile', {
        method: 'PUT',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(profileData)
      });
      if (res.ok) {
        await fetchProfile();
        await refreshData();
        return true;
      }
      return false;
    } catch (e) {
      console.error('Error updating user profile:', e);
      return false;
    }
  };

  const logout = () => {
    localStorage.removeItem('safety_jwt');
    setToken(null);
    setUser(null);
    setTourist(null);
    setActivePage('landing');
  };

  const setPage = (pageName: string) => {
    setActivePage(pageName);
  };

  const setTab = (tabName: string) => {
    setActiveTab(tabName);
  };

  const triggerSos = async (notes?: string) => {
    try {
      const res = await fetch('/api/sos/trigger', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ notes, lat: currentGps.lat, lng: currentGps.lng })
      });
      if (res.ok) {
        await refreshData();
        await fetchProfile();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const acceptSos = async (sosId: string) => {
    try {
      const res = await fetch(`/api/sos/${sosId}/accept`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        await refreshData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const resolveSos = async (sosId: string) => {
    try {
      const res = await fetch(`/api/sos/${sosId}/resolve`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        await refreshData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const sendSupportMsg = async (receiverId: string, text: string) => {
    try {
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ receiverId, message: text })
      });
      if (res.ok) {
        await refreshData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const updateGps = async (lat: number, lng: number) => {
    setCurrentGps({ lat, lng });
    if (!token || user?.role !== 'tourist') return;
    try {
      const res = await fetch('/api/telemetry/location', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ lat, lng })
      });
      if (res.ok) {
        const data = await res.json();
        setGpsZoneName(data.currentZone);
        setGpsDangerZoneName(data.breachedDangerZone);
        await refreshData();
        await fetchProfile();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const createGeofence = async (zone: any) => {
    try {
      const res = await fetch('/api/geofencing/zones', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(zone)
      });
      if (res.ok) {
        await refreshData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const createAlert = async (alert: any) => {
    try {
      const res = await fetch('/api/safety/alerts', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(alert)
      });
      if (res.ok) {
        await refreshData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const verifyQR = async (qrCode: string): Promise<any> => {
    try {
      const res = await fetch('/api/blockchain/verify-id', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ qrCodeText: qrCode })
      });
      if (res.ok) {
        const result = await res.json();
        await refreshData();
        return result;
      }
      throw new Error('Verification request rejected.');
    } catch (e: any) {
      throw new Error(e.message || 'Verification failed.');
    }
  };

  const setGpsSimulation = (active: boolean) => {
    setIsSimulatingGps(active);
  };

  return (
    <AppContext.Provider value={{
      token, user, tourist, activePage, activeTab, alerts, sosAlerts, safeZones, ledger, messages, services, currentGps, gpsZoneName, gpsDangerZoneName, isSimulatingGps, theme,
      login, register, logout, setPage, setTab, triggerSos, acceptSos, resolveSos, sendSupportMsg, updateGps, createGeofence, createAlert, verifyQR, toggleTheme, refreshData, setGpsSimulation,
      resetPassword, completeReset, updateProfile
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
