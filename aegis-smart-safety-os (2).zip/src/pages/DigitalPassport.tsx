import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { 
  ArrowLeft, QrCode, Lock, Shield, Check, Activity, Database, 
  Sparkles, RefreshCw, AlertTriangle, Fingerprint, Star, Link, Eye
} from 'lucide-react';

export default function DigitalPassport() {
  const { setPage, theme, user } = useApp();
  const isDark = theme === 'dark';

  const [isCardFlipped, setIsCardFlipped] = useState(false);
  const [isSyncingLedger, setIsSyncingLedger] = useState(false);
  const [syncStatus, setSyncStatus] = useState<'idle' | 'hashing' | 'broadcasting' | 'sealed'>('idle');
  const [syncedBlocks, setSyncedBlocks] = useState<Array<{ id: string; txHash: string; block: number; label: string; date: string }>>([
    { id: '1', txHash: '0x3a19...e882', block: 15438318, label: 'Sovereign DID Created', date: 'Jul 10, 2026' },
    { id: '2', txHash: '0xec28...12bc', block: 15438320, label: 'Consulate Verified Signature', date: 'Jul 11, 2026' }
  ]);

  const handleSealPassportOnChain = () => {
    if (isSyncingLedger) return;
    setIsSyncingLedger(true);
    setSyncStatus('hashing');

    setTimeout(() => {
      setSyncStatus('broadcasting');
      setTimeout(() => {
        const newBlockNum = syncedBlocks[syncedBlocks.length - 1].block + 1;
        const newBlock = {
          id: Date.now().toString(),
          txHash: `0x${Math.random().toString(16).substr(2, 4)}...${Math.random().toString(16).substr(2, 4)}`.toUpperCase(),
          block: newBlockNum,
          label: 'Cryptographic Biometric Seal Approved',
          date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
        };
        setSyncedBlocks(prev => [...prev, newBlock]);
        setSyncStatus('sealed');
        setIsSyncingLedger(false);
      }, 1200);
    }, 1000);
  };

  return (
    <div className="min-h-screen pb-20 pt-6 px-4 sm:px-6 relative">
      
      {/* Inline styles for 3D card flip effects, blockchain connectors, and scanning lasers */}
      <style>{`
        .perspective-container {
          perspective: 1200px;
        }
        .preserve-3d {
          transform-style: preserve-3d;
          transition: transform 0.6s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .backface-hidden {
          backface-visibility: hidden;
        }
        .rotate-y-180 {
          transform: rotateY(180deg);
        }
        
        /* Scanning Laser Line effect */
        @keyframes laserScan {
          0% { top: 0%; opacity: 0.8; }
          50% { top: 100%; opacity: 0.8; }
          100% { top: 0%; opacity: 0.8; }
        }
        .laser-line {
          position: absolute;
          left: 0;
          right: 0;
          height: 3px;
          background: #ec4899;
          box-shadow: 0 0 10px #ec4899;
          animation: laserScan 2.5s infinite linear;
        }
        
        /* Blockchain connector line pulse */
        @keyframes linePulse {
          0% { stroke-dashoffset: 24; }
          100% { stroke-dashoffset: 0; }
        }
        .line-pulse-path {
          stroke-dasharray: 8;
          animation: linePulse 1.2s infinite linear;
        }
      `}</style>

      <div className="max-w-7xl mx-auto space-y-10">
        
        {/* Title */}
        <div className="text-left space-y-2">
          <div className="bg-pink-600/10 text-pink-400 px-3.5 py-1.5 rounded-full text-xs font-mono tracking-wider font-extrabold w-fit border border-pink-500/20">
            SOVEREIGN BLOCK ID
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight">
            Sovereign DID & <span className="text-gradient">Digital Passport</span>
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm max-w-2xl leading-relaxed">
            Protect your biometric credentials, national passport records, and medical allergies on-chain. Synchronize details immutably to grant verified emergency authorities instant medical pre-clearance.
          </p>
        </div>

        {/* Content columns */}
        <div className="grid lg:grid-cols-12 gap-8 items-center">
          
          {/* Column A: Interactive 3D Passport (5 Columns) */}
          <div className="lg:col-span-5 flex flex-col items-center space-y-5">
            
            <div className="text-left w-full max-w-[340px]">
              <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest block mb-1">Click card to rotate 3D viewport:</span>
            </div>

            {/* 3D Flippable card frame */}
            <div 
              onClick={() => setIsCardFlipped(!isCardFlipped)}
              className="w-full max-w-[340px] h-[460px] perspective-container cursor-pointer group"
            >
              <div className={`relative w-full h-full preserve-3d ${isCardFlipped ? 'rotate-y-180' : ''}`}>
                
                {/* CARD SIDE 1: FRONT PASSPORT COVER */}
                <div className="absolute inset-0 backface-hidden bg-gradient-to-tr from-slate-950 via-slate-900 to-slate-950 border-2 border-white/15 rounded-[24px] p-6 flex flex-col justify-between shadow-2xl overflow-hidden text-left">
                  
                  {/* Decorative glowing background gradients */}
                  <div className="absolute inset-0 bg-radial-gradient from-blue-500/5 to-transparent pointer-events-none"></div>

                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <div className="flex items-center space-x-1.5">
                        <Fingerprint className="h-4 w-4 text-blue-500" />
                        <span className="text-[9px] font-mono font-black tracking-widest text-blue-400 uppercase">AEGIS OS</span>
                      </div>
                      <h3 className="font-extrabold text-xs text-white">SOVEREIGN TOURIST PASSPORT</h3>
                    </div>
                    <Lock className="h-5 w-5 text-pink-500" />
                  </div>

                  {/* QR Core area with laser scanning vertical line */}
                  <div className="flex flex-col items-center text-center space-y-4 my-auto relative">
                    <div className="h-36 w-36 bg-slate-950 border-2 border-white/10 rounded-2xl p-3 flex items-center justify-center relative shadow-inner overflow-hidden group-hover:border-pink-500/30 transition-colors">
                      <QrCode className="h-full w-full text-white" />
                      
                      {/* Live scanning bar during ledger sync */}
                      {isSyncingLedger && <div className="laser-line"></div>}
                      
                      <div className="absolute top-1.5 right-1.5 h-2.5 w-2.5 bg-emerald-500 rounded-full animate-pulse"></div>
                    </div>
                    
                    <div className="space-y-1">
                      <span className="inline-flex items-center space-x-1 text-[9px] bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 px-2 py-0.5 rounded-full font-bold">
                        <Star className="h-2.5 w-2.5 fill-current" />
                        <span>CRYPTOGRAPHICALLY SEALED</span>
                      </span>
                      <p className="text-[10px] font-mono text-slate-400 mt-1">Sovereign Key: 0x8A92...EF48</p>
                    </div>
                  </div>

                  {/* Passport lower section metadata */}
                  <div className="flex justify-between items-end border-t border-white/5 pt-4">
                    <div>
                      <p className="text-[8px] text-slate-500 uppercase font-black tracking-wider">Verified Holder</p>
                      <p className="text-xs font-black text-slate-300">{user?.name || 'Sovereign Tourist'}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[8px] text-slate-500 uppercase font-black tracking-wider">Consular Class</p>
                      <p className="text-xs font-black text-emerald-400">AAA Security</p>
                    </div>
                  </div>

                </div>

                {/* CARD SIDE 2: BACK PASSPORT SPECIFICS */}
                <div className="absolute inset-0 backface-hidden rotate-y-180 bg-gradient-to-tr from-slate-900 via-indigo-950 to-slate-900 border-2 border-white/15 rounded-[24px] p-6 flex flex-col justify-between shadow-2xl overflow-hidden text-left">
                  
                  <div className="flex justify-between items-center border-b border-white/5 pb-3">
                    <span className="text-[9px] font-mono font-black text-pink-400 uppercase tracking-widest">Medical Emergency Telemetry</span>
                    <Activity className="h-4 w-4 text-pink-500 animate-pulse" />
                  </div>

                  {/* Medical particulars details */}
                  <div className="space-y-4 my-auto">
                    <div className="grid grid-cols-2 gap-4 text-xs">
                      <div>
                        <p className="text-[8px] text-slate-500 uppercase font-black">Full Name</p>
                        <p className="font-extrabold text-white">{user?.name || 'Jane Doe'}</p>
                      </div>
                      <div>
                        <p className="text-[8px] text-slate-500 uppercase font-black">Consulate Origin</p>
                        <p className="font-extrabold text-white">United Kingdom</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-xs">
                      <div>
                        <p className="text-[8px] text-slate-500 uppercase font-black">Biometric Blood</p>
                        <p className="font-extrabold text-rose-400">O-Positive (O+)</p>
                      </div>
                      <div>
                        <p className="text-[8px] text-slate-500 uppercase font-black">Passport Number</p>
                        <p className="font-extrabold text-white">UK-4893921</p>
                      </div>
                    </div>

                    {/* Allergies and pre-authorizations */}
                    <div className="space-y-1.5 bg-white/5 p-3.5 rounded-xl border border-white/5 text-[10px]">
                      <p className="text-[8px] uppercase font-black text-slate-400">Pre-authorized Medical Indices:</p>
                      <p className="text-slate-300 font-semibold">• Penicillin Allergy (Critical)</p>
                      <p className="text-slate-300 font-semibold">• Gluten Intolerance</p>
                    </div>
                  </div>

                  {/* Footing detail */}
                  <div className="border-t border-white/5 pt-3 flex items-center justify-between text-[8px] font-mono text-slate-500 font-bold">
                    <span>SECURITY SEAL #4982</span>
                    <span className="text-pink-400">TAP TO ROTATE</span>
                  </div>

                </div>

              </div>
            </div>

            <div className="inline-flex items-center space-x-1 bg-blue-500/10 px-3 py-1 rounded-full text-[9px] text-blue-400 font-mono font-bold">
              <Eye className="h-3 w-3" />
              <span>Click Card to View Biometrics details</span>
            </div>

          </div>

          {/* Column B: Blockchain Ledger syncing system (7 Columns) */}
          <div className="lg:col-span-7 space-y-6">
            
            <div className={`p-6 rounded-[24px] border text-left space-y-5 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
              
              <div className="flex justify-between items-center border-b border-white/5 pb-3">
                <div className="space-y-0.5">
                  <h3 className="font-black text-sm uppercase text-white tracking-wider">Immutable Sovereign Ledger</h3>
                  <p className="text-slate-500 text-[9px] uppercase">Cryptographic decentralized database logs</p>
                </div>
                <Database className="h-5 w-5 text-blue-500 animate-pulse" />
              </div>

              {/* Dynamic connected blocks list */}
              <div className="space-y-3 relative">
                
                {/* SVG Connecting glowing line */}
                <div className="absolute left-[20px] top-[40px] bottom-[40px] w-[2px] bg-blue-500/20 pointer-events-none"></div>

                {syncedBlocks.map((blk, idx) => (
                  <div 
                    key={blk.id}
                    className="p-4 bg-slate-950/60 rounded-xl border border-white/10 flex items-center justify-between relative overflow-hidden"
                  >
                    {/* Glowing vertical side-bar tag */}
                    <div className="absolute left-0 top-0 bottom-0 w-1 bg-pink-500"></div>

                    <div className="flex items-center space-x-3.5 pl-2 text-left">
                      <div className="h-8 w-8 rounded-lg bg-pink-500/10 text-pink-400 border border-pink-500/20 flex items-center justify-center font-mono text-xs font-black">
                        #{idx + 1}
                      </div>
                      <div>
                        <h4 className="text-xs font-extrabold text-white">{blk.label}</h4>
                        <p className="text-[9px] font-mono text-slate-500">Block height: {blk.block} • timestamp {blk.date}</p>
                      </div>
                    </div>

                    <div className="text-right text-[10px] font-mono">
                      <p className="text-pink-400 font-bold uppercase">{blk.txHash}</p>
                      <span className="text-[8px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 px-2 py-0.5 rounded-full font-bold">VERIFIED SEAL</span>
                    </div>
                  </div>
                ))}

                {/* Loading transaction synchronization animation */}
                {isSyncingLedger && (
                  <div className="p-4 border-2 border-dashed border-pink-500/20 bg-pink-500/5 rounded-xl flex items-center justify-center space-x-3 text-pink-400 animate-pulse text-left">
                    <RefreshCw className="h-4 w-4 animate-spin text-pink-500" />
                    <div>
                      <span className="text-xs font-bold uppercase tracking-wider block">
                        {syncStatus === 'hashing' ? 'SHIELD-HASH: Compiling medical allergy arrays...' : 'LEDGER-SYNC: Broadcating immutable transaction proof...'}
                      </span>
                      <span className="text-[9px] font-mono text-slate-500">Node sync: {"Local Express -> MongoDB ledger model"}</span>
                    </div>
                  </div>
                )}

              </div>

              {/* Sealing Action Block */}
              <div className="bg-slate-950/40 p-5 rounded-2xl border border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-left">
                <div className="space-y-1">
                  <h4 className="text-xs font-black text-white flex items-center space-x-1.5 uppercase">
                    <Sparkles className="h-3.5 w-3.5 text-pink-500 animate-bounce" />
                    <span>Seal sovereign identity</span>
                  </h4>
                  <p className="text-[10px] text-slate-500">Lock your medical telemetry and passport details on the immutable blockchain grid.</p>
                </div>

                <button 
                  onClick={handleSealPassportOnChain}
                  disabled={isSyncingLedger}
                  className="px-6 py-3 bg-pink-600 hover:bg-pink-500 text-white text-xs font-black rounded-xl transition-all uppercase cursor-pointer shadow-xl hover:shadow-pink-500/25 disabled:bg-slate-800 disabled:text-slate-500"
                >
                  {isSyncingLedger ? 'Processing...' : 'Seal On Ledger'}
                </button>
              </div>

            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
