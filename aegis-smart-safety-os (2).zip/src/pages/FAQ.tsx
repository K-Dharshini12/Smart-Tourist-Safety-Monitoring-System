import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ArrowLeft, HelpCircle, ChevronDown, ChevronUp } from 'lucide-react';

export default function FAQ() {
  const { setPage, theme } = useApp();
  const isDark = theme === 'dark';

  const faqItems = [
    {
      q: 'What is a Blockchain Digital Tourist ID?',
      a: 'It is a cryptographic digital representation of your passport details, blood type, and embassy contact, permanently sealed and hashed onto a secure distributed ledger. It allows border agents and medical responders to verify your credentials instantly via QR scan without exposing physical documents.'
    },
    {
      q: 'How does the Geofencing automatic safety warning work?',
      a: 'Our systems monitor your live GPS coordinates. If you depart a certified Safe Zone (e.g., historical landmark perimeters) or enter a designated Danger Zone (e.g., active high-crime alleys), the backend automatic monitoring engine broadcasts warning messages directly into your notification feed.'
    },
    {
      q: 'What happens when I press the SOS Panic Button?',
      a: 'When activated, your exact location coordinates are locked and transmitted along with your blood type, medical conditions, and emergency passport information directly onto the operational command panels of the local Police, closest Trauma Hospital, and your National Embassy.'
    },
    {
      q: 'How is my private location tracking protected?',
      a: 'Your location coordinates are stored transiently in RAM to compute geofence entry and risk scoring. These are never stored permanently unless you trigger an SOS. If you activate SOS, the coordinates are logged immutably onto the ledger as emergency proof for search and rescue operations.'
    },
    {
      q: 'Is this system compatible with physical wallets?',
      a: 'Yes, your Digital ID can be linked directly with digital blockchain wallets (e.g., MetaMask, WalletConnect). Responders verify your profile through secure, key-signed authentication without requiring standard passwords.'
    }
  ];

  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className={`min-h-screen py-16 px-6 ${isDark ? 'mesh-background text-white' : 'mesh-background-light text-slate-900'}`}>
      <div className="max-w-4xl mx-auto space-y-12">
        <button 
          onClick={() => setPage('landing')}
          className="inline-flex items-center space-x-2 text-sm font-semibold text-blue-500 hover:text-blue-400 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Return Home</span>
        </button>

        <div className="space-y-4">
          <HelpCircle className="h-10 w-10 text-blue-500" />
          <h2 className="text-3xl md:text-5xl font-black tracking-tight">Security Protocol FAQ</h2>
          <p className="text-slate-400 text-sm max-w-2xl leading-relaxed">
            Got questions about how Sentinel protect lives? Learn more about our cryptographic systems, geofence definitions, and emergency dispatch routines.
          </p>
        </div>

        <div className="space-y-4 pt-4">
          {faqItems.map((item, index) => {
            const isOpen = openIndex === index;
            return (
              <div 
                key={index}
                className={`border rounded-2xl overflow-hidden transition-all duration-200 ${isDark ? 'border-white/5 bg-slate-900/40' : 'border-slate-900/5 bg-white/50'}`}
              >
                <button
                  onClick={() => toggleFaq(index)}
                  className="w-full px-6 py-5 flex items-center justify-between text-left font-bold text-sm md:text-base cursor-pointer hover:bg-white/5"
                >
                  <span>{item.q}</span>
                  {isOpen ? <ChevronUp className="h-5 w-5 text-blue-500" /> : <ChevronDown className="h-5 w-5 text-slate-400" />}
                </button>
                {isOpen && (
                  <div className={`px-6 pb-6 pt-1 text-xs md:text-sm leading-relaxed ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                    {item.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
