import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Shield, MapPin, AlertTriangle, Heart, UserCheck, QrCode, Wallet, 
  MessageSquare, Send, Compass, Cloud, Navigation, HelpCircle, Activity,
  PhoneCall, Map, RefreshCw, FileText, Settings, LogOut, Check,
  Bell, TrendingUp, Fingerprint, AlertOctagon, User, Cpu, Sliders, HardDrive, Edit2
} from 'lucide-react';

export default function TouristDashboard() {
  const { 
    user, tourist, activeTab, setTab, logout, currentGps, gpsZoneName, 
    gpsDangerZoneName, updateGps, triggerSos, sosAlerts, safeZones, 
    alerts, services, messages, sendSupportMsg, theme, updateProfile
  } = useApp();

  const isDark = theme === 'dark';

  // Emergency SOS state
  const [isSosAlertOpen, setIsSosAlertOpen] = useState(false);
  const [sosLocationUsed, setSosLocationUsed] = useState<{ lat: number, lng: number } | null>(null);

  const handleSosPress = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          setSosLocationUsed({ lat, lng });
          triggerSos(`Sovereign Portal PANIC Broadcaster. GPS coordinates captured: LAT: ${lat.toFixed(5)}, LNG: ${lng.toFixed(5)}`);
          setIsSosAlertOpen(true);
        },
        () => {
          const lat = currentGps?.lat || 48.8566;
          const lng = currentGps?.lng || 2.3522;
          setSosLocationUsed({ lat, lng });
          triggerSos(`Sovereign Portal PANIC Broadcaster. Active Simulated Telemetry: LAT: ${lat.toFixed(5)}, LNG: ${lng.toFixed(5)}`);
          setIsSosAlertOpen(true);
        }
      );
    } else {
      const lat = currentGps?.lat || 48.8566;
      const lng = currentGps?.lng || 2.3522;
      setSosLocationUsed({ lat, lng });
      triggerSos(`Sovereign Portal PANIC Broadcaster. Active Simulated Telemetry: LAT: ${lat.toFixed(5)}, LNG: ${lng.toFixed(5)}`);
      setIsSosAlertOpen(true);
    }
  };

  // AI Route planning state
  const [routeOrigin, setRouteOrigin] = useState('Eiffel Tower');
  const [routeDest, setRouteDest] = useState('Louvre Museum');
  const [routeAdvice, setRouteAdvice] = useState<any>(null);
  const [loadingRoute, setLoadingRoute] = useState(false);

  // Chatbot Assistant state
  const [chatbotMessage, setChatbotMessage] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{ role: 'user' | 'model', text: string }>>([
    { role: 'model', text: 'Hello! I am your AI Safety Travel Companion. I monitor weather, crime maps, and geofences in real time. Ask me anything about Paris travel safety.' }
  ]);
  const [loadingChat, setLoadingChat] = useState(false);

  // Manual GPS Input state
  const [customLat, setCustomLat] = useState('48.8566');
  const [customLng, setCustomLng] = useState('2.3522');

  // Support Agent chat state
  const [supportText, setSupportText] = useState('');

  // AI Risk Score detailed analysis
  const [aiRiskReport, setAiRiskReport] = useState<any>(null);
  const [loadingRiskReport, setLoadingRiskReport] = useState(false);

  // Profile Edit Form States
  const [profileName, setProfileName] = useState(user?.name || '');
  const [profilePhone, setProfilePhone] = useState(user?.phone || '');
  const [profileNationality, setProfileNationality] = useState(tourist?.nationality || '');
  const [profilePassport, setProfilePassport] = useState(tourist?.passportNumber || '');
  const [profileBloodType, setProfileBloodType] = useState(tourist?.bloodType || 'O-Positive');
  const [profileAllergies, setProfileAllergies] = useState(tourist?.medicalConditions?.join(', ') || '');
  const [profileContactName, setProfileContactName] = useState(tourist?.emergencyContactName || '');
  const [profileContactPhone, setProfileContactPhone] = useState(tourist?.emergencyContactPhone || '');
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileSaveSuccess, setProfileSaveSuccess] = useState(false);

  // Settings States
  const [gpsInterval, setGpsInterval] = useState('10');
  const [simulationOverride, setSimulationOverride] = useState(true);
  const [satProtocol, setSatProtocol] = useState('Galileo + GPS Dual');
  const [chainNode, setChainNode] = useState('Aegis L2 Gasless Rollup');

  // Live Tracking Telemetry history
  const [uploadedDocs, setUploadedDocs] = useState<{
    passport: { name: string; size: string; hash: string; date: string } | null;
    visa: { name: string; size: string; hash: string; date: string } | null;
    insurance: { name: string; size: string; hash: string; date: string } | null;
  }>({
    passport: null,
    visa: null,
    insurance: null
  });

  const handleDocumentUpload = (type: 'passport' | 'visa' | 'insurance', e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const mockHash = '0x' + Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    const fileSize = (file.size / 1024).toFixed(1) + ' KB';

    setUploadedDocs(prev => ({
      ...prev,
      [type]: {
        name: file.name,
        size: fileSize,
        hash: mockHash,
        date: new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString()
      }
    }));
  };

  const [telemetryLogs, setTelemetryLogs] = useState<Array<{ lat: number, lng: number, time: string, status: string }>>([]);

  // Sync profile edit states on user/tourist load
  useEffect(() => {
    if (user) {
      setProfileName(user.name || '');
      setProfilePhone(user.phone || '');
    }
    if (tourist) {
      setProfileNationality(tourist.nationality || '');
      setProfilePassport(tourist.passportNumber || '');
      setProfileBloodType(tourist.bloodType || 'O-Positive');
      setProfileAllergies(tourist.medicalConditions?.join(', ') || '');
      setProfileContactName(tourist.emergencyContactName || '');
      setProfileContactPhone(tourist.emergencyContactPhone || '');
    }
  }, [user, tourist]);

  // Jitter and log live coordinates in memory
  useEffect(() => {
    if (currentGps) {
      setTelemetryLogs(prev => {
        const newLog = {
          lat: currentGps.lat + (Math.random() - 0.5) * 0.0001,
          lng: currentGps.lng + (Math.random() - 0.5) * 0.0001,
          time: new Date().toLocaleTimeString(),
          status: gpsDangerZoneName ? 'BREACH WARNING' : gpsZoneName ? 'ZONE_SECURE' : 'NEUTRAL'
        };
        return [newLog, ...prev.slice(0, 14)];
      });
    }
  }, [currentGps, gpsZoneName, gpsDangerZoneName]);

  // Fetch detailed AI risk assessment from backend
  const fetchRiskReport = async () => {
    setLoadingRiskReport(true);
    try {
      const res = await fetch('/api/ai/risk-report', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('safety_jwt')}` }
      });
      if (res.ok) {
        setAiRiskReport(await res.json());
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingRiskReport(false);
    }
  };

  useEffect(() => {
    fetchRiskReport();
  }, [currentGps]);

  // Request AI route advisor from backend
  const handleRouteRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoadingRoute(true);
    try {
      const res = await fetch('/api/ai/route-advisor', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('safety_jwt')}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ origin: routeOrigin, destination: routeDest })
      });
      if (res.ok) {
        setRouteAdvice(await res.json());
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingRoute(false);
    }
  };

  // Helper to submit message directly
  const submitChatMsg = async (msgText: string) => {
    if (!msgText.trim()) return;

    setChatHistory(prev => [...prev, { role: 'user', text: msgText }]);
    setLoadingChat(true);

    try {
      // Format chat history to Gemini structure
      const formattedHistory = chatHistory.map(h => ({
        role: h.role,
        parts: [{ text: h.text }]
      }));

      const res = await fetch('/api/ai/chatbot', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('safety_jwt')}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message: msgText, chatHistory: formattedHistory })
      });

      if (res.ok) {
        const data = await res.json();
        setChatHistory(prev => [...prev, { role: 'model', text: data.reply }]);
      } else {
        setChatHistory(prev => [...prev, { role: 'model', text: 'Sorry, I am having trouble connecting to my threat feed. Please check your network connection.' }]);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingChat(false);
    }
  };

  // Send message to AI chatbot
  const handleChatbotSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatbotMessage.trim()) return;

    const userMsg = chatbotMessage;
    setChatbotMessage('');
    await submitChatMsg(userMsg);
  };

  // Submit profile updates to backend and sync context
  const handleProfileUpdateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProfile(true);
    setProfileSaveSuccess(false);
    try {
      const success = await updateProfile({
        name: profileName,
        phone: profilePhone,
        nationality: profileNationality,
        passportNumber: profilePassport,
        bloodType: profileBloodType,
        medicalConditions: profileAllergies,
        emergencyContactName: profileContactName,
        emergencyContactPhone: profileContactPhone
      });
      if (success) {
        setProfileSaveSuccess(true);
        setTimeout(() => setProfileSaveSuccess(false), 3000);
      }
    } catch (err) {
      console.error('Failed to submit profile updates:', err);
    } finally {
      setSavingProfile(false);
    }
  };

  // Send messaging text to response desks
  const handleSupportSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supportText.trim()) return;
    await sendSupportMsg('police', supportText);
    setSupportText('');
  };

  const activeSos = sosAlerts.find(s => s.touristId === user?.id && s.status !== 'resolved');

  // Quick navigation preset to landmarks around Paris
  const handleJumpLocation = async (lat: number, lng: number) => {
    setCustomLat(lat.toString());
    setCustomLng(lng.toString());
    await updateGps(lat, lng);
  };

  return (
    <div className={`min-h-screen flex flex-col md:flex-row transition-colors duration-300 ${isDark ? 'mesh-background text-white' : 'mesh-background-light text-slate-900'}`}>
      
      {/* Sidebar Controls */}
      <aside className={`w-full md:w-64 border-b md:border-b-0 md:border-r flex flex-col justify-between ${isDark ? 'glass border-white/10' : 'glass-light border-slate-900/10'}`}>
        <div>
          <div className="p-6 border-b border-white/5 flex items-center space-x-3">
            <div className="bg-blue-600 p-2.5 rounded-xl text-white">
              <Shield className="h-5 w-5" />
            </div>
            <div>
              <p className="font-extrabold text-sm tracking-tight text-gradient">AEGIS TOURIST</p>
              <span className="text-[9px] uppercase tracking-wider opacity-60">Sovereign Portal</span>
            </div>
          </div>

          <div className="p-6 border-b border-white/5">
            <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Active User</p>
            <p className="text-sm font-extrabold mt-1 text-slate-200">{user?.name}</p>
            <div className="inline-flex items-center space-x-1.5 mt-2 bg-emerald-500/10 text-emerald-400 text-[10px] px-2 py-0.5 rounded-full font-bold">
              <span className="h-1.5 w-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
              <span>ID Verified</span>
            </div>
          </div>

          <nav className="p-4 space-y-1">
            {[
              { id: 'overview', name: 'Dashboard Overview', icon: Compass },
              { id: 'ai-prediction', name: 'AI Risk & Advisory', icon: TrendingUp },
              { id: 'geofencing', name: 'Geofencing Monitor', icon: Map },
              { id: 'blockchain-id', name: 'My Blockchain ID', icon: Fingerprint },
              { id: 'live-tracking', name: 'Telemetry Tracking', icon: Activity },
              { id: 'sos', name: 'Emergency SOS Box', icon: AlertOctagon },
              { id: 'notifications', name: 'Safety Alerts Logs', icon: Bell },
              { id: 'profile', name: 'Edit Safety Profile', icon: User },
              { id: 'settings', name: 'Sovereign Settings', icon: Settings }
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setTab(tab.id)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-xs font-extrabold tracking-wide transition-all cursor-pointer ${isActive ? 'bg-blue-600 text-white shadow-md glow-blue' : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'}`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.name}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-4 border-t border-white/5">
          <button 
            onClick={logout}
            className="w-full flex items-center justify-center space-x-2 py-3 bg-red-950/20 border border-red-500/20 rounded-xl hover:bg-red-950/30 text-red-400 text-xs font-bold transition-all cursor-pointer"
          >
            <LogOut className="h-4 w-4" />
            <span>Terminate Session</span>
          </button>
        </div>
      </aside>

      {/* Main Panel Frame */}
      <main className="flex-1 flex flex-col overflow-y-auto">
        
        {/* Dynamic Telemetry Status Banner */}
        <header className="p-6 border-b border-white/5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-xl font-extrabold tracking-tight">Tourist Dashboard</h2>
            <div className="flex flex-wrap gap-2 items-center mt-1 text-xs text-slate-400">
              <span className="flex items-center space-x-1">
                <MapPin className="h-3 w-3 text-blue-500" />
                <span>Geofence: {gpsZoneName || 'Neutral Sector'}</span>
              </span>
              {gpsDangerZoneName && (
                <span className="flex items-center space-x-1 text-red-400 font-bold bg-red-500/10 px-2 py-0.5 rounded">
                  <AlertTriangle className="h-3 w-3" />
                  <span>DANGER ALERT: {gpsDangerZoneName}</span>
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center space-x-4">
            {/* Real-time Status Badge */}
            <div className="text-right">
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Tactical Threat State</p>
              <p className={`text-sm font-black uppercase tracking-wider mt-0.5 ${tourist?.riskStatus === 'Safe' ? 'text-emerald-400' : tourist?.riskStatus === 'Moderate' ? 'text-amber-400' : 'text-red-400'}`}>
                {tourist?.riskStatus || 'Safe'} ({tourist?.riskScore || 15}%)
              </p>
            </div>

            {/* Tactical SOS Panic Action Button */}
            {activeSos ? (
              <div className="bg-red-500/20 text-red-500 border border-red-500/30 px-5 py-2.5 rounded-xl font-black text-xs uppercase tracking-widest animate-pulse glow-red flex items-center space-x-2">
                <span className="h-2 w-2 rounded-full bg-red-500 animate-ping"></span>
                <span>SOS Signal Active</span>
              </div>
            ) : (
              <button 
                onClick={() => triggerSos('Tourist triggered panic button.')}
                className="bg-red-600 hover:bg-red-500 text-white px-6 py-3 rounded-xl font-black text-xs uppercase tracking-widest transition-all glow-red cursor-pointer"
                id="sos-button"
              >
                🚨 TRIGGER SOS
              </button>
            )}
          </div>
        </header>

        {/* Tab Selection Area */}
        <div className="p-6 flex-1 space-y-6">
          
          {/* Active Emergency Alert overlay */}
          {activeSos && (
            <div className="bg-red-950/20 border border-red-500/20 p-5 rounded-2xl flex items-start space-x-4">
              <AlertTriangle className="h-8 w-8 text-red-500 shrink-0 glow-red animate-bounce" />
              <div>
                <h4 className="font-extrabold text-red-500 text-sm uppercase tracking-wider">POLICE & AMBULANCE DISPATCH TRIGGERED</h4>
                <p className="text-xs text-slate-300 mt-1">
                  Your coordinates [{currentGps.lat.toFixed(4)}, {currentGps.lng.toFixed(4)}] are linked live. First response teams have accepted telemetry. Remain calm and stay in well lit areas.
                </p>
                {activeSos.status === 'accepted' ? (
                  <p className="text-xs text-emerald-400 font-bold mt-2 flex items-center space-x-1.5">
                    <span className="h-2 w-2 rounded-full bg-emerald-500 animate-ping"></span>
                    <span>Accepted by: {activeSos.acceptedBy?.name} ({activeSos.acceptedBy?.role.toUpperCase()}) • Dispatching live response.</span>
                  </p>
                ) : (
                  <p className="text-xs text-slate-400 font-mono mt-2">Waiting for first responder unit acceptance...</p>
                )}
              </div>
            </div>
          )}

          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              
              {/* Bento Row 1: AI Risk Score & Weather Alerts */}
              <div className="grid md:grid-cols-3 gap-6">
                
                {/* Risk scoring */}
                <div className={`p-6 rounded-3xl border flex flex-col justify-between ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">AI Calculated Threat</p>
                      <h4 className="text-2xl font-black mt-1 text-slate-100">{tourist?.riskScore || 15}% Score</h4>
                    </div>
                    <span className={`text-[10px] font-black uppercase px-2.5 py-1 rounded-full ${tourist?.riskStatus === 'Safe' ? 'bg-emerald-500/10 text-emerald-400' : tourist?.riskStatus === 'Moderate' ? 'bg-amber-500/10 text-amber-400' : 'bg-red-500/10 text-red-400'}`}>
                      {tourist?.riskStatus || 'Safe'}
                    </span>
                  </div>

                  <div className="mt-6 space-y-2">
                    <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all duration-500 ${tourist?.riskStatus === 'Safe' ? 'bg-emerald-500' : tourist?.riskStatus === 'Moderate' ? 'bg-amber-500' : 'bg-red-500'}`}
                        style={{ width: `${tourist?.riskScore || 15}%` }}
                      ></div>
                    </div>
                    <p className="text-[10px] text-slate-400">Threat factors computed dynamically from crime reports and spatial offsets.</p>
                  </div>
                </div>

                {/* Weather Forecast */}
                <div className={`p-6 rounded-3xl border flex flex-col justify-between ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Environmental Alerts</p>
                      <h4 className="text-lg font-bold mt-1 text-slate-200">Thunderstorm Advisory</h4>
                    </div>
                    <Cloud className="h-6 w-6 text-blue-400" />
                  </div>

                  <p className="text-xs text-slate-400 mt-4 leading-relaxed">
                    Heavy downpours expected across Paris. Flash floods reported near metro line low-points. Carry protective gear.
                  </p>

                  <div className="mt-4 pt-3 border-t border-white/5 text-[10px] text-slate-500 font-semibold uppercase tracking-wider">
                    Severity: HIGH ALERT ACTIVE
                  </div>
                </div>

                {/* Emergency Hotlines */}
                <div className={`p-6 rounded-3xl border flex flex-col justify-between ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                  <div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Diplomatic Support Kin</p>
                    <h4 className="text-sm font-bold mt-2 text-slate-200">US Consulate Paris Emergency</h4>
                    <p className="text-xs text-blue-400 font-bold font-mono mt-1">+33 1 43 12 22 22</p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-white/5">
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Primary Kin Liaison</p>
                    <p className="text-xs font-bold text-slate-300 mt-1">{tourist?.emergencyContactName || 'Sarah Jenkins (Spouse)'}</p>
                    <p className="text-[11px] font-mono text-slate-400 mt-0.5">{tourist?.emergencyContactPhone || '+1 (555) 345-6789'}</p>
                  </div>
                </div>
              </div>

              {/* Bento Row 2: AI Risk report analysis & Nearby Services */}
              <div className="grid md:grid-cols-3 gap-6">
                
                {/* AI generated Safety Outlook report */}
                <div className={`p-6 rounded-3xl border md:col-span-2 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                  <div className="flex justify-between items-center mb-4">
                    <div className="flex items-center space-x-2">
                      <Activity className="h-5 w-5 text-blue-500" />
                      <h4 className="font-extrabold text-sm uppercase tracking-wider">AI Travel Safety Assessment</h4>
                    </div>
                    <button 
                      onClick={fetchRiskReport}
                      disabled={loadingRiskReport}
                      className="p-1.5 hover:bg-white/5 rounded-lg text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                    >
                      <RefreshCw className={`h-4 w-4 ${loadingRiskReport ? 'animate-spin' : ''}`} />
                    </button>
                  </div>

                  {aiRiskReport ? (
                    <div className="space-y-4">
                      <p className="text-xs text-slate-300 leading-relaxed bg-white/5 p-4 rounded-xl border border-white/5">
                        {aiRiskReport.aiAnalysis}
                      </p>
                      
                      <div>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-2">Preemptive Safety Directives</p>
                        <div className="grid sm:grid-cols-3 gap-3">
                          {aiRiskReport.recommendations?.map((rec: string, i: number) => (
                            <div key={i} className="bg-blue-600/5 border border-blue-500/10 p-3 rounded-xl text-xs text-slate-300">
                              <span className="font-bold text-blue-400 block mb-1">Directive #{i+1}</span>
                              {rec}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <p className="text-xs text-slate-400">Loading AI assessment feed...</p>
                  )}
                </div>

                {/* Nearby Emergency Services */}
                <div className={`p-6 rounded-3xl border flex flex-col justify-between ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                  <div>
                    <h4 className="font-extrabold text-sm uppercase tracking-wider mb-3">Nearby First Responders</h4>
                    
                    <div className="space-y-3">
                      {services.map(s => (
                        <div key={s.id} className="p-3 bg-white/5 rounded-xl border border-white/5 text-xs">
                          <div className="flex justify-between items-center font-bold">
                            <span className="text-slate-200 truncate pr-2">{s.name}</span>
                            <span className="text-[10px] uppercase bg-blue-500/10 text-blue-400 px-2 py-0.5 rounded-full font-bold">{s.type}</span>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-1">{s.address}</p>
                          <p className="text-[10px] font-mono font-bold text-slate-500 mt-1">{s.phone}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: MY BLOCKCHAIN DIGITAL IDENTITY */}
          {activeTab === 'blockchain-id' && (
            <div className="grid md:grid-cols-2 gap-8 items-center py-6">
              
              {/* Sovereign ID Visualizer Card */}
              <div className="relative">
                <div className="absolute -inset-1.5 bg-gradient-to-r from-blue-500 to-purple-600 rounded-3xl blur-2xl opacity-25"></div>
                
                <div className="relative p-8 rounded-3xl border border-white/10 bg-gradient-to-b from-slate-900 via-slate-950 to-indigo-950 glow-blue text-white overflow-hidden aspect-[1.6/1]">
                  {/* Decorative Elements */}
                  <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600/10 rounded-full blur-3xl"></div>
                  <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-purple-600/15 rounded-full blur-2xl"></div>

                  <div className="flex justify-between items-start">
                    <div className="flex items-center space-x-3">
                      <div className="bg-blue-600 p-2 rounded-xl text-white">
                        <Shield className="h-5 w-5 animate-pulse" />
                      </div>
                      <div>
                        <h4 className="font-extrabold text-xs uppercase tracking-widest text-slate-200">SOVEREIGN SOVEREIGNITY CARD</h4>
                        <span className="text-[9px] text-blue-400 tracking-widest font-bold">DECENTRALIZED ENCRYPTION LINK</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] font-mono text-slate-400">BLOCK: #14820129</span>
                    </div>
                  </div>

                  <div className="mt-8 grid grid-cols-3 gap-4 items-center">
                    <div className="col-span-2 space-y-3 text-xs">
                      <div>
                        <p className="text-[9px] uppercase tracking-wider text-slate-500">Citizen Name</p>
                        <p className="font-extrabold text-sm text-slate-100">{user?.name}</p>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <p className="text-[9px] uppercase tracking-wider text-slate-500">Nationality</p>
                          <p className="font-bold text-slate-200">{tourist?.nationality}</p>
                        </div>
                        <div>
                          <p className="text-[9px] uppercase tracking-wider text-slate-500">Passport Number</p>
                          <p className="font-bold text-slate-200 font-mono">{tourist?.passportNumber}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <p className="text-[9px] uppercase tracking-wider text-slate-500">Blood Type</p>
                          <p className="font-bold text-red-400">{tourist?.bloodType}</p>
                        </div>
                        <div>
                          <p className="text-[9px] uppercase tracking-wider text-slate-500">Allergies</p>
                          <p className="font-bold text-slate-200 truncate">{tourist?.medicalConditions?.join(', ') || 'None Listed'}</p>
                        </div>
                      </div>
                    </div>

                    {/* QR Code Graphic Mockup */}
                    <div className="flex flex-col items-center justify-center p-3 bg-white rounded-2xl aspect-square w-24 ml-auto border border-white/10 shadow-lg relative group">
                      <div className="absolute inset-0 bg-blue-500/10 blur opacity-0 group-hover:opacity-100 transition-opacity rounded-2xl"></div>
                      <QrCode className="h-16 w-16 text-slate-950" />
                      <span className="text-[8px] text-slate-600 font-bold mt-1 font-mono">{tourist?.verificationQr}</span>
                    </div>
                  </div>

                  <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between">
                    <div className="flex items-center space-x-1.5 text-[10px] text-slate-400 font-mono">
                      <Wallet className="h-3.5 w-3.5 text-purple-400" />
                      <span className="truncate w-32">{tourist?.blockchainWallet}</span>
                    </div>
                    <span className="text-[9px] bg-emerald-500/15 text-emerald-400 px-2 py-0.5 rounded font-bold tracking-wider uppercase">ACTIVE LEDGER STATUS</span>
                  </div>
                </div>
              </div>

              {/* Explanations */}
              <div className="space-y-6">
                <h3 className="text-2xl font-black tracking-tight text-gradient">Secure Decentralized Digital Passport</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Your Aegis profile is hashed cryptographically and linked to an on-chain ledger wallet address. It provides security authorities with instant verify logs.
                </p>

                <div className="space-y-3.5 text-xs">
                  <div className="flex items-start space-x-3">
                    <div className="bg-emerald-500/10 p-2 rounded text-emerald-400 mt-0.5">
                      <Check className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-200">Immutable Registration Verification</p>
                      <p className="text-slate-400 mt-0.5 text-[11px]">The passport verification event hash is registered permanently. No entity can edit or forge this profile.</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="bg-emerald-500/10 p-2 rounded text-emerald-400 mt-0.5">
                      <Check className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-200">Physical Credentials Separation</p>
                      <p className="text-slate-400 mt-0.5 text-[11px]">Allows secure checking in museums, hotels, or airports without risking loss of your physical document book.</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Secure Blockchain Document Vault */}
              <div className="md:col-span-2 mt-8 p-6 rounded-3xl border border-white/10 bg-slate-900/40 text-left space-y-6">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                  <div>
                    <h3 className="text-md font-black text-white flex items-center space-x-2">
                      <HardDrive className="h-5 w-5 text-purple-400" />
                      <span>Sovereign Ledger Document Vault</span>
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Upload your essential travel documents. They are encrypted locally in your sandbox browser, hashed cryptographically, and anchored to your decentralized Aegis L2 identity block.
                    </p>
                  </div>
                  <span className="text-[9px] bg-purple-500/10 text-purple-400 border border-purple-500/20 px-2.5 py-1 rounded font-mono font-bold tracking-wider self-start sm:self-center">
                    AES-256 + IPFS SECURED
                  </span>
                </div>

                <div className="grid sm:grid-cols-3 gap-6">
                  {/* Passport Upload */}
                  <div className={`p-5 rounded-2xl border transition-all flex flex-col justify-between ${uploadedDocs.passport ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-white/5 bg-slate-950/40 hover:border-white/10'}`}>
                    <div className="space-y-3">
                      <div className="flex justify-between items-start">
                        <div className={`p-2 rounded-xl ${uploadedDocs.passport ? 'bg-emerald-500/10 text-emerald-400' : 'bg-blue-500/10 text-blue-400'}`}>
                          <FileText className="h-5 w-5" />
                        </div>
                        <span className={`text-[8px] font-bold px-2 py-0.5 rounded uppercase ${uploadedDocs.passport ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-500'}`}>
                          {uploadedDocs.passport ? 'SECURED' : 'REQUIRED'}
                        </span>
                      </div>
                      <div>
                        <h4 className="text-xs font-extrabold text-slate-200">National Passport Book</h4>
                        <p className="text-[10px] text-slate-500 mt-0.5">Primary biographical identity node</p>
                      </div>

                      {uploadedDocs.passport && (
                        <div className="space-y-1.5 pt-2 border-t border-white/5 font-mono text-[9px]">
                          <p className="text-slate-300 truncate font-bold">📄 {uploadedDocs.passport.name}</p>
                          <p className="text-slate-500">Size: {uploadedDocs.passport.size}</p>
                          <p className="text-slate-500 font-bold text-slate-400">Uploaded: {uploadedDocs.passport.date}</p>
                          <p className="text-purple-400 truncate mt-1">Hash: {uploadedDocs.passport.hash}</p>
                        </div>
                      )}
                    </div>

                    <div className="mt-4">
                      <label className="w-full py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-[10px] font-bold uppercase tracking-wider text-slate-300 transition-all cursor-pointer text-center block">
                        {uploadedDocs.passport ? 'Update Passport' : 'Upload Passport'}
                        <input 
                          type="file" 
                          accept="image/*,.pdf" 
                          className="hidden" 
                          onChange={(e) => handleDocumentUpload('passport', e)} 
                        />
                      </label>
                    </div>
                  </div>

                  {/* Visa Upload */}
                  <div className={`p-5 rounded-2xl border transition-all flex flex-col justify-between ${uploadedDocs.visa ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-white/5 bg-slate-950/40 hover:border-white/10'}`}>
                    <div className="space-y-3">
                      <div className="flex justify-between items-start">
                        <div className={`p-2 rounded-xl ${uploadedDocs.visa ? 'bg-emerald-500/10 text-emerald-400' : 'bg-blue-500/10 text-blue-400'}`}>
                          <UserCheck className="h-5 w-5" />
                        </div>
                        <span className={`text-[8px] font-bold px-2 py-0.5 rounded uppercase ${uploadedDocs.visa ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-500'}`}>
                          {uploadedDocs.visa ? 'SECURED' : 'REQUIRED'}
                        </span>
                      </div>
                      <div>
                        <h4 className="text-xs font-extrabold text-slate-200">Schengen Entry Visa</h4>
                        <p className="text-[10px] text-slate-500 mt-0.5">Authorization & immigration stamp</p>
                      </div>

                      {uploadedDocs.visa && (
                        <div className="space-y-1.5 pt-2 border-t border-white/5 font-mono text-[9px]">
                          <p className="text-slate-300 truncate font-bold">📄 {uploadedDocs.visa.name}</p>
                          <p className="text-slate-500">Size: {uploadedDocs.visa.size}</p>
                          <p className="text-slate-500 font-bold text-slate-400">Uploaded: {uploadedDocs.visa.date}</p>
                          <p className="text-purple-400 truncate mt-1">Hash: {uploadedDocs.visa.hash}</p>
                        </div>
                      )}
                    </div>

                    <div className="mt-4">
                      <label className="w-full py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-[10px] font-bold uppercase tracking-wider text-slate-300 transition-all cursor-pointer text-center block">
                        {uploadedDocs.visa ? 'Update Visa' : 'Upload Visa'}
                        <input 
                          type="file" 
                          accept="image/*,.pdf" 
                          className="hidden" 
                          onChange={(e) => handleDocumentUpload('visa', e)} 
                        />
                      </label>
                    </div>
                  </div>

                  {/* Insurance Upload */}
                  <div className={`p-5 rounded-2xl border transition-all flex flex-col justify-between ${uploadedDocs.insurance ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-white/5 bg-slate-950/40 hover:border-white/10'}`}>
                    <div className="space-y-3">
                      <div className="flex justify-between items-start">
                        <div className={`p-2 rounded-xl ${uploadedDocs.insurance ? 'bg-emerald-500/10 text-emerald-400' : 'bg-blue-500/10 text-blue-400'}`}>
                          <Heart className="h-5 w-5" />
                        </div>
                        <span className={`text-[8px] font-bold px-2 py-0.5 rounded uppercase ${uploadedDocs.insurance ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-500'}`}>
                          {uploadedDocs.insurance ? 'SECURED' : 'REQUIRED'}
                        </span>
                      </div>
                      <div>
                        <h4 className="text-xs font-extrabold text-slate-200">Medical Travel Insurance</h4>
                        <p className="text-[10px] text-slate-500 mt-0.5">Emergency healthcare coverage bond</p>
                      </div>

                      {uploadedDocs.insurance && (
                        <div className="space-y-1.5 pt-2 border-t border-white/5 font-mono text-[9px]">
                          <p className="text-slate-300 truncate font-bold">📄 {uploadedDocs.insurance.name}</p>
                          <p className="text-slate-500">Size: {uploadedDocs.insurance.size}</p>
                          <p className="text-slate-500 font-bold text-slate-400">Uploaded: {uploadedDocs.insurance.date}</p>
                          <p className="text-purple-400 truncate mt-1">Hash: {uploadedDocs.insurance.hash}</p>
                        </div>
                      )}
                    </div>

                    <div className="mt-4">
                      <label className="w-full py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-[10px] font-bold uppercase tracking-wider text-slate-300 transition-all cursor-pointer text-center block">
                        {uploadedDocs.insurance ? 'Update Insurance' : 'Upload Insurance'}
                        <input 
                          type="file" 
                          accept="image/*,.pdf" 
                          className="hidden" 
                          onChange={(e) => handleDocumentUpload('insurance', e)} 
                        />
                      </label>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* TAB 3: AI SAFE ROUTE & ASSISTANT CHAT HUB */}
          {activeTab === 'ai-prediction' && (
            <div className="space-y-8 py-4">
              <div className="grid lg:grid-cols-12 gap-8">
                
                {/* Route advisor panel */}
                <div className="lg:col-span-5 space-y-6">
                  <div className={`p-6 rounded-3xl border ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                    <h3 className="font-extrabold text-xs uppercase tracking-wider text-blue-400 mb-4 flex items-center space-x-1.5">
                      <Navigation className="h-4 w-4" />
                      <span>Request AI Path Safety Analysis</span>
                    </h3>
                    
                    <form onSubmit={handleRouteRequest} className="space-y-4">
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 block mb-1">Departure Origin Landmark</label>
                        <input 
                          type="text" 
                          required
                          value={routeOrigin}
                          onChange={(e) => setRouteOrigin(e.target.value)}
                          className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs text-slate-200 outline-none focus:border-blue-500"
                          placeholder="e.g. Eiffel Tower"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-400 block mb-1">Destination Landmark</label>
                        <input 
                          type="text" 
                          required
                          value={routeDest}
                          onChange={(e) => setRouteDest(e.target.value)}
                          className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs text-slate-200 outline-none focus:border-blue-500"
                          placeholder="e.g. Louvre Museum"
                        />
                      </div>

                      <button 
                        type="submit"
                        disabled={loadingRoute}
                        className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase rounded-xl tracking-wider transition-all cursor-pointer flex items-center justify-center space-x-2"
                      >
                        <Navigation className="h-4 w-4" />
                        <span>{loadingRoute ? 'Consulting Gemini Safety Engine...' : 'Calculate Safest Pedestrian Route'}</span>
                      </button>
                    </form>
                  </div>

                  {/* Route advice panel */}
                  <div>
                    {routeAdvice ? (
                      <div className={`p-6 rounded-3xl border space-y-4 ${isDark ? 'glass-card border-emerald-500/20' : 'glass-card-light border-emerald-500/10'}`}>
                        <div className="flex justify-between items-center">
                          <h4 className="font-black text-xs uppercase tracking-wider text-emerald-400 flex items-center space-x-1.5">
                            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-ping"></span>
                            <span>{routeAdvice.safetyLevel}</span>
                          </h4>
                          <span className="text-[10px] font-mono bg-white/5 px-2.5 py-1 rounded text-slate-300">ETA: {routeAdvice.estimatedTime}</span>
                        </div>

                        <div>
                          <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Optimized Secure Pedestrian Path</p>
                          <p className="text-xs text-slate-300 mt-1 leading-relaxed bg-white/5 p-4 rounded-xl border border-white/5">
                            {routeAdvice.safeRouteDescription}
                          </p>
                        </div>

                        <div className="grid sm:grid-cols-2 gap-4">
                          <div>
                            <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider mb-2">Identified Crime Risks</p>
                            <div className="space-y-1">
                              {routeAdvice.riskFactors?.map((f: string, i: number) => (
                                <p key={i} className="text-[11px] text-slate-300 flex items-center space-x-1.5">
                                  <span className="h-1.5 w-1.5 bg-red-400 rounded-full"></span>
                                  <span>{f}</span>
                                </p>
                              ))}
                            </div>
                          </div>

                          <div>
                            <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider mb-2">Required Precautions</p>
                            <div className="space-y-1">
                              {routeAdvice.precautions?.map((p: string, i: number) => (
                                <p key={i} className="text-[11px] text-slate-300 flex items-center space-x-1.5">
                                  <span className="h-1.5 w-1.5 bg-blue-400 rounded-full"></span>
                                  <span>{p}</span>
                                </p>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="border border-dashed border-white/10 rounded-3xl flex flex-col justify-center items-center p-8 text-center text-slate-500 text-xs">
                        <Navigation className="h-6 w-6 text-slate-600 mb-2 animate-pulse" />
                        <p>Enter origin and destination points to compute safe pathways avoiding pickpockets, crowds, and poorly illuminated streets.</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Chat Console Panel */}
                <div className="lg:col-span-7 grid md:grid-cols-3 gap-6 items-start">
                  <div className={`p-6 rounded-3xl border space-y-4 md:col-span-1 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                    <h3 className="font-extrabold text-xs uppercase tracking-wider text-purple-400 flex items-center space-x-1.5">
                      <Cpu className="h-4 w-4" />
                      <span>Threat Intelligence</span>
                    </h3>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Ask safety questions, enquire about local pickpocketing teams, weather forecasts, or retrieve cryptographic validation signatures procedures.
                    </p>

                    <div className="space-y-2 text-xs font-bold">
                      <button 
                        onClick={() => submitChatMsg('How does the blockchain passport verify identity?')}
                        className="w-full text-left py-2 px-2.5 bg-white/5 border border-white/5 rounded-xl hover:bg-white/10 transition-all text-slate-300 text-[10px] cursor-pointer"
                      >
                        💡 How does blockchain verify ID?
                      </button>
                      <button 
                        onClick={() => submitChatMsg('Are there any active storms or weather warnings in Paris?')}
                        className="w-full text-left py-2 px-2.5 bg-white/5 border border-white/5 rounded-xl hover:bg-white/10 transition-all text-slate-300 text-[10px] cursor-pointer"
                      >
                        ⛈️ Any active weather alarms?
                      </button>
                      <button 
                        onClick={() => submitChatMsg('Is Marina Beach safe today?')}
                        className="w-full text-left py-2 px-2.5 bg-white/5 border border-white/5 rounded-xl hover:bg-white/10 transition-all text-slate-300 text-[10px] cursor-pointer"
                      >
                        🏖️ Is Marina Beach safe today?
                      </button>
                    </div>
                  </div>

                  <div className={`md:col-span-2 p-6 rounded-3xl border flex flex-col justify-between min-h-[460px] ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                    <div className="space-y-4 flex-1 overflow-y-auto max-h-[340px] pr-2">
                      {chatHistory.map((h, i) => (
                        <div key={i} className={`flex ${h.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                          <div className={`max-w-[85%] p-3 rounded-2xl text-xs leading-relaxed ${h.role === 'user' ? 'bg-blue-600 text-white' : 'bg-white/5 border border-white/5 text-slate-200'}`}>
                            <p className="font-bold text-[8px] uppercase opacity-50 mb-1">{h.role === 'user' ? 'Tourist' : 'Aegis AI'}</p>
                            {h.text}
                          </div>
                        </div>
                      ))}
                      {loadingChat && (
                        <div className="flex justify-start">
                          <div className="bg-white/5 border border-white/5 p-3 rounded-2xl text-[11px] text-slate-400 animate-pulse">
                            Aegis is querying safety logs...
                          </div>
                        </div>
                      )}
                    </div>

                    <form onSubmit={handleChatbotSend} className="flex items-center space-x-3 mt-4 border-t border-white/5 pt-4">
                      <input 
                        type="text"
                        required
                        value={chatbotMessage}
                        onChange={(e) => setChatbotMessage(e.target.value)}
                        className="flex-1 px-4 py-3 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200 focus:border-blue-500"
                        placeholder="Enter your security or navigation question..."
                      />
                      <button 
                        type="submit"
                        className="p-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl transition-all cursor-pointer"
                      >
                        <Send className="h-4 w-4" />
                      </button>
                    </form>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* TAB 4: GPS TELEMETRY & GEOFENCING */}
          {activeTab === 'geofencing' && (
            <div className="space-y-6">
              <div className="grid md:grid-cols-3 gap-6 items-start">
                
                {/* Simulated Landmarks Preset Jump */}
                <div className={`p-6 rounded-3xl border space-y-4 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                  <h3 className="font-extrabold text-xs uppercase tracking-wider text-blue-400">Jump To Paris Landmarks (Test Geofences)</h3>
                  
                  <div className="space-y-2 text-xs font-bold">
                    <button 
                      onClick={() => handleJumpLocation(48.8606, 2.3376)}
                      className="w-full text-left py-2.5 px-4 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all flex justify-between items-center cursor-pointer"
                    >
                      <span>Louvre Museum Perimeter</span>
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded font-bold">Safe Zone</span>
                    </button>

                    <button 
                      onClick={() => handleJumpLocation(48.8698, 2.3075)}
                      className="w-full text-left py-2.5 px-4 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all flex justify-between items-center cursor-pointer"
                    >
                      <span>Champs-Élysées Central</span>
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded font-bold">Safe Zone</span>
                    </button>

                    <button 
                      onClick={() => handleJumpLocation(48.8654, 2.3508)}
                      className="w-full text-left py-2.5 px-4 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all flex justify-between items-center cursor-pointer"
                    >
                      <span>Rue Saint-Denis Hotspot</span>
                      <span className="text-[10px] bg-red-500/10 text-red-400 px-2 py-0.5 rounded font-bold">Danger Zone</span>
                    </button>

                    <button 
                      onClick={() => handleJumpLocation(48.8584, 2.2945)}
                      className="w-full text-left py-2.5 px-4 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all flex justify-between items-center cursor-pointer"
                    >
                      <span>Eiffel Tower Neutral Zone</span>
                      <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-bold">Neutral</span>
                    </button>
                  </div>
                </div>

                {/* Live Coordinates Controller */}
                <div className={`p-6 rounded-3xl border space-y-4 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                  <h3 className="font-extrabold text-xs uppercase tracking-wider text-purple-400">Manual Telemetry Override</h3>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="text-[10px] text-slate-400 block mb-1">Latitude</label>
                      <input 
                        type="text"
                        value={customLat}
                        onChange={(e) => setCustomLat(e.target.value)}
                        className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs text-slate-200 font-mono outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 block mb-1">Longitude</label>
                      <input 
                        type="text"
                        value={customLng}
                        onChange={(e) => setCustomLng(e.target.value)}
                        className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs text-slate-200 font-mono outline-none"
                      />
                    </div>
                    <button 
                      onClick={() => updateGps(Number(customLat), Number(customLng))}
                      className="w-full py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs uppercase rounded-xl transition-all cursor-pointer"
                    >
                      Update Telemetry Position
                    </button>
                  </div>
                </div>

                {/* Active Geofence Definitions */}
                <div className={`p-6 rounded-3xl border space-y-4 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                  <h3 className="font-extrabold text-xs uppercase tracking-wider text-slate-200">Registered Geofences</h3>
                  
                  <div className="space-y-2.5 max-h-48 overflow-y-auto">
                    {safeZones.map(z => (
                      <div key={z.id} className="p-3 bg-white/5 rounded-xl border border-white/5 text-xs">
                        <div className="flex justify-between items-center font-bold">
                          <span className="text-slate-300">{z.name}</span>
                          <span className={`text-[9px] uppercase px-2 py-0.5 rounded font-bold ${z.type === 'safe' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'}`}>
                            {z.type}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-400 mt-1">{z.description}</p>
                        <p className="text-[9px] font-mono text-slate-500 mt-1">Radius: {z.radius}m</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Visualized SVG Mock Map Grid */}
              <div className="p-6 border border-white/5 rounded-3xl bg-slate-950/80 relative overflow-hidden flex flex-col justify-between min-h-[350px]">
                <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-40"></div>
                
                <div className="z-10 flex justify-between items-center">
                  <h4 className="font-black text-xs uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
                    <Map className="h-4 w-4 text-blue-500" />
                    <span>PARIS SECTOR LIVE TELEMETRY VISUALIZER</span>
                  </h4>
                  <span className="text-[10px] font-mono text-slate-500 bg-white/5 px-2.5 py-1 rounded">Scale: 1:15,000</span>
                </div>

                {/* SVG Visual Elements for Safe & Danger Circles */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg">
                  {/* Louvre Safe circle */}
                  <circle cx="50%" cy="40%" r="60" fill="rgba(16, 185, 129, 0.05)" stroke="rgba(16, 185, 129, 0.25)" strokeWidth="1" strokeDasharray="4 4" />
                  <text x="50%" y="32%" fill="rgba(16, 185, 129, 0.7)" fontSize="8" fontWeight="bold" textAnchor="middle">LOUVRE SECURITY PERIMETER</text>

                  {/* Champs-Élysées Safe Circle */}
                  <circle cx="25%" cy="50%" r="80" fill="rgba(16, 185, 129, 0.04)" stroke="rgba(16, 185, 129, 0.2)" strokeWidth="1" />
                  <text x="25%" y="42%" fill="rgba(16, 185, 129, 0.7)" fontSize="8" fontWeight="bold" textAnchor="middle">CHAMPS-ÉLYSÉES TOURIST ZONE</text>

                  {/* Saint-Denis Danger Circle */}
                  <circle cx="75%" cy="55%" r="50" fill="rgba(239, 68, 68, 0.06)" stroke="rgba(239, 68, 68, 0.3)" strokeWidth="1" strokeDasharray="3 3" />
                  <text x="75%" y="49%" fill="rgba(239, 68, 68, 0.7)" fontSize="8" fontWeight="bold" textAnchor="middle">RUE SAINT-DENIS DANGER SECTOR</text>

                  {/* Lines linking current user to centers */}
                  <line x1="50%" y1="50%" x2="50%" y2="40%" stroke="rgba(59, 130, 246, 0.15)" strokeWidth="1" />
                  <line x1="50%" y1="50%" x2="75%" y2="55%" stroke="rgba(239, 68, 68, 0.15)" strokeWidth="1" />
                </svg>

                {/* Central Pulse Ring representation of active user position */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
                  <div className={`h-4 w-4 rounded-full ${tourist?.riskStatus === 'Safe' ? 'bg-emerald-500' : tourist?.riskStatus === 'Moderate' ? 'bg-amber-500' : 'bg-red-500'} relative z-10 glow-blue`}></div>
                  <div className="absolute h-10 w-10 rounded-full bg-blue-500/20 pulse-ring"></div>
                  <span className="text-[10px] bg-slate-900 border border-white/10 px-2 py-0.5 rounded text-white font-bold mt-6 z-20 whitespace-nowrap">
                    Active Tourist Coordinates
                  </span>
                </div>

                <div className="z-10 flex justify-between items-end text-[10px] text-slate-400 font-mono">
                  <span>LAT: {currentGps.lat.toFixed(5)}° N</span>
                  <span>LNG: {currentGps.lng.toFixed(5)}° E</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: LIVE TRACKING TELEMETRY */}
          {activeTab === 'live-tracking' && (
            <div className="space-y-6 py-4">
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
                
                {/* Metric cards */}
                <div className={`p-6 rounded-3xl border flex items-center space-x-4 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                  <div className="p-3.5 rounded-2xl bg-blue-500/10 text-blue-400">
                    <Activity className="h-5 w-5 animate-pulse" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block font-bold uppercase">Satellite Link</span>
                    <span className="text-xs font-black text-slate-100">{satProtocol}</span>
                  </div>
                </div>

                <div className={`p-6 rounded-3xl border flex items-center space-x-4 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                  <div className="p-3.5 rounded-2xl bg-emerald-500/10 text-emerald-400">
                    <Check className="h-5 w-5" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block font-bold uppercase">GPS Latency</span>
                    <span className="text-xs font-black text-slate-100">42ms (Secure)</span>
                  </div>
                </div>

                <div className={`p-6 rounded-3xl border flex items-center space-x-4 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                  <div className="p-3.5 rounded-2xl bg-purple-500/10 text-purple-400">
                    <Cpu className="h-5 w-5" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block font-bold uppercase">Polling Frequency</span>
                    <span className="text-xs font-black text-slate-100">{gpsInterval} seconds</span>
                  </div>
                </div>

                <div className={`p-6 rounded-3xl border flex items-center space-x-4 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                  <div className="p-3.5 rounded-2xl bg-amber-500/10 text-amber-400">
                    <Wallet className="h-5 w-5" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block font-bold uppercase">Decentralized Gas</span>
                    <span className="text-xs font-black text-slate-100">0.000 ETH (Free Rollup)</span>
                  </div>
                </div>

              </div>

              {/* Streaming Logs list */}
              <div className="grid md:grid-cols-3 gap-6">
                
                {/* Visualizer stream graph */}
                <div className={`md:col-span-2 p-6 rounded-3xl border ${isDark ? 'glass-card' : 'glass-card-light'} space-y-4`}>
                  <h3 className="font-extrabold text-xs uppercase tracking-wider text-blue-400">Continuous Satellite Coordinates Log</h3>
                  
                  <div className="h-64 bg-slate-950/80 rounded-2xl border border-white/5 relative overflow-hidden flex flex-col justify-end p-4">
                    <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:12px_12px] opacity-20"></div>
                    
                    {/* SVG mini jitter graph */}
                    <svg className="absolute inset-0 w-full h-full p-4" viewBox="0 0 100 100" preserveAspectRatio="none">
                      <polyline
                        fill="none"
                        stroke="#2563eb"
                        strokeWidth="1.5"
                        strokeDasharray="1 1"
                        points="0,50 15,48 30,52 45,35 60,70 75,45 90,48 100,50"
                      />
                      <polyline
                        fill="none"
                        stroke="#10b981"
                        strokeWidth="2"
                        points="0,50 10,48 20,51 30,49 40,53 50,50 60,51 70,48 80,50 90,49 100,50"
                        className="animate-pulse"
                      />
                    </svg>

                    <div className="z-10 flex justify-between items-center text-[10px] text-slate-400 font-mono">
                      <span>Telemetry: GALILEO-STREAM_ON</span>
                      <span className="text-emerald-400 flex items-center space-x-1">
                        <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                        <span>LIVE STREAMING</span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Telemetry log table */}
                <div className={`p-6 rounded-3xl border space-y-4 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                  <h3 className="font-extrabold text-xs uppercase tracking-wider text-slate-200">On-Chain Coordinates Broadcasts</h3>
                  
                  <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                    {telemetryLogs.map((l, i) => (
                      <div key={i} className="p-3 bg-white/5 border border-white/5 rounded-xl flex justify-between items-center text-[10px] font-mono">
                        <div>
                          <p className="text-slate-300">N: {l.lat.toFixed(5)}°</p>
                          <p className="text-slate-500 mt-0.5">E: {l.lng.toFixed(5)}°</p>
                        </div>
                        <div className="text-right">
                          <p className="text-slate-400">{l.time}</p>
                          <span className={`text-[8px] uppercase font-bold px-1.5 py-0.5 rounded mt-1 inline-block ${l.status === 'BREACH WARNING' ? 'bg-red-500/20 text-red-400' : l.status === 'ZONE_SECURE' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-400'}`}>
                            {l.status}
                          </span>
                        </div>
                      </div>
                    ))}
                    {telemetryLogs.length === 0 && (
                      <div className="text-center text-xs text-slate-500 py-12">
                        Initializing GPS stream feeds...
                      </div>
                    )}
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* TAB 7: SAFETY NOTIFICATIONS CENTER */}
          {activeTab === 'notifications' && (
            <div className="space-y-6 py-4">
              <div className={`p-6 rounded-3xl border ${isDark ? 'glass-card' : 'glass-card-light'} space-y-4`}>
                <h3 className="font-extrabold text-sm uppercase tracking-wider text-blue-400">Real-Time Security Notifications</h3>
                <p className="text-xs text-slate-400">
                  Critical alerts are dispatched by local security and police authorities automatically based on your GPS geofence containment state.
                </p>

                <div className="space-y-3.5">
                  {/* Weather alarm */}
                  <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl flex items-start space-x-4">
                    <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 mt-0.5">
                      <Cloud className="h-5 w-5" />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-center">
                        <h4 className="font-extrabold text-xs text-amber-200">Paris Weather Warning: Thunderstorms & Wind</h4>
                        <span className="text-[9px] font-mono font-bold text-amber-400">SEVERE ALARM</span>
                      </div>
                      <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                        Météo-France has issued an amber alert for heavy thunderstorms with gusts up to 85 km/h across the Île-de-France region. Please minimize outdoor walking and avoid standing near temporary structures or scaffoldings.
                      </p>
                      <p className="text-[10px] font-mono text-slate-500 mt-2">Active: Paris Sector • 1 hour ago</p>
                    </div>
                  </div>

                  {/* Geofence Breach Alarm */}
                  <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-start space-x-4">
                    <div className="p-2.5 rounded-xl bg-red-500/20 text-red-400 mt-0.5">
                      <AlertOctagon className="h-5 w-5" />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-center">
                        <h4 className="font-extrabold text-xs text-red-200">Pickpocketing Ring Alert near Rue Saint-Denis</h4>
                        <span className="text-[9px] font-mono font-bold text-red-400">SECURITY RISK</span>
                      </div>
                      <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                        Local security units report active organized distraction teams targeting tourist digital devices and wallets. Secure your pockets and passport credentials.
                      </p>
                      <p className="text-[10px] font-mono text-slate-500 mt-2">Active: Rue Saint-Denis • 45 minutes ago</p>
                    </div>
                  </div>

                  {/* General safety broadcast */}
                  <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-2xl flex items-start space-x-4">
                    <div className="p-2.5 rounded-xl bg-blue-500/20 text-blue-400 mt-0.5">
                      <Shield className="h-5 w-5" />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-center">
                        <h4 className="font-extrabold text-xs text-blue-200">System Information: Digital ID verified successfully</h4>
                        <span className="text-[9px] font-mono font-bold text-blue-400">SYSTEM BROADCAST</span>
                      </div>
                      <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                        Your on-chain verified digital passport hash is correctly matched with local Paris Embassy dispatchers. You are registered under high-priority safety tracking protocols.
                      </p>
                      <p className="text-[10px] font-mono text-slate-500 mt-2">Active: Global • 3 hours ago</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: EMERGENCY SOS & DISPATCH CHAT */}
          {activeTab === 'sos' && (
            <div className="grid md:grid-cols-3 gap-6 items-start py-4">
              <div className={`p-6 rounded-3xl border space-y-4 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                <h3 className="font-extrabold text-sm uppercase tracking-wider text-red-500 flex items-center space-x-1.5">
                  <span className="h-2 w-2 rounded-full bg-red-500 animate-ping"></span>
                  <span>Panic Station Control</span>
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  In case of immediate threat, pickpocketing, suspect tracking, or physical distress, trigger the broadcast panic signal to alert all nearby responders.
                </p>

                {/* Emergency Trigger Button */}
                <button
                  onClick={handleSosPress}
                  className="w-full py-4 bg-red-600 hover:bg-red-500 text-white font-extrabold text-xs uppercase tracking-wider rounded-2xl transition-all cursor-pointer shadow-lg shadow-red-600/20 text-center block animate-pulse"
                >
                  🚨 Broadcast Panic Signal Now
                </button>

                <div className="p-4 bg-blue-500/5 rounded-xl border border-blue-500/10 text-[11px] text-slate-300">
                  <span className="font-bold block text-blue-400 mb-1">Responder Coverage Desk</span>
                  Emergency services are active in your sector. A dispatch officer will secure immediate connection.
                </div>
              </div>

              {/* Chat Interface */}
              <div className={`md:col-span-2 p-6 rounded-3xl border flex flex-col justify-between min-h-[420px] ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Dispatcher Encrypted Chat Thread</h4>
                  <div className="space-y-4 overflow-y-auto max-h-[300px] pr-2">
                    {messages.map((m) => (
                      <div key={m.id} className={`flex ${m.senderId === user?.id ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] p-4 rounded-2xl text-xs leading-relaxed ${m.senderId === user?.id ? 'bg-purple-600 text-white' : 'bg-white/5 border border-white/15 text-slate-200'}`}>
                          <div className="flex justify-between space-x-4 items-center mb-1 text-[9px] opacity-60 font-bold uppercase">
                            <span>{m.senderName}</span>
                            <span>{new Date(m.createdAt).toLocaleTimeString()}</span>
                          </div>
                          {m.message}
                        </div>
                      </div>
                    ))}
                    {messages.length === 0 && (
                      <div className="text-center text-xs text-slate-500 py-12">
                        No communications recorded. Text the dispatcher station below if you need non-emergency guidance.
                      </div>
                    )}
                  </div>
                </div>

                <form onSubmit={handleSupportSend} className="flex items-center space-x-3 mt-4 border-t border-white/5 pt-4">
                  <input 
                    type="text"
                    required
                    value={supportText}
                    onChange={(e) => setSupportText(e.target.value)}
                    className="flex-1 px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200 focus:border-blue-500"
                    placeholder="Describe query or suspected safety threat..."
                  />
                  <button 
                    type="submit"
                    className="p-3.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl transition-all cursor-pointer"
                  >
                    <Send className="h-4 w-4" />
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* TAB 8: DYNAMIC SAFETY PROFILE EDITOR */}
          {activeTab === 'profile' && (
            <div className="grid md:grid-cols-12 gap-8 py-4 items-start">
              
              {/* Left Column: Visual summary badge */}
              <div className="md:col-span-4 space-y-6">
                <div className="relative">
                  <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 to-emerald-500 rounded-3xl blur opacity-20"></div>
                  <div className="relative p-6 rounded-3xl border border-white/10 bg-slate-950 text-white space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="bg-emerald-500/10 p-2.5 rounded-2xl text-emerald-400">
                        <Heart className="h-6 w-6" />
                      </div>
                      <span className="text-[10px] font-mono bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded font-bold">LOCKED LEDGER</span>
                    </div>

                    <div>
                      <h4 className="text-sm font-black text-slate-200 uppercase tracking-tight">{user?.name}</h4>
                      <p className="text-[10px] font-mono text-slate-500 mt-0.5">UID: {user?.id.slice(0, 8)}...</p>
                    </div>

                    <div className="border-t border-white/5 pt-4 space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span className="text-slate-400 font-bold text-[10px]">BLOOD TYPE:</span>
                        <span className="font-mono text-red-400 font-bold">{profileBloodType || 'Not Provided'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400 font-bold text-[10px]">PASSPORT NO:</span>
                        <span className="font-mono text-slate-200 font-bold">{profilePassport || 'Not Provided'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400 font-bold text-[10px]">NATIONALITY:</span>
                        <span className="text-slate-200 font-bold">{profileNationality || 'Not Provided'}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-emerald-500/5 rounded-2xl border border-emerald-500/10 text-[11px] text-slate-300 leading-relaxed">
                  <span className="font-bold block text-emerald-400 mb-1">First Responder Protocol</span>
                  Your medical profile and emergency contacts are encrypted and made available to emergency medical teams only if you trigger an active SOS rescue sequence.
                </div>
              </div>

              {/* Right Column: Interactive Save Form */}
              <div className={`md:col-span-8 p-6 rounded-3xl border ${isDark ? 'glass-card' : 'glass-card-light'}`}>
                <h3 className="font-extrabold text-sm uppercase tracking-wider text-blue-400 mb-4 flex items-center space-x-2">
                  <Edit2 className="h-4 w-4" />
                  <span>Configure Sovereign Safety Parameters</span>
                </h3>

                {profileSaveSuccess && (
                  <div className="mb-4 p-3.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold rounded-xl flex items-center space-x-2 animate-bounce">
                    <Check className="h-4 w-4" />
                    <span>Your security and medical parameters have been successfully written to the ledger database!</span>
                  </div>
                )}

                <form onSubmit={handleProfileUpdateSubmit} className="space-y-4">
                  
                  {/* Row 1: General details */}
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 block mb-1">Full Name (Biometric Signature)</label>
                      <input 
                        type="text" 
                        required
                        value={profileName}
                        onChange={(e) => setProfileName(e.target.value)}
                        className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs text-slate-200 outline-none focus:border-blue-500"
                        placeholder="e.g. Jean Dupont"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 block mb-1">Mobile Telephone Number</label>
                      <input 
                        type="text" 
                        required
                        value={profilePhone}
                        onChange={(e) => setProfilePhone(e.target.value)}
                        className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs text-slate-200 outline-none focus:border-blue-500 font-mono"
                        placeholder="e.g. +33 6 1234 5678"
                      />
                    </div>
                  </div>

                  {/* Row 2: Passport & Nationality */}
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 block mb-1">Passport / ID Document Number</label>
                      <input 
                        type="text" 
                        required
                        value={profilePassport}
                        onChange={(e) => setProfilePassport(e.target.value)}
                        className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs text-slate-200 outline-none focus:border-blue-500 font-mono"
                        placeholder="e.g. FRA991823"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 block mb-1">Sovereign Nationality Country</label>
                      <input 
                        type="text" 
                        required
                        value={profileNationality}
                        onChange={(e) => setProfileNationality(e.target.value)}
                        className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs text-slate-200 outline-none focus:border-blue-500"
                        placeholder="e.g. France"
                      />
                    </div>
                  </div>

                  {/* Row 3: Medical parameters */}
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 block mb-1">Emergency Blood Type Group</label>
                      <select 
                        value={profileBloodType}
                        onChange={(e) => setProfileBloodType(e.target.value)}
                        className="w-full px-4 py-2.5 bg-slate-900 border border-white/10 rounded-xl text-xs text-slate-200 outline-none focus:border-blue-500 cursor-pointer"
                      >
                        <option value="A-Positive">A-Positive (A+)</option>
                        <option value="A-Negative">A-Negative (A-)</option>
                        <option value="B-Positive">B-Positive (B+)</option>
                        <option value="B-Negative">B-Negative (B-)</option>
                        <option value="AB-Positive">AB-Positive (AB+)</option>
                        <option value="AB-Negative">AB-Negative (AB-)</option>
                        <option value="O-Positive">O-Positive (O+)</option>
                        <option value="O-Negative">O-Negative (O-)</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 block mb-1">Allergies / Critical Medical Conditions</label>
                      <input 
                        type="text" 
                        value={profileAllergies}
                        onChange={(e) => setProfileAllergies(e.target.value)}
                        className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs text-slate-200 outline-none focus:border-blue-500"
                        placeholder="e.g. Penicillin, Asthma, Diabetes"
                      />
                    </div>
                  </div>

                  {/* Row 4: Emergency Contacts */}
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 block mb-1">Emergency Contact Full Name</label>
                      <input 
                        type="text" 
                        required
                        value={profileContactName}
                        onChange={(e) => setProfileContactName(e.target.value)}
                        className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs text-slate-200 outline-none focus:border-blue-500"
                        placeholder="e.g. Sarah Dupont"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 block mb-1">Emergency Contact Phone</label>
                      <input 
                        type="text" 
                        required
                        value={profileContactPhone}
                        onChange={(e) => setProfileContactPhone(e.target.value)}
                        className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs text-slate-200 outline-none focus:border-blue-500 font-mono"
                        placeholder="e.g. +33 6 9876 5432"
                      />
                    </div>
                  </div>

                  <button 
                    type="submit"
                    disabled={savingProfile}
                    className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase rounded-xl tracking-wider transition-all cursor-pointer flex justify-center items-center space-x-2"
                  >
                    <Check className="h-4 w-4" />
                    <span>{savingProfile ? 'Writing Secure Ledger Update...' : 'Commit Safety Updates to Ledger'}</span>
                  </button>

                </form>
              </div>

            </div>
          )}

          {/* TAB 9: DECENTRALIZED SETTINGS */}
          {activeTab === 'settings' && (
            <div className="space-y-6 py-4">
              <div className={`p-6 rounded-3xl border ${isDark ? 'glass-card' : 'glass-card-light'} space-y-6`}>
                <div>
                  <h3 className="font-extrabold text-sm uppercase tracking-wider text-blue-400 flex items-center space-x-2">
                    <Sliders className="h-4 w-4" />
                    <span>Sovereign Security Configuration</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Manage the technical protocols that govern your offline geofencing parameters, satellite transmission nodes, and in-memory cryptographic state logs.
                  </p>
                </div>

                <div className="grid md:grid-cols-2 gap-6 border-t border-white/5 pt-6">
                  
                  {/* Column 1 settings */}
                  <div className="space-y-4">
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 block mb-2">GPS Polling Update Frequency</label>
                      <select 
                        value={gpsInterval}
                        onChange={(e) => setGpsInterval(e.target.value)}
                        className="w-full px-4 py-2.5 bg-slate-900 border border-white/10 rounded-xl text-xs text-slate-200 outline-none focus:border-blue-500 cursor-pointer"
                      >
                        <option value="5">Real-Time Continuous (Every 5 seconds)</option>
                        <option value="10">Standard Security (Every 10 seconds)</option>
                        <option value="30">Battery Saver Mode (Every 30 seconds)</option>
                        <option value="60">Low Power Conservation (Every 60 seconds)</option>
                      </select>
                      <p className="text-[9px] text-slate-500 mt-1">High frequencies improve geofence alert times but consume slightly more processor battery.</p>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-400 block mb-2">Primary Satellite Network Stream</label>
                      <select 
                        value={satProtocol}
                        onChange={(e) => setSatProtocol(e.target.value)}
                        className="w-full px-4 py-2.5 bg-slate-900 border border-white/10 rounded-xl text-xs text-slate-200 outline-none focus:border-blue-500 cursor-pointer"
                      >
                        <option value="Galileo + GPS Dual">Galileo (EU) + GPS (US) Dual Broadcast</option>
                        <option value="GPS Only">GPS Standard (United States System)</option>
                        <option value="GLONASS + Galileo">GLONASS (RU) + Galileo (EU) Hybrid Channel</option>
                      </select>
                    </div>
                  </div>

                  {/* Column 2 settings */}
                  <div className="space-y-4">
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 block mb-2">Blockchain Ledgers Validation Node</label>
                      <select 
                        value={chainNode}
                        onChange={(e) => setChainNode(e.target.value)}
                        className="w-full px-4 py-2.5 bg-slate-900 border border-white/10 rounded-xl text-xs text-slate-200 outline-none focus:border-blue-500 cursor-pointer"
                      >
                        <option value="Aegis L2 Gasless Rollup">Aegis Layer-2 (Zero-Knowledge Gasless Rollup)</option>
                        <option value="Sepolia Testnet">Ethereum Sepolia (Public Cryptographic Testnet)</option>
                        <option value="Solana Devnet">Solana Sovereign (High Performance Devnet Stream)</option>
                      </select>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-white/5 border border-white/5 rounded-2xl">
                      <div>
                        <span className="text-xs font-bold text-slate-200 block">Simulation Override Feeds</span>
                        <span className="text-[9px] text-slate-500">Inject artificial jitter to test geofencing boundaries.</span>
                      </div>
                      <input 
                        type="checkbox"
                        checked={simulationOverride}
                        onChange={(e) => setSimulationOverride(e.target.checked)}
                        className="h-4 w-4 bg-blue-600 border-white/10 rounded cursor-pointer"
                      />
                    </div>
                  </div>

                </div>

                <div className="border-t border-white/5 pt-6 flex flex-col sm:flex-row justify-between items-center gap-4">
                  <div className="text-left">
                    <span className="text-xs font-bold text-slate-300 block">Erase Local Cache State</span>
                    <span className="text-[10px] text-slate-500 block">Purge stored diagnostic logs and active routes.</span>
                  </div>
                  <button 
                    onClick={() => {
                      setTelemetryLogs([]);
                      alert('Cryptographic local session cache has been securely garbage-collected.');
                    }}
                    className="py-2 px-4 bg-red-950/20 border border-red-500/20 text-red-400 hover:bg-red-950/30 text-xs font-bold rounded-xl transition-all cursor-pointer"
                  >
                    Purge Session Memory
                  </button>
                </div>

              </div>
            </div>
          )}

        </div>
      </main>

      {isSosAlertOpen && (
        <div className="fixed inset-0 bg-red-950/95 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(239,68,68,0.2)_0%,transparent_70%)] animate-pulse"></div>
          
          <div className="max-w-md w-full bg-slate-900 border border-red-500/30 rounded-3xl p-8 relative overflow-hidden text-center space-y-6 shadow-2xl shadow-red-500/20">
            <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-red-500 via-orange-500 to-red-500 animate-pulse"></div>
            
            {/* Flashing Siren Visual */}
            <div className="mx-auto h-20 w-20 rounded-full bg-red-500/10 border-2 border-red-500 flex items-center justify-center text-red-500 relative">
              <span className="absolute inset-0 rounded-full bg-red-500/20 animate-ping"></span>
              <AlertTriangle className="h-10 w-10 animate-bounce" />
            </div>

            <div className="space-y-2">
              <h2 className="text-xl font-black text-red-400 tracking-wider uppercase animate-pulse">
                🚨 EMERGENCY SOS DISPATCHED
              </h2>
              <p className="text-xs text-slate-300 leading-relaxed">
                Your high-priority biometric signature, diagnostic data, and current geographic location have been encrypted and sent to your emergency contacts and local Aegis dispatchers.
              </p>
            </div>

            {/* Dispatch details */}
            <div className="p-4 bg-slate-950/80 rounded-2xl border border-red-500/15 text-left space-y-2.5 text-xs font-mono">
              <div className="flex justify-between items-center text-[10px]">
                <span className="text-slate-500">TRANSMISSION:</span>
                <span className="text-emerald-400 font-bold flex items-center space-x-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                  <span>GPS BROADCAST SENT</span>
                </span>
              </div>

              <div className="border-t border-white/5 pt-2 text-[11px] space-y-1.5">
                <p className="text-slate-300">
                  <span className="text-slate-500 font-bold">LAT:</span> {sosLocationUsed?.lat.toFixed(5)}° N
                </p>
                <p className="text-slate-300">
                  <span className="text-slate-500 font-bold">LNG:</span> {sosLocationUsed?.lng.toFixed(5)}° E
                </p>
              </div>

              <div className="border-t border-white/5 pt-2 text-[10px] space-y-1">
                <p className="text-red-400 font-bold">🚨 SMS PACKET SENT TO EMERGENCY CONTACTS:</p>
                <p className="text-slate-300">Contact: {profileContactName || tourist?.emergencyContactName || 'Sarah Dupont'}</p>
                <p className="text-slate-300">Phone: {profileContactPhone || tourist?.emergencyContactPhone || '+33 6 9876 5432'}</p>
              </div>
            </div>

            <div className="pt-2">
              <p className="text-[10px] text-slate-400">
                A secure peer-to-peer radio connection has been bridged. First responders have been notified of your exact location coordinate stream.
              </p>
            </div>

            <button
              onClick={() => setIsSosAlertOpen(false)}
              className="w-full py-3 bg-red-950 hover:bg-red-900 border border-red-500/30 text-red-200 text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer text-center font-bold"
            >
              Cancel SOS Alert Signal
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
