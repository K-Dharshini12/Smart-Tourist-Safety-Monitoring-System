import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

// Types for our collections
export interface User {
  id: string;
  email: string;
  passwordHash: string;
  role: 'tourist' | 'admin' | 'police' | 'hospital' | 'embassy';
  name: string;
  phone: string;
  nationality?: string;
  passportNumber?: string;
  walletAddress?: string;
  createdAt: string;
}

export interface Tourist {
  userId: string;
  currentLat: number;
  currentLng: number;
  riskScore: number; // AI calculated (0-100)
  riskStatus: 'Safe' | 'Moderate' | 'High';
  safeZoneId: string | null;
  digitalId: string; // Blockchain Digital ID Hash
  verificationQr: string; // Fake base64 QR or text
  blockchainWallet: string;
  status: 'active' | 'in_emergency' | 'offline';
  nationality: string;
  passportNumber: string;
  medicalConditions: string[];
  bloodType: string;
  emergencyContactName: string;
  emergencyContactPhone: string;
  embassyContact: string;
}

export interface Alert {
  id: string;
  type: 'weather' | 'crime' | 'hazard' | 'info';
  title: string;
  description: string;
  severity: 'low' | 'medium' | 'high';
  lat: number;
  lng: number;
  radius: number; // in meters
  active: boolean;
  createdAt: string;
}

export interface SOSAlert {
  id: string;
  touristId: string;
  touristName: string;
  nationality: string;
  lat: number;
  lng: number;
  status: 'pending' | 'accepted' | 'resolved';
  acceptedBy: { id: string; role: 'police' | 'hospital'; name: string } | null;
  medicalInfo: {
    bloodType: string;
    conditions: string[];
  };
  notes: string;
  createdAt: string;
  resolvedAt?: string;
}

export interface SafeZone {
  id: string;
  name: string;
  description: string;
  type: 'safe' | 'danger';
  lat: number;
  lng: number;
  radius: number; // in meters
  creatorId: string;
  createdAt: string;
}

export interface BlockchainRecord {
  txHash: string;
  blockNumber: number;
  timestamp: string;
  type: 'ID_CREATION' | 'IDENTITY_VERIFICATION' | 'SOS_LOG' | 'SECURITY_ALERT';
  details: string;
  walletAddress: string;
}

export interface SupportMessage {
  id: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  message: string;
  createdAt: string;
  read: boolean;
}

export interface ServiceEntity {
  id: string;
  name: string;
  type: 'police' | 'hospital' | 'embassy';
  phone: string;
  address: string;
  lat: number;
  lng: number;
  details?: string;
}

const STORE_FILE_PATH = path.join(process.cwd(), 'data_store.json');

class DataStore {
  users: User[] = [];
  tourists: Record<string, Tourist> = {}; // keyed by userId
  alerts: Alert[] = [];
  sosAlerts: SOSAlert[] = [];
  safeZones: SafeZone[] = [];
  blockchainRecords: BlockchainRecord[] = [];
  supportMessages: SupportMessage[] = [];
  serviceEntities: ServiceEntity[] = [];

  constructor() {
    this.load();
  }

  private load() {
    try {
      if (fs.existsSync(STORE_FILE_PATH)) {
        const raw = fs.readFileSync(STORE_FILE_PATH, 'utf-8');
        const data = JSON.parse(raw);
        this.users = data.users || [];
        this.tourists = data.tourists || {};
        this.alerts = data.alerts || [];
        this.sosAlerts = data.sosAlerts || [];
        this.safeZones = data.safeZones || [];
        this.blockchainRecords = data.blockchainRecords || [];
        this.supportMessages = data.supportMessages || [];
        this.serviceEntities = data.serviceEntities || [];
        console.log('Database loaded successfully from file.');
      } else {
        this.seedInitialData();
        this.save();
      }
    } catch (e) {
      console.error('Error loading database, seeding defaults.', e);
      this.seedInitialData();
      this.save();
    }
  }

  public save() {
    try {
      const data = {
        users: this.users,
        tourists: this.tourists,
        alerts: this.alerts,
        sosAlerts: this.sosAlerts,
        safeZones: this.safeZones,
        blockchainRecords: this.blockchainRecords,
        supportMessages: this.supportMessages,
        serviceEntities: this.serviceEntities
      };
      fs.writeFileSync(STORE_FILE_PATH, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to save data store.', e);
    }
  }

  private hashPassword(password: string): string {
    return crypto.createHash('sha256').update(password).digest('hex');
  }

  private seedInitialData() {
    console.log('Seeding initial system database...');
    // Clear
    this.users = [];
    this.tourists = {};
    this.alerts = [];
    this.sosAlerts = [];
    this.safeZones = [];
    this.blockchainRecords = [];
    this.supportMessages = [];
    this.serviceEntities = [];

    // 1. Seed Default Users (one for each role)
    const roles: Array<'tourist' | 'admin' | 'police' | 'hospital' | 'embassy'> = [
      'tourist', 'admin', 'police', 'hospital', 'embassy'
    ];

    roles.forEach(role => {
      const id = crypto.randomUUID();
      const email = `${role}@safety.com`;
      const walletAddress = '0x' + crypto.randomBytes(20).toString('hex');
      this.users.push({
        id,
        email,
        passwordHash: this.hashPassword(`${role}123`),
        role,
        name: `Global ${role.charAt(0).toUpperCase() + role.slice(1)} Agent`,
        phone: role === 'tourist' ? '+1 (555) 019-2834' : '+1 (555) 999-0000',
        walletAddress,
        nationality: role === 'tourist' ? 'United States' : undefined,
        passportNumber: role === 'tourist' ? 'A9821734' : undefined,
        createdAt: new Date().toISOString()
      });

      if (role === 'tourist') {
        // Create matching tourist record
        const digitalId = '0x' + crypto.randomBytes(32).toString('hex');
        this.tourists[id] = {
          userId: id,
          currentLat: 48.8566, // Paris by default
          currentLng: 2.3522,
          riskScore: 24,
          riskStatus: 'Safe',
          safeZoneId: 'zone-1',
          digitalId,
          verificationQr: `SAFETY-ID-${id.substring(0, 8).toUpperCase()}`,
          blockchainWallet: walletAddress,
          status: 'active',
          nationality: 'United States',
          passportNumber: 'A9821734',
          medicalConditions: ['Penicillin Allergy'],
          bloodType: 'O-Negative',
          emergencyContactName: 'Sarah Jenkins (Spouse)',
          emergencyContactPhone: '+1 (555) 345-6789',
          embassyContact: '+33 1 43 12 22 22 (US Embassy, Paris)'
        };

        // Blockchain Digital ID Creation Tx
        this.blockchainRecords.push({
          txHash: '0x' + crypto.randomBytes(32).toString('hex'),
          blockNumber: 14820129,
          timestamp: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString(),
          type: 'ID_CREATION',
          details: `Immutable Passport Verification & Digital ID Linked for user ${id.substring(0, 6)}...`,
          walletAddress
        });
      }
    });

    // 2. Seed Safe Zones & Danger Zones (Geofences)
    this.safeZones = [
      {
        id: 'zone-1',
        name: 'Champs-Élysées Tourist Safe Zone',
        description: 'Highly monitored main avenue. Heavy police presence, certified tourist help kiosks.',
        type: 'safe',
        lat: 48.8698,
        lng: 2.3075,
        radius: 1200, // 1.2km
        creatorId: 'system',
        createdAt: new Date().toISOString()
      },
      {
        id: 'zone-2',
        name: 'Louvre Museum Security Perimeter',
        description: 'Full perimeter safe zone. Automated SOS assistance dispatch activated.',
        type: 'safe',
        lat: 48.8606,
        lng: 2.3376,
        radius: 800,
        creatorId: 'system',
        createdAt: new Date().toISOString()
      },
      {
        id: 'zone-3',
        name: 'Rue Saint-Denis High Pickpocket Alley',
        description: 'DANGER ZONE: High report frequency of nighttime pickpocketing and minor assaults.',
        type: 'danger',
        lat: 48.8654,
        lng: 2.3508,
        radius: 400,
        creatorId: 'system',
        createdAt: new Date().toISOString()
      }
    ];

    // 3. Seed Alerts
    this.alerts = [
      {
        id: 'alert-1',
        type: 'weather',
        title: 'Severe Thunderstorm & Flash Flood Warning',
        description: 'Heavy torrential rains expected in Paris metropolitan area. Avoid low-lying metro accesses and banks of River Seine.',
        severity: 'high',
        lat: 48.8566,
        lng: 2.3522,
        radius: 5000,
        active: true,
        createdAt: new Date(Date.now() - 2 * 3600 * 1000).toISOString()
      },
      {
        id: 'alert-2',
        type: 'crime',
        title: 'Organized Distraction Theft Alert',
        description: 'Teams of scammers targeting tourists posing as charity petition signers around Montmartre.',
        severity: 'medium',
        lat: 48.8867,
        lng: 2.3431,
        radius: 1000,
        active: true,
        createdAt: new Date(Date.now() - 5 * 3600 * 1000).toISOString()
      }
    ];

    // 4. Seed Nearby Service Entities
    this.serviceEntities = [
      {
        id: 'service-1',
        name: 'Commissariat de Police de Paris (Central Police)',
        type: 'police',
        phone: '+33 1 44 53 80 00',
        address: '19 Rue du Jour, 75001 Paris, France',
        lat: 48.8631,
        lng: 2.3452,
        details: '24/7 tourist incident unit, translator assistance on-duty.'
      },
      {
        id: 'service-2',
        name: 'Hôtel-Dieu Hospital Emergency Center',
        type: 'hospital',
        phone: '+33 1 42 34 82 34',
        address: '1 Parvis Notre-Dame - Pl. Jean-Paul II, 75004 Paris',
        lat: 48.8542,
        lng: 2.3488,
        details: 'Trauma response, immediate emergency dispatch, general triage.'
      },
      {
        id: 'service-3',
        name: 'Embassy of the United States, Paris',
        type: 'embassy',
        phone: '+33 1 43 12 22 22',
        address: '2 Avenue Gabriel, 75008 Paris, France',
        lat: 48.8694,
        lng: 2.3204,
        details: 'Consular crisis center, emergency travel documents replacement.'
      }
    ];

    // 5. Seed Support Messages
    this.supportMessages = [
      {
        id: 'msg-1',
        senderId: 'police',
        senderName: 'Police Dispatch',
        receiverId: 'tourist',
        message: 'Hello, your GPS telemetry shows you are walking towards Rue Saint-Denis, which is currently flagged as a high-crime risk area at night. We recommend sticking to lighted main roads.',
        createdAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
        read: false
      }
    ];

    // 6. Seed a completed SOS for history demonstration
    this.sosAlerts = [
      {
        id: 'sos-1',
        touristId: 'tourist',
        touristName: 'Global Tourist Agent',
        nationality: 'United States',
        lat: 48.8584,
        lng: 2.2945, // near Eiffel Tower
        status: 'resolved',
        acceptedBy: { id: 'police', role: 'police', name: 'Global Police Agent' },
        medicalInfo: {
          bloodType: 'O-Negative',
          conditions: ['Penicillin Allergy']
        },
        notes: 'Tourist reported a lost wallet and suspicious followings. Police units arrived and resolved the concern safely.',
        createdAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
        resolvedAt: new Date(Date.now() - 23.5 * 24 * 3600 * 1000).toISOString()
      }
    ];
  }
}

export const db = new DataStore();
