import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import apiRouter from './server/routes';

// Load environment variables from .env
dotenv.config();

const isProduction = process.env.NODE_ENV === 'production';
const PORT = 3000;

async function startServer() {
  const app = express();

  // Parse JSON payloads
  app.use(express.json());

  // Mount backend API routes
  app.use('/api', apiRouter);

  // Print startup telemetry
  console.log('------------------------------------------------------------');
  console.log('Smart Tourist Safety Monitoring & Response Server initializing...');
  console.log(`Environment Mode: ${isProduction ? 'PRODUCTION' : 'DEVELOPMENT'}`);
  console.log('------------------------------------------------------------');

  if (!isProduction) {
    // Setup Vite development server as middleware
    console.log('Configuring Vite dev server middleware...');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });
    
    app.use(vite.middlewares);

    // Serve HTML using Vite transform
    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      try {
        let template = fs.readFileSync(
          path.resolve(process.cwd(), 'index.html'),
          'utf-8'
        );
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    // Production: Serve pre-built static client files
    const distPath = path.resolve(process.cwd(), 'dist');
    console.log(`Serving static assets in production from: ${distPath}`);
    app.use(express.static(distPath));

    app.use('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Smart Tourist Safety system successfully live at http://localhost:${PORT}`);
  });
}

startServer().catch((error) => {
  console.error('Fatal failure initiating server:', error);
});
