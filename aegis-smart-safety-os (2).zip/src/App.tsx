import React, { useState, useEffect } from 'react';
import { useApp } from './context/AppContext';
import LandingPage from './pages/LandingPage';
import Login from './pages/Login';
import Register from './pages/Register';
import About from './pages/About';
import Features from './pages/Features';
import Services from './pages/Services';
import Contact from './pages/Contact';
import LedgerExplorer from './pages/LedgerExplorer';
import FAQ from './pages/FAQ';
import PrivacyTerms from './pages/PrivacyTerms';
import CommandDeck from './pages/CommandDeck';
import AIControlCenter from './pages/AIControlCenter';
import DigitalPassport from './pages/DigitalPassport';
import LiveAnalytics from './pages/LiveAnalytics';
import TouristDashboard from './pages/dashboards/TouristDashboard';
import AdminDashboard from './pages/dashboards/AdminDashboard';
import PoliceDashboard from './pages/dashboards/PoliceDashboard';
import HospitalDashboard from './pages/dashboards/HospitalDashboard';
import EmbassyDashboard from './pages/dashboards/EmbassyDashboard';

import { 
  Shield, Compass, Cpu, QrCode, TrendingUp, Database, 
  Volume2, Bell, AlertOctagon, User, LogOut, Clock, ShieldAlert,
  Activity, Map, Fingerprint, BarChart2
} from 'lucide-react';

export default function App() {
  const { activePage, setPage, theme, toggleTheme, user, logout, tourist, token } = useApp();
  const isDark = theme === 'dark';

  const [timeStr, setTimeStr] = useState('');
  const [sirenState, setSirenState] = useState(false);

  // Digital clock in header
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString('en-US', { hour12: false }) + ' UTC');
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Flash system warning if a tourist is in emergency state
  const isInEmergency = tourist?.status === 'in_emergency';

  useEffect(() => {
    let interval: any;
    if (isInEmergency) {
      interval = setInterval(() => {
        setSirenState(p => !p);
      }, 500);
    } else {
      setSirenState(false);
    }
    return () => clearInterval(interval);
  }, [isInEmergency]);

  // Helper router for dashboards depending on role
  const renderDashboard = () => {
    if (!user) return <Login />;

    switch (user.role) {
      case 'tourist':
        return <TouristDashboard />;
      case 'admin':
        return <AdminDashboard />;
      case 'police':
        return <PoliceDashboard />;
      case 'hospital':
        return <HospitalDashboard />;
      case 'embassy':
        return <EmbassyDashboard />;
      default:
        return <TouristDashboard />;
    }
  };

  // Skip header layout for authentication screens
  const isAuthPage = ['login', 'register'].includes(activePage);

  // Check if token exists, but user profile is still being loaded
  if (token && !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 text-white">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-blue-500 mx-auto"></div>
          <p className="text-xs font-mono tracking-widest text-slate-400 uppercase">Synchronizing Security Nodes...</p>
        </div>
      </div>
    );
  }

  // If no user, force login or allow register
  if (!user) {
    if (activePage === 'register') {
      return <Register />;
    }
    return <Login />;
  }

  const getPageTitle = () => {
    switch (activePage) {
      case 'landing': return 'Sovereign Hub';
      case 'command-deck': return 'Tactical Map & Geofence';
      case 'ai-control': return 'Aegis AI Risk Core';
      case 'digital-passport': return 'Decentralized Identity';
      case 'live-analytics': return 'Telemetry Analytics';
      default: return 'Safety Shield';
    }
  };

  const renderActivePageContent = () => {
    switch (activePage) {
      case 'landing':
        return <LandingPage />;
      case 'login':
        return <Login />;
      case 'register':
        return <Register />;
      case 'about':
        return <About />;
      case 'features':
        return <Features />;
      case 'services':
        return <Services />;
      case 'contact':
        return <Contact />;
      case 'ledger-explorer':
        return <LedgerExplorer />;
      case 'faq':
        return <FAQ />;
      case 'privacy':
      case 'terms':
        return <PrivacyTerms />;
      case 'command-deck':
        return <CommandDeck />;
      case 'ai-control':
        return <AIControlCenter />;
      case 'digital-passport':
        return <DigitalPassport />;
      case 'live-analytics':
        return <LiveAnalytics />;
      case 'dashboard':
        return renderDashboard();
      default:
        return <LandingPage />;
    }
  };

  if (isAuthPage) {
    return renderActivePageContent();
  }

  return (
    <div className={`min-h-screen flex flex-col transition-colors duration-300 ${isDark ? 'mesh-background text-white' : 'mesh-background-light text-slate-900'}`}>
      
      {/* --- SOVEREIGN UNIFIED HEADER --- */}
      <header className={`sticky top-0 z-50 transition-colors duration-300 border-b backdrop-blur-md ${isDark ? 'glass border-white/10' : 'glass-light border-slate-900/10'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between">
          
          {/* Logo & Platform Name */}
          <div className="flex items-center space-x-3 cursor-pointer select-none" onClick={() => setPage('landing')}>
            <div className={`p-2.5 rounded-2xl shadow-lg transition-all duration-500 relative overflow-hidden group ${isInEmergency ? 'bg-red-600 glow-red animate-pulse' : 'bg-blue-600 glow-blue'}`}>
              <Shield className="h-5.5 w-5.5 text-white relative z-10 transition-transform duration-300 group-hover:rotate-12" />
              <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-indigo-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="font-black text-lg sm:text-xl tracking-tight text-gradient">AEGIS OS</h1>
              </div>
              <span className="text-[9px] uppercase tracking-wider block font-extrabold text-slate-500">TRAVEL SMART. TRAVEL SAFE.</span>
            </div>
          </div>

          {/* Persistent Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1 bg-slate-950/20 p-1 border border-white/5 rounded-2xl">
            {[
              { id: 'landing', label: 'Home Hub', icon: Compass },
              { id: 'command-deck', label: 'Tactical Map', icon: Map },
              { id: 'ai-control', label: 'Aegis AI', icon: Cpu },
              { id: 'digital-passport', label: 'Sovereign ID', icon: Fingerprint },
              { id: 'live-analytics', label: 'Analytics', icon: BarChart2 }
            ].map(tab => {
              const isActive = activePage === tab.id;
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setPage(tab.id)}
                  className={`flex items-center space-x-1.5 px-4 py-2 rounded-xl text-[11px] font-bold uppercase transition-all duration-300 cursor-pointer ${isActive ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'}`}
                >
                  <Icon className="h-3.5 w-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Quick Stats, User profile, and Settings */}
          <div className="flex items-center space-x-3 font-mono">
            
            {/* Live Security Indicator */}
            <div className={`hidden sm:flex items-center space-x-2 px-3 py-1.5 rounded-xl border transition-all duration-300 ${isInEmergency ? 'bg-red-500/10 border-red-500/35 text-red-400' : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'}`}>
              <span className={`h-2 w-2 rounded-full ${isInEmergency ? 'bg-red-500 animate-ping' : 'bg-emerald-500 animate-pulse'}`}></span>
              <span className="text-[10px] font-bold uppercase tracking-wider">
                {isInEmergency ? '🚨 SOS EMERGENCY BROADCAST' : '● ALL NODES SECURE'}
              </span>
            </div>

            {/* Live System Time */}
            <div className="hidden md:flex items-center space-x-1.5 px-3 py-1.5 rounded-xl border border-white/5 bg-slate-950/20 text-[10px] text-slate-400">
              <Clock className="h-3.5 w-3.5 text-blue-400" />
              <span>{timeStr}</span>
            </div>

            {/* Theme Toggle */}
            <button 
              onClick={toggleTheme}
              className={`p-2 rounded-xl border transition-colors cursor-pointer text-xs ${isDark ? 'border-white/10 hover:bg-white/5 text-yellow-400' : 'border-slate-900/10 hover:bg-slate-900/5 text-indigo-900'}`}
              title={isDark ? 'Switch to Light theme' : 'Switch to Dark theme'}
            >
              {isDark ? '☀️' : '🌙'}
            </button>

            {/* Authentication state profile dropdown */}
            {user ? (
              <div className="flex items-center space-x-2 pl-1 border-l border-white/10">
                <div 
                  onClick={() => setPage('dashboard')}
                  className="flex items-center space-x-1.5 bg-blue-500/10 hover:bg-blue-500/15 border border-blue-500/20 px-3 py-1.5 rounded-xl text-blue-400 cursor-pointer text-xs transition-all"
                >
                  <User className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline font-bold truncate max-w-[80px]">{user.name}</span>
                </div>
                <button
                  onClick={logout}
                  className="p-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 rounded-xl cursor-pointer transition-all"
                  title="Disconnect Security Shield Account"
                >
                  <LogOut className="h-3.5 w-3.5" />
                </button>
              </div>
            ) : (
              <button 
                onClick={() => setPage('login')}
                className={`px-4 py-1.5 text-xs font-black rounded-xl border transition-all uppercase tracking-wider cursor-pointer ${isDark ? 'border-white/15 bg-blue-600/10 hover:bg-blue-600/25 border-blue-500/30 text-blue-400' : 'border-slate-900/15 hover:bg-slate-900/5 text-slate-700'}`}
              >
                Log In
              </button>
            )}

          </div>

        </div>
      </header>

      {/* --- MAIN PAGE CONTENT WRAPPER --- */}
      <main className="flex-grow">
        {renderActivePageContent()}
      </main>

      {/* --- FUTURISTIC FLOATING EMERGENCY BEACON --- */}
      {!isAuthPage && activePage !== 'command-deck' && (
        <button
          onClick={() => {
            setPage('command-deck');
            setTimeout(() => {
              const startSOSBtn = document.getElementById('sos-panic-beacon');
              if (startSOSBtn) {
                startSOSBtn.scrollIntoView({ behavior: 'smooth' });
                startSOSBtn.classList.add('scale-110');
                setTimeout(() => startSOSBtn.classList.remove('scale-110'), 1000);
              }
            }, 100);
          }}
          className={`fixed bottom-20 sm:bottom-6 right-6 z-40 p-4 rounded-full shadow-2xl transition-all duration-300 hover:scale-110 flex items-center justify-center cursor-pointer group uppercase font-mono font-bold text-xs ${isInEmergency ? 'bg-red-600 glow-red animate-bounce text-white' : 'bg-red-500/15 border-2 border-red-500/50 text-red-500 hover:bg-red-600 hover:text-white'}`}
          title="INSTANT SOS PANIC ROUTER"
        >
          <div className="absolute inset-0 rounded-full bg-red-500/30 animate-ping"></div>
          <AlertOctagon className="h-6 w-6 relative z-10 animate-pulse mr-1" />
          <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-500 ease-in-out whitespace-nowrap block relative z-10">
            PANIC STATION
          </span>
        </button>
      )}

      {/* --- TOUCH-FRIENDLY BOTTOM NAVIGATION BAR FOR MOBILE DEVICIES --- */}
      {!isAuthPage && (
        <div className={`lg:hidden fixed bottom-0 left-0 right-0 z-50 border-t backdrop-blur-lg px-2 py-1.5 flex justify-around transition-colors duration-300 ${isDark ? 'bg-slate-950/80 border-white/10' : 'bg-white/85 border-slate-900/10'}`}>
          {[
            { id: 'landing', label: 'Hub', icon: Compass },
            { id: 'command-deck', label: 'Map', icon: Map },
            { id: 'ai-control', label: 'AI Risk', icon: Cpu },
            { id: 'digital-passport', label: 'ID DID', icon: Fingerprint },
            { id: 'live-analytics', label: 'Stats', icon: BarChart2 }
          ].map(tab => {
            const isActive = activePage === tab.id;
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setPage(tab.id)}
                className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all duration-300 cursor-pointer ${isActive ? 'text-blue-500 scale-105' : 'text-slate-400 hover:text-slate-300'}`}
              >
                <Icon className={`h-5 w-5 ${isActive ? 'stroke-[2.5px]' : 'stroke-[1.8px]'}`} />
                <span className="text-[9px] font-bold uppercase tracking-wider mt-0.5">{tab.label}</span>
              </button>
            );
          })}
        </div>
      )}

    </div>
  );
}

