import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ArrowLeft, Send, Check, PhoneCall, Mail, MapPin, Shield, Lock, AlertTriangle } from 'lucide-react';

export default function Contact() {
  const { setPage, theme } = useApp();
  const isDark = theme === 'dark';

  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (form.name && form.email && form.message) {
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setForm({ name: '', email: '', message: '' });
      }, 4000);
    }
  };

  const hotlines = [
    { title: 'Police National (FR)', num: '17', desc: 'Active physical threat, crime in progress' },
    { title: 'SAMU (Medical Emergency)', num: '15', desc: 'Severe trauma, cardiac or clinical crises' },
    { title: 'European Emergency Line', num: '112', desc: 'Universal roaming cell-phone emergency dispatch' },
    { title: 'US Embassy Paris', num: '+33 1 43 12 22 22', desc: 'Passport crises, citizen detention or disaster aid' },
    { title: 'UK Embassy Paris', num: '+33 1 44 51 31 00', desc: 'Consular protection for British nationals' }
  ];

  return (
    <div className={`min-h-screen py-16 px-6 transition-colors duration-300 ${isDark ? 'mesh-background text-white' : 'mesh-background-light text-slate-900'}`}>
      <div className="max-w-6xl mx-auto space-y-16">
        
        {/* Navigation back and header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-8">
          <button 
            onClick={() => setPage('landing')}
            className="inline-flex items-center space-x-2 text-sm font-semibold text-blue-500 hover:text-blue-400 cursor-pointer w-fit"
            id="back-to-home-btn"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Return Home</span>
          </button>
          
          <div className="flex items-center space-x-3 text-xs font-mono">
            <span className="opacity-50">DISPATCH CHANNEL:</span>
            <span className="h-2.5 w-2.5 bg-emerald-500 rounded-full animate-pulse"></span>
            <span className="font-extrabold text-emerald-400">ENCRYPTED</span>
          </div>
        </div>

        {/* Header Section */}
        <div className="space-y-4 max-w-3xl">
          <div className="bg-blue-600/10 text-blue-400 px-3 py-1 rounded-full text-xs font-bold w-fit border border-blue-500/20">
            SECURE OPERATIONS CENTER
          </div>
          <h1 className="text-4xl md:text-5xl font-black tracking-tight leading-none">
            Inquire & Connect <br />
            <span className="text-gradient">With Crisis Response HQ</span>
          </h1>
          <p className="text-slate-400 text-sm md:text-base leading-relaxed">
            Need administrative system support, security consultation, or coordinate verification? Access our direct operations lines and send encrypted inquiries to our response team.
          </p>
        </div>

        <div className="grid lg:grid-cols-12 gap-12">
          
          {/* Left Column: Direct Crisis Hotlines */}
          <div className="lg:col-span-5 space-y-8">
            <div className="space-y-4">
              <h2 className="text-2xl font-bold tracking-tight">Direct Emergency Lines</h2>
              <p className="text-xs text-slate-400">
                If you are currently experiencing an active life threat, do not fill the form. Use standard telephony channels to connect with responders immediately.
              </p>
            </div>

            <div className="space-y-4">
              {hotlines.map((h, idx) => (
                <div 
                  key={idx} 
                  className={`p-5 rounded-2xl border flex items-center justify-between ${isDark ? 'border-white/5 bg-slate-900/40' : 'border-slate-900/5 bg-white/50'}`}
                >
                  <div className="space-y-1">
                    <h4 className="font-extrabold text-sm tracking-wide">{h.title}</h4>
                    <p className="text-[11px] text-slate-500">{h.desc}</p>
                  </div>
                  <div className="text-right shrink-0 ml-4">
                    <span className="inline-flex items-center space-x-1.5 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs px-3.5 py-2 rounded-xl">
                      <PhoneCall className="h-3.5 w-3.5" />
                      <span>{h.num}</span>
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Response headquarters address block */}
            <div className={`p-6 rounded-2xl border flex items-start space-x-4 ${isDark ? 'border-white/5 bg-slate-900/10' : 'border-slate-900/5 bg-slate-100/40'}`}>
              <MapPin className="h-5 w-5 text-blue-500 shrink-0 mt-0.5" />
              <div className="text-xs leading-relaxed space-y-1">
                <p className="font-bold">Sentinel Global Operations HQ</p>
                <p className="text-slate-400">22 Rue de la Paix, 75002 Paris, France</p>
                <p className="font-mono text-[10px] text-slate-500">Coordinates: 48.8681° N, 2.3304° E • GMT+1</p>
              </div>
            </div>
          </div>

          {/* Right Column: Encrypted Form */}
          <div className={`lg:col-span-7 p-8 md:p-10 rounded-3xl border relative ${isDark ? 'glass-card' : 'glass-card-light'}`}>
            <div className="absolute top-6 right-6 flex items-center space-x-2 text-[10px] font-mono text-blue-400 bg-blue-500/10 px-2.5 py-1 rounded-full border border-blue-500/20">
              <Lock className="h-3.5 w-3.5" />
              <span>AES-256 ENCRYPTED</span>
            </div>

            <h3 className="text-xl font-bold mb-6">Operations Message Dispatch</h3>

            {submitted ? (
              <div className="text-center py-16 space-y-4">
                <div className="bg-emerald-500/20 p-5 rounded-full w-fit mx-auto text-emerald-400">
                  <Check className="h-10 w-10" />
                </div>
                <h4 className="font-bold text-lg text-slate-200">Transmission Successful</h4>
                <p className="text-slate-400 text-xs max-w-sm mx-auto leading-relaxed">
                  Your inquiry message has been securely compiled and recorded on our network buffer. An operations officer will reach out within 15 minutes.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="text-[10px] font-mono uppercase text-slate-400 block mb-2 tracking-wider">Your Full Name</label>
                    <input 
                      type="text" 
                      required
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none text-xs text-slate-200"
                      placeholder="e.g. Alexis Carter"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono uppercase text-slate-400 block mb-2 tracking-wider">Email Address</label>
                    <input 
                      type="email" 
                      required
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none text-xs text-slate-200"
                      placeholder="e.g. alexis@domain.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-mono uppercase text-slate-400 block mb-2 tracking-wider">Crisis Inquiry Message</label>
                  <textarea 
                    rows={5}
                    required
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none text-xs text-slate-200"
                    placeholder="Describe your security status, coordinate discrepancy, or administrative inquiry..."
                  />
                </div>

                <div className={`p-4 rounded-xl border flex items-start space-x-3 text-xs leading-relaxed ${isDark ? 'border-blue-500/20 bg-blue-500/5' : 'border-blue-500/10 bg-blue-50/50'}`}>
                  <AlertTriangle className="h-5 w-5 text-blue-400 shrink-0 mt-0.5" />
                  <p className="text-slate-400">
                    By transmitting this inquiry, your message is validated with a transient timestamp hash. No personal tracking details or browser sessions are collected.
                  </p>
                </div>

                <button 
                  type="submit"
                  className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl flex items-center justify-center space-x-2.5 transition-all cursor-pointer glow-blue"
                >
                  <Send className="h-4 w-4" />
                  <span>Transmit Encrypted Dispatch</span>
                </button>
              </form>
            )}
          </div>

        </div>

      </div>
    </div>
  );
}
