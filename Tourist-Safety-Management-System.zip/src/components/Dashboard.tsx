import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Shield, Navigation, Radio, Compass, AlertTriangle, ShieldCheck, HeartPulse, 
  MapPin, Loader2, Zap, Send, PhoneCall, History, TrendingUp, BarChart2, 
  Calendar, CheckCircle, Award, ShieldAlert 
} from "lucide-react";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { AppScreen, TouristProfile, JourneyState, AISafetyAssessment, SOSBeacon, RescueOperation, TripHistoryItem } from "../types";

// Lightweight count-up animation used by the statistics cards below.
function AnimatedCounter({ value, decimals = 0 }: { value: number; decimals?: number }) {
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    let frame: number;
    const duration = 900;
    const start = performance.now();

    const tick = (now: number) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(value * eased);
      if (progress < 1) frame = requestAnimationFrame(tick);
    };

    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [value]);

  return <>{display.toFixed(decimals)}</>;
}

interface DashboardProps {
  profile: TouristProfile;
  onNavigate: (screen: AppScreen) => void;
  sosBeacon: SOSBeacon;
  onTriggerSOS: (lat: number, lng: number) => void;
  onCancelSOS: () => void;
  rescueOperation: RescueOperation;
}

export default function Dashboard({
  profile,
  onNavigate,
  sosBeacon,
  onTriggerSOS,
  onCancelSOS,
  rescueOperation,
}: DashboardProps) {
  // Journey state
  const [journey, setJourney] = useState<JourneyState>({
    active: false,
    startTime: null,
    lat: 46.0207,
    lng: 7.7491,
    centerLat: 46.0207,
    centerLng: 7.7491,
    geoFenceRadiusKm: 1.5,
    terrain: "Alpine Mountain Trek",
    outOfBounds: false,
  });

  // Trip History log state
  const [tripHistory, setTripHistory] = useState<TripHistoryItem[]>([
    {
      id: "TRIP-005",
      terrain: "Alpine Mountain High Glaciers",
      date: "July 18, 2026",
      duration: "4h 30m",
      distanceCoveredKm: 10.5,
      maxRiskLevel: 65,
      status: "DANGER",
    },
    {
      id: "TRIP-004",
      terrain: "Historic Tokyo Urban Explorer",
      date: "July 17, 2026",
      duration: "2h 15m",
      distanceCoveredKm: 6.1,
      maxRiskLevel: 9,
      status: "SAFE",
    },
    {
      id: "TRIP-003",
      terrain: "Sahara Dunes Deep Trek",
      date: "July 16, 2026",
      duration: "5h 10m",
      distanceCoveredKm: 12.4,
      maxRiskLevel: 45,
      status: "WARNING",
    },
    {
      id: "TRIP-002",
      terrain: "Coastal Cliff Overlook Path",
      date: "July 15, 2026",
      duration: "1h 50m",
      distanceCoveredKm: 4.5,
      maxRiskLevel: 18,
      status: "SAFE",
    },
    {
      id: "TRIP-001",
      terrain: "Alpine Mountain Ridge Trail",
      date: "July 14, 2026",
      duration: "3h 45m",
      distanceCoveredKm: 8.2,
      maxRiskLevel: 12,
      status: "SAFE",
    },
  ]);

  // Travel frequency and distance statistics
  const [dailyStats, setDailyStats] = useState([
    { day: "Mon 07/13", trips: 1, distance: 8.2 },
    { day: "Tue 07/14", trips: 1, distance: 4.5 },
    { day: "Wed 07/15", trips: 1, distance: 12.4 },
    { day: "Thu 07/16", trips: 1, distance: 6.1 },
    { day: "Fri 07/17", trips: 1, distance: 10.5 },
    { day: "Sat 07/18", trips: 0, distance: 0 },
    { day: "Sun 07/19", trips: 0, distance: 0 }, // today
  ]);

  // Handle Complete Journey & Save to Logbook
  const handleCompleteJourney = () => {
    if (!journey.active) return;

    // Simulate duration and distance covered based on current selection
    const generatedDistance = parseFloat((Math.random() * 3.5 + 2.0).toFixed(1)); // 2.0 to 5.5 km
    const hours = Math.floor(Math.random() * 2) + 1;
    const mins = Math.floor(Math.random() * 60);
    const durationStr = `${hours}h ${mins}m`;
    const todayStr = "July 19, 2026";
    const nextId = `TRIP-00${tripHistory.length + 1}`;

    const newTrip: TripHistoryItem = {
      id: nextId,
      terrain: journey.terrain,
      date: todayStr,
      duration: durationStr,
      distanceCoveredKm: generatedDistance,
      maxRiskLevel: aiReport.riskLevel,
      status: aiReport.status,
    };

    setTripHistory(prev => [newTrip, ...prev]);

    // Add to dailyStats
    setDailyStats(prev => {
      return prev.map(item => {
        if (item.day === "Sun 07/19") {
          return {
            ...item,
            trips: item.trips + 1,
            distance: parseFloat((item.distance + generatedDistance).toFixed(1)),
          };
        }
        return item;
      });
    });

    addLog(`[SYSTEM] Expedition successfully finalized. Secure log archived as ID ${nextId}.`);
    addLog(`[SYSTEM] Metrics captured: Duration: ${durationStr} | Distance Covered: ${generatedDistance} km.`);

    setJourney(prev => ({
      ...prev,
      active: false,
      startTime: null,
      outOfBounds: false,
    }));
  };

  // Terrain preset configurations
  const terrainPresets = [
    { name: "Alpine Mountain Trek", centerLat: 46.0207, centerLng: 7.7491, radius: 1.2 },
    { name: "Coastal Shore Explorer", centerLat: -34.0254, centerLng: 151.1982, radius: 1.8 },
    { name: "Sahara Desert Crossing", centerLat: 24.8864, centerLng: -0.1276, radius: 2.5 },
    { name: "Historic City Core", centerLat: 35.6762, centerLng: 139.6503, radius: 0.8 }
  ];

  // AI evaluation
  const [aiReport, setAiReport] = useState<AISafetyAssessment>({
    status: "SAFE",
    riskLevel: 8,
    summary: "Secured under active geo-fencing tracking.",
    dangerDetails: "AEGIS telemetry is locked on steady coordinates. Surrounding terrain verified safe.",
    environmentalHazards: ["Sudden weather change"],
    recommendations: ["Maintain normal travel velocity", "Check water supplies regularly"],
    alertTitle: "AEGIS SECURED",
  });
  const [aiLoading, setAiLoading] = useState(false);
  const [telemetryLogs, setTelemetryLogs] = useState<string[]>([]);
  const logContainerRef = useRef<HTMLDivElement>(null);

  // Auto-scroll logs
  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [telemetryLogs]);

  // Handle terrain transition
  const handleTerrainChange = (terrainName: string) => {
    const preset = terrainPresets.find(p => p.name === terrainName);
    if (!preset) return;
    
    setJourney(prev => {
      const updated = {
        ...prev,
        terrain: preset.name,
        centerLat: preset.centerLat,
        centerLng: preset.centerLng,
        lat: preset.centerLat,
        lng: preset.centerLng,
        geoFenceRadiusKm: preset.radius,
        outOfBounds: false
      };
      
      // Update logs
      addLog(`[GEOSHILD] Terrain switched to: ${preset.name}`);
      addLog(`[GEOSHILD] Centered coordinates at Lat ${preset.centerLat.toFixed(4)}, Lng ${preset.centerLng.toFixed(4)}`);
      
      return updated;
    });
  };

  const addLog = (msg: string) => {
    const stamp = new Date().toLocaleTimeString();
    setTelemetryLogs(prev => [...prev, `[${stamp}] ${msg}`]);
  };

  // Start active journey
  const handleStartJourney = () => {
    // Request simulated GPS location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          addLog("[GPS] Browser hardware GPS handshake complete.");
        },
        (error) => {
          addLog("[GPS] Permission prompt bypassed. Utilizing high-fidelity simulated satellite GPS.");
        }
      );
    }

    setJourney(prev => ({
      ...prev,
      active: true,
      startTime: new Date().toLocaleTimeString()
    }));

    addLog(`[SYSTEM] Safety Shield Initialized for ${profile.name}.`);
    addLog(`[GEOSHILD] Geo-fence boundary configured: ${journey.geoFenceRadiusKm}km perimeter.`);
    addLog("[AI-CORE] Safety analytics listening on server endpoint...");
  };

  // Move coordinates on radar click
  const handleRadarClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!journey.active) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left; // relative pixels
    const y = e.clientY - rect.top;

    // Convert pixels (0 to 300) to delta offset (-3.0 to +3.0 km equivalent)
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const dx = (x - centerX) / (rect.width / 2); // -1.0 to 1.0
    const dy = (centerY - y) / (rect.height / 2); // -1.0 to 1.0 (positive is up)

    // Dynamic multiplier depending on chosen radius
    const latDelta = dy * 0.03 * journey.geoFenceRadiusKm;
    const lngDelta = dx * 0.04 * journey.geoFenceRadiusKm;

    const newLat = journey.centerLat + latDelta;
    const newLng = journey.centerLng + lngDelta;

    updateCoordinates(newLat, newLng);
  };

  // Standard preset navigational pathways to easily showcase Safe/Danger
  const triggerCoordinatePreset = (type: "safe" | "off-trail" | "boundary-exit") => {
    if (!journey.active) return;
    let deltaLat = 0;
    let deltaLng = 0;

    switch (type) {
      case "safe":
        deltaLat = 0.0012;
        deltaLng = -0.0008;
        addLog("[NAVIGATION] Path preset loaded: Safe Nature Trail.");
        break;
      case "off-trail":
        deltaLat = 0.0068;
        deltaLng = 0.0084;
        addLog("[NAVIGATION] Path preset loaded: Stray Off-Trail / Steeps.");
        break;
      case "boundary-exit":
        deltaLat = 0.0212;
        deltaLng = -0.0245;
        addLog("[NAVIGATION] Path preset loaded: Exceeded Protected Boundaries.");
        break;
    }

    updateCoordinates(journey.centerLat + deltaLat, journey.centerLng + deltaLng);
  };

  // Unified coordinate update with distance calculation and AI triggers
  const updateCoordinates = (lat: number, lng: number) => {
    // Calculate distance from center (approximate equirectangular projection distance in km)
    const R = 6371; // km
    const dLat = ((lat - journey.centerLat) * Math.PI) / 180;
    const dLng = ((lng - journey.centerLng) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((journey.centerLat * Math.PI) / 180) *
        Math.cos((lat * Math.PI) / 180) *
        Math.sin(dLng / 2) *
        Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distanceKm = R * c;

    const outOfBounds = distanceKm > journey.geoFenceRadiusKm;

    setJourney(prev => ({
      ...prev,
      lat,
      lng,
      outOfBounds
    }));

    addLog(`[GPS] Coordinate updated: Lat ${lat.toFixed(5)}°, Lng ${lng.toFixed(5)}°`);
    addLog(`[GEOSHILD] Distance to focal center: ${distanceKm.toFixed(3)}km.`);
    
    if (outOfBounds) {
      addLog("[ALARM] Out of safe perimeter! Geo-fence breached.");
    } else {
      addLog("[GEOSHILD] Boundary integrity verified. Secure.");
    }
  };

  // Run AI analysis on coordinate or bounds change
  useEffect(() => {
    if (!journey.active) return;

    const queryAISafety = async () => {
      setAiLoading(true);
      addLog("[AI-CORE] Fetching server-side safety diagnostics from Gemini...");

      try {
        const response = await fetch("/api/safety-check", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            lat: journey.lat,
            lng: journey.lng,
            terrain: journey.terrain,
            outOfBounds: journey.outOfBounds,
            userStatus: sosBeacon.active ? "USER ACTIVATED URGENT SOS BEACON DISASTER SIGNAL" : "Exploring normally"
          })
        });

        const data = await response.json();
        
        // Handle fallback structure from backend or direct API output
        const report = data.fallback ? data.fallback : data;
        setAiReport(report);
        addLog(`[AI-CORE] Evaluation returned: STATUS ${report.status} | RISK LEVEL ${report.riskLevel}%`);
      } catch (error) {
        console.error("AI check error", error);
        addLog("[AI-CORE] Server safety verification failed. Triggering edge-node diagnostic backup.");
      } finally {
        setAiLoading(false);
      }
    };

    // Debounce safety fetch slightly to avoid slamming API during fast drag/clicks
    const timeout = setTimeout(queryAISafety, 800);
    return () => clearTimeout(timeout);
  }, [journey.lat, journey.lng, journey.terrain, journey.outOfBounds, sosBeacon.active]);

  // Trigger SOS Beacon
  const triggerSOSBeacon = () => {
    onTriggerSOS(journey.lat, journey.lng);
    addLog("[SOS] Distress Beacon launched! Broadcasting Digital ID and Live GPS...");
    addLog("[SOS] Dispatching beacon to Rescue Command Center...");
  };

  return (
    <div className={`relative min-h-screen bg-white text-gray-100 flex flex-col font-sans transition-colors duration-1000 ${
      journey.outOfBounds ? "animate-sos-flash" : ""
    }`}>
      {/* Background travel image with gradient overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-15 mix-blend-overlay pointer-events-none"
        style={{ backgroundImage: `url('/src/assets/images/travel_background_1784446490513.jpg')` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#020817]/95 via-[#03132e]/95 to-[#020817] pointer-events-none" />
      <div className="absolute inset-0 grid-bg opacity-15 pointer-events-none" />

      {/* Main HUD Nav bar */}
      <header className="relative z-10 max-w-7xl w-full mx-auto px-6 py-4 flex items-center justify-between border-b border-cyan-600/10 backdrop-blur-md">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <div className={`absolute -inset-1 rounded-lg blur opacity-75 ${journey.outOfBounds ? "bg-red-500" : "bg-cyan-600/30"}`} />
            <div className="relative bg-[#0b1d3a] p-1.5 rounded-lg border border-cyan-500/20 flex items-center justify-center">
              <Shield className={`h-5 w-5 ${journey.outOfBounds ? "text-red-400" : "text-cyan-500"}`} />
            </div>
          </div>
          <div>
            <span className="font-display font-black text-lg tracking-wider text-white">AEGIS</span>
            <span className="text-[9px] font-mono block text-cyan-500/60 leading-none">TOURIST SAFETY CONSOLE</span>
          </div>
        </div>

        {/* Global Navigation System Status Badge */}
        <div className="hidden md:flex items-center space-x-2 bg-emerald-950/40 border border-emerald-500/30 px-3 py-1.5 rounded-full shadow-[0_0_12px_rgba(16,185,129,0.15)] animate-pulse">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="text-[10px] font-mono font-bold text-emerald-400 tracking-widest uppercase">
            NAVIGATION SYSTEM ONLINE
          </span>
        </div>

        {/* Tourist Biometrics badge and Admin Button */}
        <div className="flex items-center space-x-4">
          <button
            id="go_to_admin_panel_btn"
            onClick={() => onNavigate("admin")}
            className={`flex items-center space-x-2 text-xs font-mono border px-3.5 py-1.5 rounded-md transition-all cursor-pointer ${
              sosBeacon.active
                ? "border-red-500/50 bg-red-950/40 text-red-400 hover:bg-red-900/40 hover:text-white shadow-[0_0_10px_rgba(239,68,68,0.2)]"
                : "border-cyan-600/20 bg-cyan-950/20 text-cyan-500 hover:text-white hover:border-cyan-600/50"
            }`}
          >
            {sosBeacon.active && <span className="h-2 w-2 rounded-full bg-red-500 animate-ping" />}
            <ShieldAlert className="h-4 w-4" />
            <span>AEGIS CONTROL HQ</span>
          </button>

          <div className="flex items-center space-x-3 bg-cyan-950/30 border border-cyan-600/15 p-1.5 rounded-xl pr-4">
            <img
              src={profile.avatarUrl}
              alt={profile.name}
              referrerPolicy="no-referrer"
              className="h-8 w-8 rounded-full object-cover border border-cyan-500/40"
            />
            <div>
              <p className="text-xs font-bold leading-none text-white uppercase">{profile.name.split(" ")[0]}</p>
              <p className="text-[8px] font-mono text-cyan-500 mt-0.5">{profile.touristId}</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="relative z-10 flex-grow max-w-7xl w-full mx-auto px-6 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        
        {/* Left Side: Journey Setup and Tactile GPS Radar Map (7 cols) */}
        <div className="lg:col-span-7 flex flex-col space-y-8">
          
          {/* Journey Controls Panel */}
          <div className="glass-card rounded-2xl p-6 relative">
            <h3 className="text-sm font-display font-extrabold text-white mb-4 uppercase tracking-widest flex items-center gap-2">
              <Compass className="h-4.5 w-4.5 text-cyan-500" />
              1. Voyage Parameters
            </h3>

            {!journey.active ? (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[9px] font-mono text-cyan-500/80 mb-1.5 uppercase">
                      Select Navigation Terrain
                    </label>
                    <select
                      id="dashboard_terrain_select"
                      value={journey.terrain}
                      onChange={(e) => handleTerrainChange(e.target.value)}
                      className="w-full px-3 py-3 bg-[#0a182f] border border-cyan-600/25 rounded-xl font-sans text-xs text-white focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none"
                    >
                      {terrainPresets.map((t) => (
                        <option key={t.name} value={t.name}>
                          {t.name} (Perimeter: {t.radius}km)
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[9px] font-mono text-cyan-500/80 mb-1.5 uppercase">
                      Tourist Registry Token
                    </label>
                    <div className="px-3 py-3 bg-cyan-950/20 border border-cyan-600/10 rounded-xl font-mono text-xs text-cyan-500 font-bold">
                      {profile.touristId}
                    </div>
                  </div>
                </div>

                <button
                  id="start_journey_btn"
                  onClick={handleStartJourney}
                  className="w-full py-4 bg-gradient-to-r from-cyan-500 to-blue-900 hover:from-cyan-400 hover:to-blue-800 text-white font-display font-black text-sm rounded-xl transition-all flex items-center justify-center space-x-2 tracking-wider shadow-[0_0_15px_rgba(6,182,212,0.2)] cursor-pointer"
                >
                  <Navigation className="h-4.5 w-4.5" />
                  <span>START EXPEDITION JOURNEY</span>
                </button>
              </div>
            ) : (
              <div className="flex flex-col space-y-4">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-cyan-950/25 border border-cyan-600/15 p-4 rounded-xl">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
                      <p className="text-xs font-mono font-extrabold text-emerald-400 uppercase tracking-widest">Active Safety Shield</p>
                    </div>
                    <h4 className="text-sm font-display font-bold mt-1 text-white">{journey.terrain}</h4>
                    <p className="text-[10px] font-mono text-gray-400 mt-1">Geo-Fence focal limit: {journey.geoFenceRadiusKm}km</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button
                      id="preset_path_safe_btn"
                      onClick={() => triggerCoordinatePreset("safe")}
                      className="px-3 py-1.5 bg-emerald-950/40 text-emerald-400 hover:bg-emerald-900/40 border border-emerald-500/20 text-[10px] font-mono rounded cursor-pointer"
                    >
                      PRESET: SAFE NATURE PATH
                    </button>
                    <button
                      id="preset_path_off_trail_btn"
                      onClick={() => triggerCoordinatePreset("off-trail")}
                      className="px-3 py-1.5 bg-amber-950/40 text-amber-400 hover:bg-amber-900/40 border border-amber-500/20 text-[10px] font-mono rounded cursor-pointer"
                    >
                      PRESET: STRAY OFF-TRAIL
                    </button>
                    <button
                      id="preset_path_breach_btn"
                      onClick={() => triggerCoordinatePreset("boundary-exit")}
                      className="px-3 py-1.5 bg-red-950/40 text-red-400 hover:bg-red-900/40 border border-red-500/20 text-[10px] font-mono rounded cursor-pointer"
                    >
                      PRESET: EXIT BOUNDARY
                    </button>
                  </div>
                </div>

                <button
                  id="complete_journey_action_btn"
                  onClick={handleCompleteJourney}
                  className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-black font-display font-black text-xs tracking-wider rounded-xl transition-all flex items-center justify-center space-x-2 shadow-[0_0_15px_rgba(16,185,129,0.15)] cursor-pointer"
                >
                  <CheckCircle className="h-4.5 w-4.5" />
                  <span>COMPLETE EXPEDITION & RECORD TRIP LOG</span>
                </button>
              </div>
            )}
          </div>

          {/* Interactive Satellite Radar & Map Console */}
          <div className="glass-card rounded-2xl p-6 flex flex-col justify-between flex-grow h-[420px] relative">
            <h3 className="text-sm font-display font-extrabold text-white mb-4 uppercase tracking-widest flex items-center gap-2">
              <Radio className="h-4.5 w-4.5 text-cyan-500 animate-pulse" />
              2. Tactical GPS Radar Interface
            </h3>

            {!journey.active ? (
              <div className="flex-grow flex flex-col items-center justify-center text-center p-6 bg-slate-950/40 rounded-xl border border-cyan-600/5 relative overflow-hidden">
                {/* Subtle scanning visual glow */}
                <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/5 via-transparent to-transparent pointer-events-none" />
                <div className="relative mb-3">
                  <div className="absolute -inset-2 bg-emerald-500/10 rounded-full blur animate-pulse" />
                  <MapPin className="h-10 w-10 text-emerald-400 relative z-10 animate-bounce" />
                </div>
                <p className="font-display font-bold text-emerald-400 text-sm tracking-wider uppercase flex items-center justify-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping inline-block" />
                  Navigation System Online
                </p>
                <p className="text-gray-400 text-[11px] max-w-xs mt-2 leading-relaxed">
                  Satellite telemetry links are established. Standard planetary GPS array is active. Start your expedition journey above to map real-time tracking streams.
                </p>
              </div>
            ) : (
              <div className="flex-grow grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch h-full">
                {/* Tactical Radar Display (SVG Map Simulation) */}
                <div className="md:col-span-2 bg-[#020c1b] rounded-xl border border-cyan-600/15 p-4 flex flex-col justify-between relative overflow-hidden">
                  
                  {/* Radar rotating sweep line */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="h-full w-full max-h-[300px] max-w-[300px] border border-cyan-500/5 rounded-full relative animate-radar overflow-hidden">
                      <div className="absolute top-0 left-1/2 w-1/2 h-1/2 origin-bottom-left bg-gradient-to-tr from-cyan-500/10 to-transparent skew-x-12" />
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[10px] font-mono text-cyan-500">
                    <span>SATELLITE SYNC LOCK: TRUE</span>
                    <span className="animate-pulse">GEOSHILD SCANNING</span>
                  </div>

                  {/* SVG Tactile click console */}
                  <div className="relative flex-grow flex items-center justify-center py-4 cursor-crosshair">
                    <svg 
                      onClick={handleRadarClick}
                      viewBox="0 0 300 300" 
                      className="w-full h-full max-h-[220px] max-w-[220px] bg-cyan-950/5 rounded-full border border-cyan-600/15"
                    >
                      {/* Grid concentric rings */}
                      <circle cx="150" cy="150" r="130" fill="none" stroke="rgba(6, 182, 212, 0.05)" strokeWidth="1" />
                      <circle cx="150" cy="150" r="90" fill="none" stroke="rgba(6, 182, 212, 0.08)" strokeWidth="1" />
                      <circle cx="150" cy="150" r="50" fill="none" stroke="rgba(6, 182, 212, 0.12)" strokeWidth="1" />
                      
                      {/* Grid Crosshairs */}
                      <line x1="150" y1="0" x2="150" y2="300" stroke="rgba(6, 182, 212, 0.07)" strokeWidth="1" />
                      <line x1="0" y1="150" x2="300" y2="150" stroke="rgba(6, 182, 212, 0.07)" strokeWidth="1" />

                      {/* Dynamic Geo-Fencing circle (Safe perimeter limit) */}
                      {/* Let's draw it based on standard radius mapping, say r=90 represents geoFenceRadiusKm limit */}
                      <circle 
                        cx="150" 
                        cy="150" 
                        r="90" 
                        fill="rgba(6, 182, 212, 0.01)" 
                        stroke={journey.outOfBounds ? "rgba(239, 68, 68, 0.45)" : "rgba(6, 182, 212, 0.45)"} 
                        strokeWidth="1.5" 
                        strokeDasharray={journey.outOfBounds ? "0" : "5, 4"}
                        className={journey.outOfBounds ? "" : "animate-pulse"}
                      />

                      {/* Safe Perimeter label indicator */}
                      <text x="155" y="55" fill={journey.outOfBounds ? "#f87171" : "#06B6D4"} fontSize="7" fontFamily="monospace" opacity="0.8">
                        PERIMETER LIMIT: {journey.geoFenceRadiusKm}KM
                      </text>

                      {/* Central Anchored focal tracking center */}
                      <circle cx="150" cy="150" r="3.5" fill="#38bdf8" />
                      <circle cx="150" cy="150" r="7" fill="none" stroke="#38bdf8" strokeWidth="0.8" className="animate-ping" />

                      {/* Map Terrain abstract graphics */}
                      <path d="M 60 120 Q 80 90 100 130 T 140 100" fill="none" stroke="rgba(6, 182, 212, 0.04)" strokeWidth="2" />
                      <path d="M 180 220 Q 200 190 220 240 T 260 210" fill="none" stroke="rgba(6, 182, 212, 0.04)" strokeWidth="2" />

                      {/* Dynamic Tourist Tracker Dot */}
                      {/* Calculate coordinates: scale delta Lat/Lng into pixel offsets */}
                      {(() => {
                        const latOffset = ((journey.lat - journey.centerLat) / (0.03 * journey.geoFenceRadiusKm)) * 90;
                        const lngOffset = ((journey.lng - journey.centerLng) / (0.04 * journey.geoFenceRadiusKm)) * 90;
                        
                        // Bound within limits of chart circle slightly
                        const clampedX = Math.max(10, Math.min(290, 150 + lngOffset));
                        const clampedY = Math.max(10, Math.min(290, 150 - latOffset)); // Y goes down on SVG
                        
                        return (
                          <g>
                            {/* Pulse background */}
                            <circle 
                              cx={clampedX} 
                              cy={clampedY} 
                              r="10" 
                              fill={journey.outOfBounds ? "rgba(239, 68, 68, 0.35)" : "rgba(34, 197, 94, 0.35)"} 
                              className="animate-locator" 
                            />
                            {/* Tracker core dot */}
                            <circle 
                              cx={clampedX} 
                              cy={clampedY} 
                              r="4.5" 
                              fill={journey.outOfBounds ? "#ef4444" : "#22c55e"} 
                              stroke="#ffffff" 
                              strokeWidth="1" 
                            />
                          </g>
                        );
                      })()}
                    </svg>
                  </div>

                  <div className="text-[9px] font-mono text-cyan-500/50 flex justify-between">
                    <span>* TAP RADAR TO SIMULATE TRAVEL COORDS</span>
                    <span>AZIMUTH CONSOLE RE-LOCKED</span>
                  </div>
                </div>

                {/* Telemetry Logger Feed (Terminal style) */}
                <div className="bg-[#020b18] rounded-xl border border-cyan-600/15 p-4 flex flex-col h-full">
                  <span className="text-[10px] font-mono text-cyan-500 border-b border-cyan-600/10 pb-1.5 mb-2 block font-extrabold uppercase tracking-wider">
                    🛰️ Active Telemetry Log
                  </span>
                  <div 
                    ref={logContainerRef}
                    className="flex-grow overflow-y-auto font-mono text-[9px] text-cyan-500/80 space-y-1.5 scrollbar-thin scrollbar-thumb-cyan-900 pr-1 h-[220px]"
                  >
                    {telemetryLogs.map((log, index) => (
                      <div key={index} className="leading-relaxed border-l border-cyan-600/15 pl-1.5">
                        {log}
                      </div>
                    ))}
                    {telemetryLogs.length === 0 && (
                      <div className="text-gray-600 text-center py-10">
                        System telemetry pending handshake...
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Gemini AI Safety Hub & SOS Distress Center (5 cols) */}
        <div className="lg:col-span-5 flex flex-col space-y-8">
          
          {/* AI Safety Assessment Core Panel */}
          <div className="glass-card rounded-2xl p-6 flex flex-col h-full justify-between relative overflow-hidden">
            {/* If AI is evaluation or outOfBounds, glowing neon side panel */}
            <div className={`absolute left-0 inset-y-0 w-[4px] ${
              journey.outOfBounds ? "bg-red-500 shadow-[0_0_10px_#ef4444]" : "bg-emerald-500 shadow-[0_0_10px_#22c55e]"
            }`} />

            <div>
              <div className="flex items-center justify-between mb-4 border-b border-cyan-600/10 pb-3">
                <h3 className="text-sm font-display font-extrabold text-white uppercase tracking-widest flex items-center gap-2">
                  <ShieldCheck className="h-4.5 w-4.5 text-cyan-500" />
                  3. Gemini AI Safety Shield
                </h3>
                {aiLoading && <Loader2 className="h-4 w-4 text-cyan-500 animate-spin" />}
              </div>

              {/* Security diagnostic results depending on coordinates */}
              <AnimatePresence mode="wait">
                <motion.div
                  key={aiReport.status + String(aiLoading)}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-5"
                >
                  {/* Status Banner */}
                  <div className={`p-4 rounded-xl border flex items-center space-x-3.5 ${
                    journey.outOfBounds 
                      ? "bg-red-950/30 border-red-500/30 text-red-200" 
                      : "bg-emerald-950/20 border-emerald-500/20 text-emerald-200"
                  }`}>
                    {journey.outOfBounds ? (
                      <div className="p-2 bg-red-900/30 border border-red-500/30 rounded-lg shrink-0">
                        <AlertTriangle className="h-6 w-6 text-red-400 animate-bounce" />
                      </div>
                    ) : (
                      <div className="p-2 bg-emerald-900/30 border border-emerald-500/30 rounded-lg shrink-0">
                        <ShieldCheck className="h-6 w-6 text-emerald-400 animate-pulse" />
                      </div>
                    )}
                    <div>
                      <p className="text-[10px] font-mono tracking-wider opacity-60">AI SAFETY METRIC</p>
                      <h4 className="font-display font-black text-sm uppercase tracking-wide">
                        {journey.outOfBounds ? "DANGER ZONE ALARM" : "SAFE ZONE VERIFIED"}
                      </h4>
                      <p className="text-[10px] opacity-85 mt-0.5 leading-snug">{aiReport.summary}</p>
                    </div>
                  </div>

                  {/* Core details */}
                  <div className="space-y-4">
                    <div>
                      <p className="text-[10px] font-mono text-cyan-500/60 uppercase">Dynamic Risk Level</p>
                      <div className="flex items-center space-x-3 mt-1.5">
                        <div className="flex-grow bg-cyan-950/40 border border-cyan-600/10 h-2.5 rounded-full overflow-hidden">
                          <div 
                            className={`h-full transition-all duration-1000 rounded-full ${
                              journey.outOfBounds ? "bg-red-500 glow-red" : "bg-emerald-500 glow-green"
                            }`}
                            style={{ width: `${aiReport.riskLevel}%` }}
                          />
                        </div>
                        <span className={`text-xs font-mono font-bold ${
                          journey.outOfBounds ? "text-red-400" : "text-emerald-400"
                        }`}>{aiReport.riskLevel}%</span>
                      </div>
                    </div>

                    <div>
                      <p className="text-[10px] font-mono text-cyan-500/60 uppercase">AI Diagnosis Details</p>
                      <p className="text-xs text-gray-300 leading-relaxed mt-1.5">
                        {aiReport.dangerDetails}
                      </p>
                    </div>

                    {/* Local Terrain Hazards detected */}
                    <div>
                      <p className="text-[10px] font-mono text-cyan-500/60 uppercase">Surrounding Environmental Hazards</p>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {aiReport.environmentalHazards?.map((h, i) => (
                          <span 
                            key={i} 
                            className="px-2.5 py-1 bg-[#1a0e1b]/30 text-amber-400 border border-amber-500/20 text-[9px] font-mono rounded"
                          >
                            ⚠ {h}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Safety Suggestions */}
                    <div>
                      <p className="text-[10px] font-mono text-cyan-500/60 uppercase">Secure Core Recommendations</p>
                      <ul className="space-y-2 mt-2">
                        {aiReport.recommendations?.map((r, i) => (
                          <li key={i} className="flex items-start space-x-2 text-xs text-gray-300">
                            <span className="text-cyan-500 mt-1 shrink-0 font-bold">•</span>
                            <span>{r}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Live Rescue Operations HUD (Receives Alert, Shows Team Dispatched) */}
            <div className="mt-6 border-t border-cyan-600/10 pt-5">
              <AnimatePresence>
                {rescueOperation.active && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="p-4 bg-red-950/20 border border-red-500/30 rounded-xl space-y-3.5 relative overflow-hidden"
                  >
                    {/* Glowing beacon */}
                    <div className="absolute top-2 right-2 flex items-center space-x-1">
                      <span className="h-1.5 w-1.5 bg-red-500 rounded-full animate-ping" />
                      <span className="text-[8px] font-mono text-red-400 font-extrabold uppercase">CO-PILOT RESPONSE ACTIVE</span>
                    </div>

                    <h4 className="text-xs font-display font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                      <Zap className="h-4 w-4 text-red-400 animate-pulse" />
                      Rescue Operation: Active Dispatch
                    </h4>

                    {/* Real-time Stage status */}
                    <div className="p-2.5 bg-black/40 border border-red-500/10 rounded-lg text-[10px] font-mono text-red-200">
                      <p className="text-red-400 font-black mb-1">STATUS: {rescueOperation.stages[rescueOperation.currentStageIndex]?.title}</p>
                      <p className="text-gray-400 leading-normal">{rescueOperation.stages[rescueOperation.currentStageIndex]?.desc}</p>
                    </div>

                    {/* ETA Countdown */}
                    <div className="flex items-center justify-between text-[11px] font-mono border-t border-red-500/10 pt-2 text-red-300">
                      <span>DISPATCH ID: {rescueOperation.dispatchId}</span>
                      <span className="font-bold">ETA: ~4 MINS</span>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* SOS Emergency beacon panel */}
            <div className="mt-6 border-t border-cyan-600/10 pt-5">
              {sosBeacon.active ? (
                <div className="space-y-3">
                  <div className="p-3 bg-red-950 text-red-200 border border-red-500/40 rounded-xl text-center">
                    <HeartPulse className="h-7 w-7 text-red-400 animate-ping mx-auto mb-2" />
                    <p className="text-xs font-mono font-bold tracking-widest uppercase">SOS BROADCAST BEACON TRANSMITTING</p>
                    <p className="text-[9px] text-red-300 font-mono mt-1">Satellite tracking locked on coordinates. Dispatch systems monitoring.</p>
                  </div>
                  <button
                    id="cancel_sos_beacon_btn"
                    onClick={onCancelSOS}
                    className="w-full py-3 bg-gray-950 border border-red-500/30 text-red-400 font-mono text-xs font-bold rounded-lg hover:bg-red-950/20 hover:border-red-500 transition-colors cursor-pointer"
                  >
                    DISMISS DISTRESS SIGNAL
                  </button>
                </div>
              ) : (
                <button
                  id="trigger_sos_beacon_btn"
                  onClick={triggerSOSBeacon}
                  disabled={!journey.active}
                  className={`w-full py-5 text-white font-display font-black text-sm tracking-wider rounded-xl transition-all flex items-center justify-center space-x-3.5 border ${
                    !journey.active 
                      ? "bg-gray-900/40 border-gray-800 text-gray-500 cursor-not-allowed" 
                      : "bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 border-red-500 shadow-[0_0_20px_rgba(239,68,68,0.3)] hover:shadow-[0_0_35px_rgba(239,68,68,0.5)] cursor-pointer"
                  }`}
                >
                  <PhoneCall className="h-5 w-5 animate-pulse" />
                  <span>TRIGGER SOS EMERGENCY SATELLITE DISPATCH</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* 4. Trip History & Secure Logbook Section */}
      <section className="relative z-10 max-w-7xl w-full mx-auto px-6 pb-16">
        <div className="glass-card rounded-2xl p-6 md:p-8 border border-cyan-600/15 relative overflow-hidden">
          {/* Subtle grid visual background */}
          <div className="absolute inset-0 grid-bg opacity-5 pointer-events-none" />

          {/* Section Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-cyan-600/10 pb-6 mb-8 gap-4 relative z-10">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-cyan-950/30 border border-cyan-600/20 rounded-xl">
                <History className="h-6 w-6 text-cyan-500" />
              </div>
              <div>
                <h3 className="font-display font-black text-lg text-white uppercase tracking-wider flex items-center gap-2">
                  SECURE TRAVEL LOGBOOK & FREQUENCY HUD
                </h3>
                <p className="text-[10px] font-mono text-cyan-500/60 uppercase">
                  ARCHIVED SATELLITE TELEMETRY | PASSENGER JOURNEY REGISTRY
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2 text-xs font-mono text-cyan-400 bg-cyan-950/20 border border-cyan-600/10 px-3 py-1.5 rounded-lg">
              <Calendar className="h-4 w-4" />
              <span>LOGBOOK SYNCED: SECURE CLOUD STORAGE ACTIVE</span>
            </div>
          </div>

          {/* Quick Metrics Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8 relative z-10">
            <div className="stat-card glass-card-hover p-4 rounded-xl flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-mono text-gray-500 uppercase">Total Journeys</span>
                <History className="h-3.5 w-3.5 text-cyan-500/50" />
              </div>
              <span className="font-display font-black text-2xl text-white mt-1">
                <AnimatedCounter value={tripHistory.length} /> <span className="text-xs font-sans text-cyan-500 font-bold">RECORDS</span>
              </span>
            </div>
            
            <div className="stat-card glass-card-hover p-4 rounded-xl flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-mono text-gray-500 uppercase">Distance Covered</span>
                <Navigation className="h-3.5 w-3.5 text-cyan-500/50" />
              </div>
              <span className="font-display font-black text-2xl text-cyan-500 mt-1">
                <AnimatedCounter value={parseFloat(tripHistory.reduce((acc, item) => acc + item.distanceCoveredKm, 0).toFixed(1))} decimals={1} /> <span className="text-xs font-sans text-white font-bold">KM</span>
              </span>
            </div>
            
            <div className="stat-card glass-card-hover p-4 rounded-xl flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-mono text-gray-500 uppercase">Avg Max Risk</span>
                <TrendingUp className="h-3.5 w-3.5 text-amber-400/50" />
              </div>
              <span className="font-display font-black text-2xl text-amber-400 mt-1">
                <AnimatedCounter value={Math.round(tripHistory.reduce((acc, item) => acc + item.maxRiskLevel, 0) / (tripHistory.length || 1))} />% <span className="text-xs font-sans text-white font-bold">INDEX</span>
              </span>
            </div>
            
            <div className="stat-card glass-card-hover p-4 rounded-xl flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-mono text-gray-500 uppercase">Shield Protection Integrity</span>
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-400/50" />
              </div>
              <span className="font-display font-black text-2xl text-emerald-400 mt-1">
                <AnimatedCounter value={100} />% <span className="text-xs font-sans text-white font-bold">SECURED</span>
              </span>
            </div>
          </div>

          {/* Analytics Details: Chart on Left, Log Table on Right */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch relative z-10">
            
            {/* Visual Travel Frequency Chart */}
            <div className="lg:col-span-5 bg-[#020b18]/40 border border-cyan-600/10 p-5 rounded-xl flex flex-col justify-between">
              <div>
                <h4 className="text-xs font-mono font-extrabold text-cyan-500 uppercase tracking-widest flex items-center gap-1.5 mb-2">
                  <BarChart2 className="h-4 w-4" />
                  Voyage Frequency & Distance Trends
                </h4>
                <p className="text-[10px] text-gray-400 leading-relaxed mb-6">
                  Spatio-temporal analysis depicting the frequency of excursions and aggregate geodesic distance covered over the current cycle.
                </p>
              </div>

              {/* Area Chart Container */}
              <div className="h-[260px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={dailyStats}
                    margin={{ top: 10, right: 10, left: -25, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient id="colorDistance" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#06B6D4" stopOpacity={0.4}/>
                        <stop offset="95%" stopColor="#06B6D4" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorTrips" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#0e1e36" opacity={0.4} />
                    <XAxis 
                      dataKey="day" 
                      stroke="#475569" 
                      fontSize={9} 
                      tickLine={false} 
                      axisLine={false}
                    />
                    <YAxis 
                      stroke="#475569" 
                      fontSize={9} 
                      tickLine={false} 
                      axisLine={false}
                    />
                    <Tooltip 
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          return (
                            <div className="bg-[#030e21] border border-cyan-600/30 p-3 rounded-lg shadow-lg font-mono text-[10px] space-y-1">
                              <p className="text-gray-400 font-bold border-b border-cyan-600/10 pb-1 mb-1 uppercase">
                                {payload[0].payload.day}
                              </p>
                              <p className="text-cyan-500 flex justify-between gap-4">
                                <span>DISTANCE:</span> 
                                <span className="font-bold">{payload[0].value} KM</span>
                              </p>
                              {payload[1] && (
                                <p className="text-blue-400 flex justify-between gap-4">
                                  <span>TRIPS:</span> 
                                  <span className="font-bold">{payload[1].value}</span>
                                </p>
                              )}
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="distance" 
                      stroke="#06B6D4" 
                      strokeWidth={2}
                      fillOpacity={1} 
                      fill="url(#colorDistance)" 
                      name="Distance Covered"
                    />
                    <Area 
                      type="monotone" 
                      dataKey="trips" 
                      stroke="#3b82f6" 
                      strokeWidth={1.5}
                      fillOpacity={1} 
                      fill="url(#colorTrips)" 
                      name="Trips Completed"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {/* Legend */}
              <div className="flex justify-center space-x-6 text-[9px] font-mono text-gray-400 mt-4 border-t border-cyan-600/5 pt-3">
                <div className="flex items-center space-x-1.5">
                  <span className="h-2 w-2 rounded-full bg-cyan-500" />
                  <span>Geodesic Distance (KM)</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <span className="h-2 w-2 rounded-full bg-blue-500" />
                  <span>Trips Logged (Qty)</span>
                </div>
              </div>
            </div>

            {/* Past Journeys List */}
            <div className="lg:col-span-7 bg-[#020b18]/40 border border-cyan-600/10 p-5 rounded-xl flex flex-col">
              <h4 className="text-xs font-mono font-extrabold text-cyan-500 uppercase tracking-widest flex items-center gap-1.5 mb-4">
                <Compass className="h-4 w-4 animate-spin-slow" />
                Expedition Archives & Biometric Assessments
              </h4>
              
              <div className="flex-grow overflow-y-auto max-h-[320px] pr-2 scrollbar-thin scrollbar-thumb-cyan-950 space-y-3.5 relative">
                {/* Timeline connector spine */}
                <div className="absolute left-[7px] top-2 bottom-2 w-px bg-gradient-to-b from-cyan-600/40 via-cyan-600/10 to-transparent pointer-events-none" />
                {tripHistory.map((trip) => (
                  <div 
                    key={trip.id}
                    className="relative pl-5 p-4 bg-[#030e21] hover:bg-[#061530] border border-cyan-600/5 hover:border-cyan-600/20 rounded-xl transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    <span className={`absolute left-0 top-5 h-2.5 w-2.5 rounded-full border-2 border-[#030e21] ${
                      trip.status === "SAFE" ? "bg-emerald-400" : trip.status === "WARNING" ? "bg-amber-400" : "bg-red-500"
                    }`} />
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className="text-[10px] font-mono text-cyan-500/80 font-bold bg-cyan-950/30 px-2 py-0.5 rounded border border-cyan-600/10">
                          {trip.id}
                        </span>
                        <span className="text-[10px] font-mono text-gray-400">
                          {trip.date}
                        </span>
                      </div>
                      <h5 className="font-display font-bold text-sm text-white">
                        {trip.terrain}
                      </h5>
                    </div>

                    <div className="flex items-center justify-between md:justify-end gap-6">
                      <div className="text-right">
                        <p className="text-[10px] font-mono text-gray-500 uppercase">Coverage</p>
                        <p className="text-xs text-cyan-400 font-bold mt-0.5">
                          {trip.distanceCoveredKm} km <span className="text-[10px] font-mono text-gray-400">({trip.duration})</span>
                        </p>
                      </div>

                      <div className="text-right">
                        <p className="text-[10px] font-mono text-gray-500 uppercase">Risk Level</p>
                        <p className="text-xs text-amber-400 font-bold mt-0.5">
                          {trip.maxRiskLevel}%
                        </p>
                      </div>

                      <div>
                        {trip.status === "SAFE" ? (
                          <span className="px-2.5 py-1 bg-emerald-950/40 text-emerald-400 border border-emerald-500/20 text-[9px] font-mono rounded-full font-bold uppercase tracking-wider block text-center min-w-[72px]">
                            SECURE
                          </span>
                        ) : trip.status === "WARNING" ? (
                          <span className="px-2.5 py-1 bg-amber-950/40 text-amber-400 border border-amber-500/20 text-[9px] font-mono rounded-full font-bold uppercase tracking-wider block text-center min-w-[72px]">
                            WARNING
                          </span>
                        ) : (
                          <span className="px-2.5 py-1 bg-red-950/40 text-red-400 border border-red-500/20 text-[9px] font-mono rounded-full font-bold uppercase tracking-wider block text-center min-w-[72px]">
                            BREACH
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}

                {tripHistory.length === 0 && (
                  <div className="text-center py-12 text-gray-500 font-mono text-xs">
                    No historic voyages on register.
                  </div>
                )}
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 py-5 text-center text-[10px] font-mono text-gray-600 border-t border-cyan-600/10 bg-[#020617]/50 w-full mt-auto">
        AEGIS PRIVACY CORE | CONNECTED WITH REGIONAL EMBASSIES & EMERGENCY DISPATCH ARRAYS
      </footer>
    </div>
  );
}
