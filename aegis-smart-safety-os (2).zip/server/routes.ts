import express, { Response } from 'express';
import crypto from 'crypto';
import { db, User, Tourist, Alert, SOSAlert, SafeZone, BlockchainRecord, SupportMessage, ServiceEntity } from './store';
import { authenticateToken, authorizeRoles, signToken, AuthenticatedRequest } from './auth';
import { getRiskPrediction, getChatbotResponse, getRouteSafetySuggestion } from './ai';

const router = express.Router();

/**
 * Haversine formula to compute distance in meters between two coordinates
 */
function getDistanceMeters(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371e3; // Earth radius in meters
  const phi1 = (lat1 * Math.PI) / 180;
  const phi2 = (lat2 * Math.PI) / 180;
  const deltaPhi = ((lat2 - lat1) * Math.PI) / 180;
  const deltaLambda = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}

// ==========================================
// AUTHENTICATION ENDPOINTS
// ==========================================

// Register a new tourist
router.post('/auth/register', (req, res) => {
  try {
    const { email, password, name, phone, nationality, passportNumber, bloodType, medicalConditions, emergencyContactName, emergencyContactPhone } = req.body;

    if (!email || !password || !name) {
      return res.status(400).json({ error: 'Missing required parameters: email, password, and name are mandatory.' });
    }

    const existing = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      return res.status(400).json({ error: 'User with this email already exists.' });
    }

    const userId = crypto.randomUUID();
    const passwordHash = crypto.createHash('sha256').update(password).digest('hex');
    const walletAddress = '0x' + crypto.randomBytes(20).toString('hex');

    const newUser: User = {
      id: userId,
      email: email.toLowerCase(),
      passwordHash,
      role: 'tourist',
      name,
      phone: phone || '',
      nationality: nationality || 'Unknown',
      passportNumber: passportNumber || 'N/A',
      walletAddress,
      createdAt: new Date().toISOString()
    };

    db.users.push(newUser);

    // Create the Tourist profile matching the User
    const digitalId = '0x' + crypto.randomBytes(32).toString('hex');
    const newTourist: Tourist = {
      userId,
      currentLat: 48.8566, // Default Paris
      currentLng: 2.3522,
      riskScore: 10,
      riskStatus: 'Safe',
      safeZoneId: null,
      digitalId,
      verificationQr: `SAFETY-ID-${userId.substring(0, 8).toUpperCase()}`,
      blockchainWallet: walletAddress,
      status: 'active',
      nationality: nationality || 'Unknown',
      passportNumber: passportNumber || 'N/A',
      medicalConditions: medicalConditions ? medicalConditions.split(',').map((s: string) => s.trim()) : [],
      bloodType: bloodType || 'O-Positive',
      emergencyContactName: emergencyContactName || 'N/A',
      emergencyContactPhone: emergencyContactPhone || 'N/A',
      embassyContact: `Contact embassy for ${nationality || 'your country'}`
    };

    db.tourists[userId] = newTourist;

    // Add immutable Blockchain registration record
    db.blockchainRecords.push({
      txHash: '0x' + crypto.randomBytes(32).toString('hex'),
      blockNumber: Math.floor(Math.random() * 2000000) + 14000000,
      timestamp: new Date().toISOString(),
      type: 'ID_CREATION',
      details: `Immutable Passport Verification & Digital ID Linked for user ${userId.substring(0, 6)}...`,
      walletAddress
    });

    db.save();

    const token = signToken({ id: userId, email: newUser.email, role: 'tourist', name: newUser.name });

    res.status(201).json({
      message: 'Tourist registered successfully.',
      token,
      user: { id: userId, email: newUser.email, role: 'tourist', name: newUser.name }
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Login for all roles
router.post('/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const user = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const hash = crypto.createHash('sha256').update(password).digest('hex');
    if (user.passwordHash !== hash) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const token = signToken({ id: user.id, email: user.email, role: user.role, name: user.name });

    res.json({
      message: 'Login successful.',
      token,
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        name: user.name,
        walletAddress: user.walletAddress
      }
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Reset Password / Forgot Password
router.post('/auth/forgot-password', (req, res) => {
  const { email } = req.body;
  const user = db.users.find(u => u.email.toLowerCase() === email?.toLowerCase());
  if (!user) {
    return res.status(404).json({ error: 'No account registered with this email.' });
  }
  // Simulate OTP code
  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  res.json({
    message: `A simulated security OTP reset code has been generated. Use OTP: ${otp} to update password.`,
    otp
  });
});

// Complete Password Reset with OTP
router.post('/auth/reset-password', (req, res) => {
  const { email, otp, newPassword } = req.body;
  if (!email || !otp || !newPassword) {
    return res.status(400).json({ error: 'Missing reset details.' });
  }
  const user = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (!user) {
    return res.status(404).json({ error: 'Account not found.' });
  }

  // Set new password
  user.passwordHash = crypto.createHash('sha256').update(newPassword).digest('hex');
  db.save();
  res.json({ message: 'Password updated successfully. Please login with your new credentials.' });
});

// Get current profile
router.get('/auth/me', authenticateToken, (req: AuthenticatedRequest, res) => {
  const user = db.users.find(u => u.id === req.user?.id);
  if (!user) return res.status(404).json({ error: 'User profile not found.' });

  const touristProfile = req.user?.role === 'tourist' ? db.tourists[user.id] : null;

  res.json({
    user: {
      id: user.id,
      email: user.email,
      role: user.role,
      name: user.name,
      phone: user.phone,
      walletAddress: user.walletAddress,
      nationality: user.nationality,
      passportNumber: user.passportNumber
    },
    tourist: touristProfile
  });
});

// Update profile parameters
router.put('/auth/profile', authenticateToken, (req: AuthenticatedRequest, res) => {
  try {
    const user = db.users.find(u => u.id === req.user?.id);
    if (!user) return res.status(404).json({ error: 'User profile not found.' });

    const { name, phone, nationality, passportNumber, bloodType, medicalConditions, emergencyContactName, emergencyContactPhone } = req.body;

    if (name !== undefined) user.name = name;
    if (phone !== undefined) user.phone = phone;
    if (nationality !== undefined) user.nationality = nationality;
    if (passportNumber !== undefined) user.passportNumber = passportNumber;

    if (user.role === 'tourist') {
      const tourist = db.tourists[user.id];
      if (tourist) {
        if (nationality !== undefined) tourist.nationality = nationality;
        if (passportNumber !== undefined) tourist.passportNumber = passportNumber;
        if (bloodType !== undefined) tourist.bloodType = bloodType;
        if (medicalConditions !== undefined) {
          tourist.medicalConditions = Array.isArray(medicalConditions) 
            ? medicalConditions 
            : typeof medicalConditions === 'string'
              ? medicalConditions.split(',').map((s: string) => s.trim()).filter(Boolean)
              : [];
        }
        if (emergencyContactName !== undefined) tourist.emergencyContactName = emergencyContactName;
        if (emergencyContactPhone !== undefined) tourist.emergencyContactPhone = emergencyContactPhone;
      }
    }

    // Add ledger audit trace for profile update
    db.blockchainRecords.push({
      txHash: '0x' + crypto.randomBytes(32).toString('hex'),
      blockNumber: Math.floor(Math.random() * 2000000) + 14000000,
      timestamp: new Date().toISOString(),
      type: 'IDENTITY_VERIFICATION',
      details: `PROFILE UPDATE: User ${user.name} secure biometric / registration profile parameters updated.`,
      walletAddress: user.walletAddress || '0x' + crypto.randomBytes(20).toString('hex')
    });

    db.save();

    res.json({
      message: 'Profile updated successfully.',
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        name: user.name,
        phone: user.phone,
        walletAddress: user.walletAddress,
        nationality: user.nationality,
        passportNumber: user.passportNumber
      },
      tourist: user.role === 'tourist' ? db.tourists[user.id] : null
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// ==========================================
// GPS TELEMETRY & GEOFENCING ENGINE
// ==========================================

// Post live GPS coordinate & check geofencing status
router.post('/telemetry/location', authenticateToken, (req: AuthenticatedRequest, res) => {
  const userId = req.user?.id;
  const { lat, lng } = req.body;

  if (lat === undefined || lng === undefined) {
    return res.status(400).json({ error: 'Latitude and longitude are required.' });
  }

  if (req.user?.role !== 'tourist') {
    return res.status(400).json({ error: 'Location tracking only supported for Tourist accounts.' });
  }

  const tourist = db.tourists[userId!];
  if (!tourist) {
    return res.status(404).json({ error: 'Tourist profile not found.' });
  }

  // Update position
  tourist.currentLat = lat;
  tourist.currentLng = lng;

  // Evaluate Geofences (Safe Zones and Danger Zones)
  let joinedZone: SafeZone | null = null;
  let breachedDangerZone: SafeZone | null = null;

  db.safeZones.forEach(zone => {
    const dist = getDistanceMeters(lat, lng, zone.lat, zone.lng);
    if (dist <= zone.radius) {
      if (zone.type === 'safe') {
        joinedZone = zone;
      } else if (zone.type === 'danger') {
        breachedDangerZone = zone;
      }
    }
  });

  const alertsTriggered: string[] = [];

  // Check transitions
  if (joinedZone) {
    if (tourist.safeZoneId !== joinedZone.id) {
      // Automatic Entry Alert!
      alertsTriggered.push(`GEOFENCE ALERT: Welcome back! You entered the secured '${joinedZone.name}'. Protection active.`);
      tourist.safeZoneId = joinedZone.id;
    }
  } else {
    if (tourist.safeZoneId !== null) {
      // Automatic Exit Alert!
      const oldZone = db.safeZones.find(z => z.id === tourist.safeZoneId);
      alertsTriggered.push(`GEOFENCE ALERT: WARNING! You departed the secured '${oldZone?.name || 'Safe Zone'}'. Situational monitoring initialized.`);
      tourist.safeZoneId = null;
    }
  }

  if (breachedDangerZone) {
    alertsTriggered.push(`CRITICAL ALERT: BREACH! You entered high-risk area '${breachedDangerZone.name}'. Security emergency dispatchers are on watch. Maintain full awareness.`);
  }

  // Create notifications in-memory for the tourist
  alertsTriggered.forEach(msgText => {
    db.supportMessages.push({
      id: crypto.randomUUID(),
      senderId: 'system_geofence',
      senderName: 'Geofencing Engine',
      receiverId: userId!,
      message: msgText,
      createdAt: new Date().toISOString(),
      read: false
    });
  });

  // Calculate dynamic AI risk score immediately based on geofences and state
  let score = 15;
  if (breachedDangerZone) score += 40;
  if (!joinedZone) score += 15;
  if (tourist.status === 'in_emergency') score = 98;

  tourist.riskScore = score;
  tourist.riskStatus = score < 30 ? 'Safe' : score < 60 ? 'Moderate' : 'High';

  db.save();

  res.json({
    status: tourist.status,
    riskScore: tourist.riskScore,
    riskStatus: tourist.riskStatus,
    currentZone: joinedZone ? joinedZone.name : 'Unsecured Neutral Area',
    breachedDangerZone: breachedDangerZone ? breachedDangerZone.name : null,
    alertsTriggered
  });
});

// ==========================================
// SOS EMERGENCY ACTION SYSTEM
// ==========================================

// Trigger SOS emergency
router.post('/sos/trigger', authenticateToken, (req: AuthenticatedRequest, res) => {
  const userId = req.user?.id;
  const { notes, lat, lng } = req.body;

  if (req.user?.role !== 'tourist') {
    return res.status(400).json({ error: 'SOS can only be activated by tourists.' });
  }

  const tourist = db.tourists[userId!];
  if (!tourist) return res.status(404).json({ error: 'Tourist profile not found.' });

  tourist.status = 'in_emergency';
  tourist.riskScore = 99;
  tourist.riskStatus = 'High';

  // Create SOS Alert record
  const sosId = `sos-${Date.now()}`;
  const newSos: SOSAlert = {
    id: sosId,
    touristId: userId!,
    touristName: req.user.name,
    nationality: tourist.nationality,
    lat: lat || tourist.currentLat,
    lng: lng || tourist.currentLng,
    status: 'pending',
    acceptedBy: null,
    medicalInfo: {
      bloodType: tourist.bloodType,
      conditions: tourist.medicalConditions
    },
    notes: notes || 'EMERGENCY: Immediate assistance required. Tourist triggered physical panic button.',
    createdAt: new Date().toISOString()
  };

  db.sosAlerts.push(newSos);

  // Log to Blockchain Ledger
  db.blockchainRecords.push({
    txHash: '0x' + crypto.randomBytes(32).toString('hex'),
    blockNumber: Math.floor(Math.random() * 2000000) + 14000000,
    timestamp: new Date().toISOString(),
    type: 'SOS_LOG',
    details: `EMERGENCY ALERT BROADCASTED: Tourist ${req.user.name} coordinates (${newSos.lat.toFixed(4)}, ${newSos.lng.toFixed(4)}) recorded permanently.`,
    walletAddress: tourist.blockchainWallet
  });

  db.save();

  res.status(201).json({
    message: 'SOS Alert broadcasted to all police units, hospitals, and national embassy.',
    sosAlert: newSos
  });
});

// Accept an SOS incident (Police or Hospital)
router.post('/sos/:id/accept', authenticateToken, authorizeRoles('police', 'hospital'), (req: AuthenticatedRequest, res) => {
  const { id } = req.params;
  const sos = db.sosAlerts.find(s => s.id === id);

  if (!sos) return res.status(404).json({ error: 'SOS alert not found.' });

  sos.status = 'accepted';
  sos.acceptedBy = {
    id: req.user!.id,
    role: req.user!.role as 'police' | 'hospital',
    name: req.user!.name
  };

  // Add system message to tourist
  db.supportMessages.push({
    id: crypto.randomUUID(),
    senderId: req.user!.id,
    senderName: req.user!.name,
    receiverId: sos.touristId,
    message: `EMERGENCY RESPONSE: Your SOS has been accepted. Dispatching immediate dispatch responders from ${req.user!.name}. Remain calm.`,
    createdAt: new Date().toISOString(),
    read: false
  });

  db.save();
  res.json({ message: 'Emergency dispatch accepted successfully.', sosAlert: sos });
});

// Resolve SOS emergency
router.post('/sos/:id/resolve', authenticateToken, (req: AuthenticatedRequest, res) => {
  const { id } = req.params;
  const sos = db.sosAlerts.find(s => s.id === id);

  if (!sos) return res.status(404).json({ error: 'SOS alert not found.' });

  sos.status = 'resolved';
  sos.resolvedAt = new Date().toISOString();

  // Reset tourist emergency status if they have no other pending SOS alerts
  const tourist = db.tourists[sos.touristId];
  if (tourist) {
    tourist.status = 'active';
    tourist.riskScore = 15;
    tourist.riskStatus = 'Safe';
  }

  db.save();
  res.json({ message: 'Emergency case resolved.', sosAlert: sos });
});

// Retrieve active SOS alerts (for admin, police, hospital, embassy dashboards)
router.get('/sos/active', authenticateToken, (req: AuthenticatedRequest, res) => {
  // Police, Hospitals, Embassies see pending + accepted alerts. Tourists see their own.
  if (req.user?.role === 'tourist') {
    const list = db.sosAlerts.filter(s => s.touristId === req.user!.id);
    return res.json(list);
  }

  res.json(db.sosAlerts);
});

// ==========================================
// BLOCKCHAIN DIGITAL IDENTITY
// ==========================================

// Audit ledger records
router.get('/blockchain/ledger', authenticateToken, (req, res) => {
  res.json(db.blockchainRecords);
});

// Verify cryptographic ID QR Code
router.post('/blockchain/verify-id', authenticateToken, (req, res) => {
  const { qrCodeText } = req.body;
  if (!qrCodeText) return res.status(400).json({ error: 'QR Code payload is missing.' });

  // Locate the tourist possessing this ID
  let tourist = Object.values(db.tourists).find(
    t => t.verificationQr.toUpperCase() === qrCodeText.toUpperCase()
  );

  // Fallback for demo testing with prefilled 'SAFETY-ID-TOURIST'
  if (!tourist && qrCodeText.toUpperCase() === 'SAFETY-ID-TOURIST') {
    tourist = Object.values(db.tourists)[0];
  }

  if (!tourist) {
    return res.status(404).json({ error: 'Cryptographic ID signature verification failed. Invalid card or tamper detected.' });
  }

  const user = db.users.find(u => u.id === tourist.userId);

  // Generate verifiable event in ledger
  db.blockchainRecords.push({
    txHash: '0x' + crypto.randomBytes(32).toString('hex'),
    blockNumber: Math.floor(Math.random() * 2000000) + 14000000,
    timestamp: new Date().toISOString(),
    type: 'IDENTITY_VERIFICATION',
    details: `IDENTITY VERIFIED: Verified Tourist ${user?.name} via QR Signature. Passport: ${tourist.passportNumber}`,
    walletAddress: tourist.blockchainWallet
  });

  db.save();

  res.json({
    verified: true,
    timestamp: new Date().toISOString(),
    identity: {
      name: user?.name,
      nationality: tourist.nationality,
      passportNumber: tourist.passportNumber,
      bloodType: tourist.bloodType,
      walletAddress: tourist.blockchainWallet,
      digitalSignature: tourist.digitalId
    }
  });
});

// ==========================================
// GEOFENCING SAFE ZONES & ALERTS MANAGEMENT
// ==========================================

// Retrieve all Geofences
router.get('/geofencing/zones', authenticateToken, (req, res) => {
  res.json(db.safeZones);
});

// Create new geofenced zone (Admin only)
router.post('/geofencing/zones', authenticateToken, authorizeRoles('admin'), (req: AuthenticatedRequest, res) => {
  const { name, description, type, lat, lng, radius } = req.body;

  if (!name || !type || lat === undefined || lng === undefined || radius === undefined) {
    return res.status(400).json({ error: 'Missing geofence specifications.' });
  }

  const newZone: SafeZone = {
    id: `zone-${Date.now()}`,
    name,
    description: description || '',
    type,
    lat: Number(lat),
    lng: Number(lng),
    radius: Number(radius),
    creatorId: req.user!.id,
    createdAt: new Date().toISOString()
  };

  db.safeZones.push(newZone);

  // Log on blockchain
  db.blockchainRecords.push({
    txHash: '0x' + crypto.randomBytes(32).toString('hex'),
    blockNumber: Math.floor(Math.random() * 2000000) + 14000000,
    timestamp: new Date().toISOString(),
    type: 'SECURITY_ALERT',
    details: `GEOFENCE AREA CREATED: ${name} (${type.toUpperCase()}) registered on global monitor ledger.`,
    walletAddress: '0x0000000000000000000000000000000000000000'
  });

  db.save();
  res.status(201).json({ message: 'Geofenced safety sector registered successfully.', zone: newZone });
});

// Retrieve safety service coordinates (Hospitals, Police, Embassies)
router.get('/services/entities', authenticateToken, (req, res) => {
  res.json(db.serviceEntities);
});

// Retrieve environmental alerts
router.get('/safety/alerts', authenticateToken, (req, res) => {
  res.json(db.alerts.filter(a => a.active));
});

// Add new safety alert (Admin, Police, Embassy)
router.post('/safety/alerts', authenticateToken, authorizeRoles('admin', 'police', 'embassy'), (req, res) => {
  const { type, title, description, severity, lat, lng, radius } = req.body;

  if (!type || !title || !description || !severity || lat === undefined || lng === undefined) {
    return res.status(400).json({ error: 'Missing core alert details.' });
  }

  const newAlert: Alert = {
    id: `alert-${Date.now()}`,
    type,
    title,
    description,
    severity,
    lat: Number(lat),
    lng: Number(lng),
    radius: Number(radius || 1000),
    active: true,
    createdAt: new Date().toISOString()
  };

  db.alerts.push(newAlert);
  db.save();

  res.status(201).json({ message: 'Security Alert broadcasted to all tourists.', alert: newAlert });
});

// ==========================================
// AI-POWERED MONITORING ENDPOINTS
// ==========================================

// AI travel risk assessment for tourist dashboard
router.get('/ai/risk-report', authenticateToken, async (req: AuthenticatedRequest, res) => {
  try {
    const tourist = db.tourists[req.user!.id];
    if (!tourist) return res.status(404).json({ error: 'Tourist profile not found.' });

    // Weather forecast mockup
    const report = await getRiskPrediction(
      tourist.currentLat,
      tourist.currentLng,
      'Scattered Thunderstorms & High Humid Atmosphere',
      new Date().toLocaleTimeString('en-US', { hour12: false })
    );

    res.json(report);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// AI safe path route advisor
router.post('/ai/route-advisor', authenticateToken, async (req, res) => {
  try {
    const { origin, destination } = req.body;
    if (!origin || !destination) {
      return res.status(400).json({ error: 'Origin and destination parameters are required.' });
    }
    const pathAdvice = await getRouteSafetySuggestion(origin, destination);
    res.json(pathAdvice);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// AI Interactive Safety Assistant Chatbot
router.post('/ai/chatbot', authenticateToken, async (req, res) => {
  try {
    const { message, chatHistory } = req.body;
    if (!message) return res.status(400).json({ error: 'Message cannot be empty.' });

    const reply = await getChatbotResponse(chatHistory || [], message);
    res.json({ reply });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// ==========================================
// EMERGENCY BROADCAST MESSAGES / CHAT API
// ==========================================

// Send a support message (inter-dashboard communication)
router.post('/messages', authenticateToken, (req: AuthenticatedRequest, res) => {
  const { receiverId, message } = req.body;
  if (!receiverId || !message) {
    return res.status(400).json({ error: 'Receiver ID and message body required.' });
  }

  const newMsg: SupportMessage = {
    id: crypto.randomUUID(),
    senderId: req.user!.id,
    senderName: req.user!.name,
    receiverId,
    message,
    createdAt: new Date().toISOString(),
    read: false
  };

  db.supportMessages.push(newMsg);
  db.save();

  res.status(201).json(newMsg);
});

// Fetch messaging log for current user
router.get('/messages', authenticateToken, (req: AuthenticatedRequest, res) => {
  const userId = req.user!.id;
  const role = req.user!.role;

  // Police, Hospitals, Embassies see support requests sent to them, plus tourist conversations.
  // Standard user sees any messages involving their ID.
  const relevantMsgs = db.supportMessages.filter(
    m => m.senderId === userId || m.receiverId === userId || m.receiverId === role || m.senderId === role
  );

  res.json(relevantMsgs);
});

export default router;
