/**
 * Haversine formula to compute distance in meters between two GPS coordinates.
 * @param {number} lat1 Latitude of first coordinate
 * @param {number} lon1 Longitude of first coordinate
 * @param {number} lat2 Latitude of second coordinate
 * @param {number} lon2 Longitude of second coordinate
 * @returns {number} Distance in meters
 */
export function getDistanceMeters(lat1, lon1, lat2, lon2) {
  const R = 6371e3; // Earth radius in meters
  const phi1 = (lat1 * Math.PI) / 180;
  const phi2 = (lat2 * Math.PI) / 180;
  const deltaPhi = ((lat2 - lat1) * Math.PI) / 180;
  const deltaLambda = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}

/**
 * Service to manage real-time GPS boundary detection and event triggers for designated zones.
 */
export class GeofenceService {
  constructor(zones = []) {
    this.zones = zones; // Array of { id, name, type, lat, lng, radius, description }
    this.activeZones = new Map(); // Map of entered zoneId -> zone details
    this.listeners = {
      enter: [],
      exit: [],
      statusChange: []
    };
  }

  /**
   * Set or update the active list of geofence zones.
   * @param {Array} zones 
   */
  updateZones(zones) {
    this.zones = zones || [];
  }

  /**
   * Register an event listener.
   * Supported events: 'enter', 'exit', 'statusChange'
   * @param {string} event 
   * @param {function} callback 
   */
  on(event, callback) {
    if (this.listeners[event] && typeof callback === 'function') {
      this.listeners[event].push(callback);
    }
  }

  /**
   * Unregister an event listener.
   * @param {string} event 
   * @param {function} callback 
   */
  off(event, callback) {
    if (this.listeners[event]) {
      this.listeners[event] = this.listeners[event].filter(cb => cb !== callback);
    }
  }

  /**
   * Dispatches the event with the provided payload to all registered listeners.
   * @param {string} event 
   * @param {any} data 
   */
  _emit(event, data) {
    if (this.listeners[event]) {
      this.listeners[event].forEach(callback => {
        try {
          callback(data);
        } catch (error) {
          console.error(`Error executing geofence listener for event [${event}]:`, error);
        }
      });
    }
  }

  /**
   * Process a new GPS location update, determine crossings, and trigger alerts.
   * @param {number} lat - Current latitude
   * @param {number} lng - Current longitude
   * @returns {object} Status evaluation report
   */
  processLocationUpdate(lat, lng) {
    if (lat === undefined || lng === undefined || isNaN(lat) || isNaN(lng)) {
      return { error: 'Invalid coordinates provided' };
    }

    const currentEnteredZones = [];
    let breachedDangerZone = null;
    let currentSafeZone = null;

    // Check relationship with each zone
    this.zones.forEach(zone => {
      const distance = getDistanceMeters(lat, lng, zone.lat, zone.lng);
      const isInside = distance <= zone.radius;

      if (isInside) {
        currentEnteredZones.push({ ...zone, currentDistance: distance });
        if (zone.type === 'danger') {
          breachedDangerZone = zone;
        } else if (zone.type === 'safe') {
          currentSafeZone = zone;
        }

        // Check if transition: entering zone
        if (!this.activeZones.has(zone.id)) {
          this.activeZones.set(zone.id, { ...zone, enteredAt: new Date().toISOString() });
          this._emit('enter', {
            zone,
            lat,
            lng,
            distance,
            timestamp: new Date().toISOString()
          });
        }
      } else {
        // Check if transition: exiting zone
        if (this.activeZones.has(zone.id)) {
          const exitDetails = this.activeZones.get(zone.id);
          this.activeZones.delete(zone.id);
          this._emit('exit', {
            zone,
            lat,
            lng,
            distance,
            enteredAt: exitDetails.enteredAt,
            timestamp: new Date().toISOString()
          });
        }
      }
    });

    const statusReport = {
      lat,
      lng,
      currentEnteredZones,
      currentSafeZone,
      breachedDangerZone,
      isProtected: currentSafeZone !== null,
      isUnderThreat: breachedDangerZone !== null,
      timestamp: new Date().toISOString()
    };

    this._emit('statusChange', statusReport);
    return statusReport;
  }

  /**
   * Get list of currently active (entered) geofences.
   * @returns {Array} List of entered zones
   */
  getActiveZones() {
    return Array.from(this.activeZones.values());
  }
}

// Export a default shared global instance of GeofenceService for convenient usage
export const defaultGeofenceService = new GeofenceService();
