import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Shield, Users, Radio, MapPin, AlertTriangle, Activity, 
  Send, Plus, Trash2, Globe, Heart, LogOut, Check
} from 'lucide-react';

export default function AdminDashboard() {
  const { 
    user, safeZones, alerts, sosAlerts, createGeofence, createAlert, logout, theme 
  } = useApp();

  const isDark = theme === 'dark';

  // State for creating safe zone
  const [zoneForm, setZoneForm] = useState({
    name: '',
    description: '',
    type: 'safe',
    lat: '48.8566',
    lng: '2.3522',
    radius: '500'
  });

  // State for creating alert
  const [alertForm, setAlertForm] = useState({
    type: 'weather',
    title: '',
    description: '',
    severity: 'medium',
    lat: '48.8566',
    lng: '2.3522',
    radius: '1000'
  });

  const [usersList, setUsersList] = useState<any[]>([]);
  const [msg, setMsg] = useState('');

  // Fetch users list from backend
  const fetchUsers = async () => {
    try {
      const res = await fetch('/api/blockchain/ledger', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('safety_jwt')}` }
      });
      // Set some demo user data if needed
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleZoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg('');
    await createGeofence(zoneForm);
    setMsg('New geofenced safety boundary successfully locked on-chain!');
    setZoneForm({
      name: '',
      description: '',
      type: 'safe',
      lat: '48.8566',
      lng: '2.3522',
      radius: '500'
    });
  };

  const handleAlertSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg('');
    await createAlert(alertForm);
    setMsg('Security Alert broadcasted to all tourists active in Paris.');
    setAlertForm({
      type: 'weather',
      title: '',
      description: '',
      severity: 'medium',
      lat: '48.8566',
      lng: '2.3522',
      radius: '1000'
    });
  };

  return (
    <div className={`min-h-screen flex flex-col md:flex-row transition-colors duration-300 ${isDark ? 'mesh-background text-white' : 'mesh-background-light text-slate-900'}`}>
      
      {/* Sidebar navigation */}
      <aside className={`w-full md:w-64 border-b md:border-b-0 md:border-r flex flex-col justify-between ${isDark ? 'glass border-white/10' : 'glass-light border-slate-900/10'}`}>
        <div>
          <div className="p-6 border-b border-white/5 flex items-center space-x-3">
            <div className="bg-blue-600 p-2 rounded-xl text-white">
              <Shield className="h-5 w-5" />
            </div>
            <div>
              <p className="font-extrabold text-sm tracking-tight text-gradient">AEGIS TOURIST</p>
              <span className="text-[9px] uppercase tracking-wider opacity-60">Admin Command</span>
            </div>
          </div>

          <div className="p-6 border-b border-white/5">
            <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Operator</p>
            <p className="text-sm font-extrabold mt-1 text-slate-200">{user?.name}</p>
            <span className="text-[10px] bg-red-500/10 text-red-400 px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider mt-2 inline-block">
              Root Clearance
            </span>
          </div>

          <nav className="p-4 space-y-1 text-xs font-bold tracking-wide text-slate-400">
            <div className="px-4 py-2 uppercase text-[10px] text-slate-500 font-black">Controls</div>
            <button className="w-full flex items-center space-x-3 px-4 py-3 bg-blue-600 text-white rounded-xl shadow-md cursor-default">
              <Globe className="h-4 w-4" />
              <span>Sovereign Command</span>
            </button>
          </nav>
        </div>

        <div className="p-4 border-t border-white/5">
          <button 
            onClick={logout}
            className="w-full flex items-center justify-center space-x-2 py-3 bg-red-950/20 border border-red-500/20 rounded-xl hover:bg-red-950/30 text-red-400 text-xs font-bold transition-all cursor-pointer"
          >
            <LogOut className="h-4 w-4" />
            <span>End Session</span>
          </button>
        </div>
      </aside>

      {/* Main Content Pane */}
      <main className="flex-1 flex flex-col overflow-y-auto p-8 space-y-8">
        
        {/* Header */}
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-white/5 pb-6">
          <div>
            <h2 className="text-2xl font-black tracking-tight">Operator Central Terminal</h2>
            <p className="text-xs text-slate-400 mt-1">Configure geofence sectors, issue weather/hazard warnings, and monitor SOS metrics.</p>
          </div>
        </header>

        {msg && (
          <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 p-4 rounded-2xl text-xs font-bold flex items-center space-x-2">
            <Check className="h-5 w-5 shrink-0" />
            <span>{msg}</span>
          </div>
        )}

        {/* Dynamic Analytics (SVG charts) */}
        <div className="grid md:grid-cols-3 gap-6">
          
          <div className={`p-6 rounded-3xl border flex flex-col justify-between ${isDark ? 'glass-card' : 'glass-card-light'}`}>
            <div>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Active SOS Load</p>
              <h4 className="text-3xl font-black mt-1 text-slate-100">
                {sosAlerts.filter(s => s.status !== 'resolved').length} Emergencies
              </h4>
            </div>
            
            {/* Simple Dynamic SVG Indicator */}
            <div className="h-16 mt-4 flex items-end space-x-1.5 bg-slate-950/40 p-2 rounded-xl">
              <div className="w-full h-[20%] bg-blue-500/20 rounded"></div>
              <div className="w-full h-[45%] bg-blue-500/30 rounded"></div>
              <div className="w-full h-[30%] bg-blue-500/20 rounded"></div>
              <div className="w-full h-[85%] bg-red-500/80 rounded animate-pulse"></div>
            </div>
          </div>

          <div className={`p-6 rounded-3xl border flex flex-col justify-between ${isDark ? 'glass-card' : 'glass-card-light'}`}>
            <div>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Secured Geofences</p>
              <h4 className="text-3xl font-black mt-1 text-slate-100">{safeZones.length} Sectors Registered</h4>
            </div>

            <div className="h-16 mt-4 flex items-end space-x-1.5 bg-slate-950/40 p-2 rounded-xl">
              <div className="w-full h-[80%] bg-purple-500/60 rounded"></div>
              <div className="w-full h-[60%] bg-purple-500/50 rounded"></div>
              <div className="w-full h-[90%] bg-purple-500/80 rounded"></div>
              <div className="w-full h-[70%] bg-purple-500/60 rounded"></div>
            </div>
          </div>

          <div className={`p-6 rounded-3xl border flex flex-col justify-between ${isDark ? 'glass-card' : 'glass-card-light'}`}>
            <div>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Broadcasted Security Alerts</p>
              <h4 className="text-3xl font-black mt-1 text-slate-100">{alerts.length} Active Feeds</h4>
            </div>

            <div className="h-16 mt-4 flex items-end space-x-1.5 bg-slate-950/40 p-2 rounded-xl">
              <div className="w-full h-[30%] bg-amber-500/40 rounded"></div>
              <div className="w-full h-[40%] bg-amber-500/50 rounded"></div>
              <div className="w-full h-[80%] bg-amber-500/80 rounded animate-pulse"></div>
              <div className="w-full h-[50%] bg-amber-500/60 rounded"></div>
            </div>
          </div>
        </div>

        {/* Forms layout */}
        <div className="grid md:grid-cols-2 gap-8">
          
          {/* Geofence safe zone creator form */}
          <div className={`p-8 rounded-3xl border space-y-6 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
            <div className="flex items-center space-x-3">
              <MapPin className="h-5 w-5 text-purple-400" />
              <h3 className="font-extrabold text-sm uppercase tracking-widest text-purple-400">Deploy New Geofence Perimeter</h3>
            </div>

            <form onSubmit={handleZoneSubmit} className="space-y-4">
              <div>
                <label className="text-[10px] text-slate-400 block mb-1">Geofence Name</label>
                <input 
                  type="text" 
                  required
                  value={zoneForm.name}
                  onChange={(e) => setZoneForm({ ...zoneForm, name: e.target.value })}
                  className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200"
                  placeholder="e.g. Champs-Élysées Central"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-1">Sector Description</label>
                <input 
                  type="text" 
                  value={zoneForm.description}
                  onChange={(e) => setZoneForm({ ...zoneForm, description: e.target.value })}
                  className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200"
                  placeholder="Tourist support perimeter details..."
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">Type</label>
                  <select 
                    value={zoneForm.type}
                    onChange={(e) => setZoneForm({ ...zoneForm, type: e.target.value })}
                    className="w-full px-4 py-2.5 bg-slate-900 border border-white/10 rounded-xl outline-none text-xs text-slate-200"
                  >
                    <option value="safe">Safe Zone</option>
                    <option value="danger">Danger Zone</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">Latitude</label>
                  <input 
                    type="text" 
                    required
                    value={zoneForm.lat}
                    onChange={(e) => setZoneForm({ ...zoneForm, lat: e.target.value })}
                    className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200 font-mono"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">Longitude</label>
                  <input 
                    type="text" 
                    required
                    value={zoneForm.lng}
                    onChange={(e) => setZoneForm({ ...zoneForm, lng: e.target.value })}
                    className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-1">Boundary Radius (Meters)</label>
                <input 
                  type="text" 
                  required
                  value={zoneForm.radius}
                  onChange={(e) => setZoneForm({ ...zoneForm, radius: e.target.value })}
                  className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200 font-mono"
                />
              </div>

              <button 
                type="submit"
                className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold uppercase rounded-xl tracking-wider transition-all cursor-pointer"
              >
                Lock Coordinates on Ledger
              </button>
            </form>
          </div>

          {/* Alert Broadcaster form */}
          <div className={`p-8 rounded-3xl border space-y-6 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
            <div className="flex items-center space-x-3">
              <Radio className="h-5 w-5 text-amber-500 animate-pulse" />
              <h3 className="font-extrabold text-sm uppercase tracking-widest text-amber-500">Transmit Emergency Alarms</h3>
            </div>

            <form onSubmit={handleAlertSubmit} className="space-y-4">
              <div>
                <label className="text-[10px] text-slate-400 block mb-1">Alert Category</label>
                <select 
                  value={alertForm.type}
                  onChange={(e) => setAlertForm({ ...alertForm, type: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-900 border border-white/10 rounded-xl outline-none text-xs text-slate-200"
                >
                  <option value="weather">Weather Forecast</option>
                  <option value="crime">Pickpocketing / Local Assault</option>
                  <option value="hazard">Civil Distress / Construction</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-1">Alert Title</label>
                <input 
                  type="text" 
                  required
                  value={alertForm.title}
                  onChange={(e) => setAlertForm({ ...alertForm, title: e.target.value })}
                  className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200"
                  placeholder="e.g. Distraction Theft Teams Active"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-1">Precaution Guidelines</label>
                <textarea 
                  required
                  rows={2}
                  value={alertForm.description}
                  onChange={(e) => setAlertForm({ ...alertForm, description: e.target.value })}
                  className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200"
                  placeholder="Recommend actions for safety..."
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">Severity</label>
                  <select 
                    value={alertForm.severity}
                    onChange={(e) => setAlertForm({ ...alertForm, severity: e.target.value })}
                    className="w-full px-4 py-2.5 bg-slate-900 border border-white/10 rounded-xl outline-none text-xs text-slate-200"
                  >
                    <option value="low">Low Severity</option>
                    <option value="medium">Medium Severity</option>
                    <option value="high">High Severity</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">Latitude</label>
                  <input 
                    type="text" 
                    required
                    value={alertForm.lat}
                    onChange={(e) => setAlertForm({ ...alertForm, lat: e.target.value })}
                    className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200 font-mono"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">Longitude</label>
                  <input 
                    type="text" 
                    required
                    value={alertForm.lng}
                    onChange={(e) => setAlertForm({ ...alertForm, lng: e.target.value })}
                    className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200 font-mono"
                  />
                </div>
              </div>

              <button 
                type="submit"
                className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold uppercase rounded-xl tracking-wider transition-all cursor-pointer"
              >
                Broadcast Security Warning
              </button>
            </form>
          </div>

        </div>
      </main>
    </div>
  );
}
