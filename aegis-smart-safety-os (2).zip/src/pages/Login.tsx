import React, { useState } from 'react';
import { useApp, Role } from '../context/AppContext';
import { Shield, ArrowLeft, Send, Lock, Mail, Key } from 'lucide-react';

export default function Login() {
  const { login, setPage, theme, resetPassword, completeReset, user } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Forgot Password / OTP states
  const [isResetMode, setIsResetMode] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [resetEmail, setResetEmail] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const isDark = theme === 'dark';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const success = await login(email, password);
      if (!success) {
        setError('Invalid credentials. Check email or password.');
      }
    } catch (e: any) {
      setError(e.message || 'An unexpected authentication error occurred.');
    } finally {
      setLoading(false);
    }
  };

  const handlePreload = (role: Role) => {
    setEmail(`${role}@safety.com`);
    setPassword(`${role}123`);
  };

  const handleTriggerReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');
    try {
      const otp = await resetPassword(resetEmail);
      setOtpSent(true);
      setSuccessMsg(`Simulated OTP generated successfully: ${otp}`);
    } catch (err: any) {
      setError(err.message || 'Failed to trigger reset.');
    }
  };

  const handleCompleteReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');
    try {
      await completeReset(resetEmail, otpCode, newPassword);
      setSuccessMsg('Your security password has been updated. You can login now.');
      setIsResetMode(false);
      setOtpSent(false);
      setEmail(resetEmail);
      setPassword(newPassword);
    } catch (err: any) {
      setError(err.message || 'Reset verification code is invalid.');
    }
  };

  return (
    <div className={`min-h-screen flex flex-col justify-center py-12 sm:px-6 lg:px-8 transition-colors duration-300 ${isDark ? 'mesh-background text-white' : 'mesh-background-light text-slate-900'}`}>
      
      {user && (
        <div className="absolute top-6 left-6">
          <button 
            onClick={() => setPage('landing')}
            className="inline-flex items-center space-x-2 text-sm font-semibold text-blue-500 hover:text-blue-400 cursor-pointer"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Return Home</span>
          </button>
        </div>
      )}

      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="mx-auto h-12 w-12 bg-blue-600 rounded-xl flex items-center justify-center glow-blue text-white mb-4">
          <Shield className="h-6 w-6" />
        </div>
        <h2 className="text-3xl font-black tracking-tight text-gradient">Sovereign Portal Login</h2>
        <p className="mt-2 text-xs text-slate-400">Authenticate credentials or use quick-login mock profiles below</p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className={`py-8 px-4 shadow sm:rounded-3xl sm:px-10 border ${isDark ? 'glass-card' : 'glass-card-light'}`}>
          
          {error && (
            <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-3 rounded-xl text-xs font-semibold mb-4">
              {error}
            </div>
          )}

          {successMsg && (
            <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 p-3 rounded-xl text-xs font-semibold mb-4">
              {successMsg}
            </div>
          )}

          {!isResetMode ? (
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div>
                <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">Registered Email</label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-3.5 h-4 w-4 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none text-sm"
                    placeholder="name@agency.com"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Security Password</label>
                  <button 
                    type="button"
                    onClick={() => { setIsResetMode(true); setError(''); setSuccessMsg(''); }}
                    className="text-xs text-blue-500 hover:text-blue-400 font-semibold"
                  >
                    Forgot Key?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-3.5 h-4 w-4 text-slate-400" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none text-sm"
                    placeholder="••••••••"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center space-x-2"
              >
                <span>{loading ? 'Authenticating...' : 'Sign In To Dashboard'}</span>
              </button>

              <div className="relative flex py-2 items-center">
                <div className="flex-grow border-t border-white/5"></div>
                <span className="flex-shrink mx-4 text-[10px] text-slate-500 font-semibold uppercase tracking-wider">Demo Account Quick Load</span>
                <div className="flex-grow border-t border-white/5"></div>
              </div>

              {/* Grid of quick loaders */}
              <div className="grid grid-cols-2 gap-2 text-xs font-bold">
                <button 
                  type="button" 
                  onClick={() => handlePreload('tourist')} 
                  className="py-2.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all text-[11px]"
                >
                  🗼 Tourist Log
                </button>
                <button 
                  type="button" 
                  onClick={() => handlePreload('police')} 
                  className="py-2.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all text-[11px]"
                >
                  🚓 Police Log
                </button>
                <button 
                  type="button" 
                  onClick={() => handlePreload('hospital')} 
                  className="py-2.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all text-[11px]"
                >
                  🏥 Hospital Log
                </button>
                <button 
                  type="button" 
                  onClick={() => handlePreload('embassy')} 
                  className="py-2.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all text-[11px]"
                >
                  🇪🇺 Embassy Log
                </button>
              </div>
              <button 
                type="button" 
                onClick={() => handlePreload('admin')} 
                className="w-full py-2.5 bg-blue-900/20 border border-blue-500/20 rounded-xl hover:bg-blue-900/30 transition-all text-[11px] font-bold text-blue-400"
              >
                🛡️ Global Admin Command Log
              </button>
            </form>
          ) : (
            // Forgot Password Form with OTP Verification
            <div className="space-y-6">
              <h3 className="font-extrabold text-lg text-blue-400">Decrypt Key / Reset Password</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Enter your registered profile email. We will generate a secure OTP reset verification key on the simulated console system immediately.
              </p>

              {!otpSent ? (
                <form onSubmit={handleTriggerReset} className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">Account Email</label>
                    <input 
                      type="email" 
                      required
                      value={resetEmail}
                      onChange={(e) => setResetEmail(e.target.value)}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none text-sm text-slate-200"
                      placeholder="tourist@safety.com"
                    />
                  </div>
                  <div className="flex space-x-3">
                    <button 
                      type="button" 
                      onClick={() => setIsResetMode(false)}
                      className="w-1/3 py-3 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-bold text-slate-300"
                    >
                      Back
                    </button>
                    <button 
                      type="submit" 
                      className="w-2/3 py-3 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl"
                    >
                      Request Security OTP
                    </button>
                  </div>
                </form>
              ) : (
                <form onSubmit={handleCompleteReset} className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">Simulated OTP Code</label>
                    <input 
                      type="text" 
                      required
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value)}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none text-sm text-slate-200 font-mono tracking-widest text-center"
                      placeholder="123456"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">New Security Password</label>
                    <input 
                      type="password" 
                      required
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none text-sm text-slate-200"
                      placeholder="••••••••"
                    />
                  </div>
                  <div className="flex space-x-3">
                    <button 
                      type="button" 
                      onClick={() => { setOtpSent(false); }}
                      className="w-1/3 py-3 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-bold text-slate-300"
                    >
                      Reset Email
                    </button>
                    <button 
                      type="submit" 
                      className="w-2/3 py-3 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-xl"
                    >
                      Confirm Change
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          <div className="mt-6 text-center">
            <span className="text-xs text-slate-500">Need a secure digital ledger card? </span>
            <button 
              onClick={() => setPage('register')}
              className="text-xs font-bold text-blue-500 hover:text-blue-400 underline cursor-pointer"
            >
              Register Passport
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}
