import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Shield, ArrowLeft, Mail, Lock, User, FileText, Heart, Plus } from 'lucide-react';

export default function Register() {
  const { register, setPage, theme, user } = useApp();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    phone: '',
    nationality: 'United States',
    passportNumber: '',
    bloodType: 'O-Positive',
    medicalConditions: '',
    emergencyContactName: '',
    emergencyContactPhone: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const isDark = theme === 'dark';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (!formData.email || !formData.password || !formData.name || !formData.passportNumber) {
      setError('Please fill in all core fields including Passport Number.');
      setLoading(false);
      return;
    }

    try {
      const success = await register(formData);
      if (!success) {
        setError('Registration failed. Email might already be taken.');
      }
    } catch (e: any) {
      setError(e.message || 'An unexpected registration error occurred.');
    } finally {
      setLoading(false);
    }
  };

  const countries = [
    'United States', 'Canada', 'United Kingdom', 'Germany', 'France', 
    'Japan', 'Australia', 'Singapore', 'India', 'Brazil', 'Other'
  ];

  const bloodTypes = ['A-Positive', 'A-Negative', 'B-Positive', 'B-Negative', 'AB-Positive', 'AB-Negative', 'O-Positive', 'O-Negative'];

  return (
    <div className={`min-h-screen py-12 px-4 sm:px-6 lg:px-8 transition-colors duration-300 ${isDark ? 'mesh-background text-white' : 'mesh-background-light text-slate-900'}`}>
      
      {user && (
        <div className="absolute top-6 left-6">
          <button 
            onClick={() => setPage('landing')}
            className="inline-flex items-center space-x-2 text-sm font-semibold text-blue-500 hover:text-blue-400 cursor-pointer"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Return Home</span>
          </button>
        </div>
      )}

      <div className="max-w-xl mx-auto space-y-8">
        <div className="text-center">
          <div className="mx-auto h-12 w-12 bg-blue-600 rounded-xl flex items-center justify-center glow-blue text-white mb-4">
            <Shield className="h-6 w-6" />
          </div>
          <h2 className="text-3xl font-black tracking-tight text-gradient">Create Cryptographic Safety ID</h2>
          <p className="text-xs text-slate-400 mt-2">Initialize your sovereign on-chain travel passport and first-responder profiles</p>
        </div>

        <div className={`p-8 rounded-3xl border shadow ${isDark ? 'glass-card' : 'glass-card-light'}`}>
          {error && (
            <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-3 rounded-xl text-xs font-semibold mb-6">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* Core credentials */}
            <div className="border-b border-white/5 pb-4 space-y-4">
              <h3 className="font-bold text-sm uppercase tracking-wider text-blue-400">1. Account Credentials</h3>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-2">Full Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Sarah Jenkins"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-2">Email Address</label>
                  <input
                    type="email"
                    required
                    placeholder="sarah@travel.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200 focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-2">Password</label>
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-2">Mobile Phone</label>
                  <input
                    type="text"
                    required
                    placeholder="+1 (555) 019-2834"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200 focus:border-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Cryptographic ID details */}
            <div className="border-b border-white/5 pb-4 space-y-4">
              <h3 className="font-bold text-sm uppercase tracking-wider text-purple-400">2. Passport Information (For Ledger Verification)</h3>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-2">Passport Number</label>
                  <input
                    type="text"
                    required
                    placeholder="A9821734"
                    value={formData.passportNumber}
                    onChange={(e) => setFormData({ ...formData, passportNumber: e.target.value })}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-2">Nationality</label>
                  <select
                    value={formData.nationality}
                    onChange={(e) => setFormData({ ...formData, nationality: e.target.value })}
                    className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-xl outline-none text-xs text-slate-200 focus:border-blue-500"
                  >
                    {countries.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>
            </div>

            {/* Medical Profiles */}
            <div className="border-b border-white/5 pb-4 space-y-4">
              <h3 className="font-bold text-sm uppercase tracking-wider text-pink-400">3. Sovereign Emergency Medical Record</h3>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-2">Blood Type</label>
                  <select
                    value={formData.bloodType}
                    onChange={(e) => setFormData({ ...formData, bloodType: e.target.value })}
                    className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-xl outline-none text-xs text-slate-200 focus:border-blue-500"
                  >
                    {bloodTypes.map(bt => <option key={bt} value={bt}>{bt}</option>)}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-2">Known Medical Conditions / Allergies</label>
                  <input
                    type="text"
                    placeholder="Penicillin Allergy, Asthmatic"
                    value={formData.medicalConditions}
                    onChange={(e) => setFormData({ ...formData, medicalConditions: e.target.value })}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200 focus:border-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Emergency Contacts */}
            <div className="space-y-4">
              <h3 className="font-bold text-sm uppercase tracking-wider text-red-400">4. Emergency Kin Contact</h3>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-2">Kin Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Sarah Jenkins (Spouse)"
                    value={formData.emergencyContactName}
                    onChange={(e) => setFormData({ ...formData, emergencyContactName: e.target.value })}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-2">Kin Phone Number</label>
                  <input
                    type="text"
                    required
                    placeholder="+1 (555) 345-6789"
                    value={formData.emergencyContactPhone}
                    onChange={(e) => setFormData({ ...formData, emergencyContactPhone: e.target.value })}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl outline-none text-xs text-slate-200 focus:border-blue-500"
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center space-x-2"
              id="submit-register"
            >
              <span>{loading ? 'Issuing Digital Card...' : 'Issue Digital Tourist ID'}</span>
            </button>
          </form>

          <div className="mt-6 text-center">
            <span className="text-xs text-slate-400">Already registered? </span>
            <button 
              onClick={() => setPage('login')}
              className="text-xs font-bold text-blue-500 hover:text-blue-400 underline cursor-pointer"
            >
              Log In
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
