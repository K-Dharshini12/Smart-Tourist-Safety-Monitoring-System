import React from 'react';
import { useApp } from '../context/AppContext';
import { ArrowLeft, Shield, Heart, Landmark, PlusCircle, CheckCircle, Users, Activity, HelpCircle } from 'lucide-react';

export default function Services() {
  const { setPage, theme } = useApp();
  const isDark = theme === 'dark';

  return (
    <div className={`min-h-screen py-16 px-6 transition-colors duration-300 ${isDark ? 'mesh-background text-white' : 'mesh-background-light text-slate-900'}`}>
      <div className="max-w-6xl mx-auto space-y-16">
        
        {/* Navigation back and header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-8">
          <button 
            onClick={() => setPage('landing')}
            className="inline-flex items-center space-x-2 text-sm font-semibold text-blue-500 hover:text-blue-400 cursor-pointer w-fit"
            id="back-to-home-btn"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Return Home</span>
          </button>
          
          <div className="flex items-center space-x-3 text-xs font-mono">
            <span className="opacity-50">PARTNER RESPONSE:</span>
            <span className="h-2.5 w-2.5 bg-emerald-500 rounded-full animate-pulse"></span>
            <span className="font-extrabold text-emerald-400">OPERATIONAL</span>
          </div>
        </div>

        {/* Hero Section */}
        <div className="space-y-6 max-w-3xl">
          <div className="bg-emerald-500/10 text-emerald-400 px-3 py-1 rounded-full text-xs font-bold w-fit border border-emerald-500/20">
            INTEGRATED RESPONSE SERVICES
          </div>
          <h1 className="text-4xl md:text-5xl font-black tracking-tight leading-none">
            Coordinated Responders, <br />
            <span className="text-gradient">Universal Protection</span>
          </h1>
          <p className="text-slate-400 text-sm md:text-base leading-relaxed">
            Sentinel is more than a tracking app. We coordinate direct integrations into municipal response dashboards, trauma care facilities, and national consular centers.
          </p>
        </div>

        {/* The 3 Core Integrations Breakdown */}
        <div className="grid lg:grid-cols-3 gap-8">
          
          {/* Service 1: Law Enforcement */}
          <div className={`p-8 rounded-3xl border space-y-6 relative overflow-hidden ${isDark ? 'glass-card' : 'glass-card-light'}`}>
            <div className="bg-blue-600/10 p-4 rounded-2xl text-blue-400 w-fit">
              <Shield className="h-8 w-8" />
            </div>
            
            <div className="space-y-2">
              <h3 className="text-xl font-bold">Law Enforcement Portals</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Direct dispatch links connect tourist SOS panics directly into local police station monitoring consoles.
              </p>
            </div>

            <div className="border-t border-white/5 pt-4 space-y-3">
              <h4 className="text-[10px] font-mono uppercase text-slate-500">Key Capabilities:</h4>
              <ul className="space-y-2 text-xs">
                <li className="flex items-center space-x-2 text-slate-300">
                  <CheckCircle className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span>Real-time GPS coordinate reporting</span>
                </li>
                <li className="flex items-center space-x-2 text-slate-300">
                  <CheckCircle className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span>Secure 2-way emergency messaging</span>
                </li>
                <li className="flex items-center space-x-2 text-slate-300">
                  <CheckCircle className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span>Instant verification of digital IDs</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Service 2: Trauma Care */}
          <div className={`p-8 rounded-3xl border space-y-6 relative overflow-hidden ${isDark ? 'glass-card' : 'glass-card-light'}`}>
            <div className="bg-rose-600/10 p-4 rounded-2xl text-rose-400 w-fit">
              <Heart className="h-8 w-8" />
            </div>
            
            <div className="space-y-2">
              <h3 className="text-xl font-bold">Trauma & Hospital Networks</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Emergency rooms possess the clinical facts they need to save your life even if you are unconscious.
              </p>
            </div>

            <div className="border-t border-white/5 pt-4 space-y-3">
              <h4 className="text-[10px] font-mono uppercase text-slate-500">Key Capabilities:</h4>
              <ul className="space-y-2 text-xs">
                <li className="flex items-center space-x-2 text-slate-300">
                  <CheckCircle className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span>Instant access to registered blood types</span>
                </li>
                <li className="flex items-center space-x-2 text-slate-300">
                  <CheckCircle className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span>Secure allergies & conditions listing</span>
                </li>
                <li className="flex items-center space-x-2 text-slate-300">
                  <CheckCircle className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span>Emergency contact speed-dial hotwire</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Service 3: Embassies */}
          <div className={`p-8 rounded-3xl border space-y-6 relative overflow-hidden ${isDark ? 'glass-card' : 'glass-card-light'}`}>
            <div className="bg-purple-600/10 p-4 rounded-2xl text-purple-400 w-fit">
              <Landmark className="h-8 w-8" />
            </div>
            
            <div className="space-y-2">
              <h3 className="text-xl font-bold">Embassy & Consulate Auditing</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Diplomatic offices monitor state citizens, coordinate safe-havens, and replace documentation on-ledger.
              </p>
            </div>

            <div className="border-t border-white/5 pt-4 space-y-3">
              <h4 className="text-[10px] font-mono uppercase text-slate-500">Key Capabilities:</h4>
              <ul className="space-y-2 text-xs">
                <li className="flex items-center space-x-2 text-slate-300">
                  <CheckCircle className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span>Cryptographic passport validation</span>
                </li>
                <li className="flex items-center space-x-2 text-slate-300">
                  <CheckCircle className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span>Immediate diplomatic notifications</span>
                </li>
                <li className="flex items-center space-x-2 text-slate-300">
                  <CheckCircle className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span>Sovereign boundary monitoring</span>
                </li>
              </ul>
            </div>
          </div>

        </div>

        {/* Extra option: Public Safety Advisor Directory / Safe Zone Maps info */}
        <div className={`p-8 md:p-12 rounded-3xl border ${isDark ? 'glass-card' : 'glass-card-light'} grid md:grid-cols-2 gap-8 items-center`}>
          <div className="space-y-5">
            <h3 className="text-2xl font-black">Want to Verify Your QR Identity?</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Every Sentinel Safety Card carries a cryptographic QR code payload verified directly against the blockchain distributed ledger. Law enforcement or medical responders can use our public explorer tool to check the status of any safety card.
            </p>
            <div className="pt-2">
              <button 
                onClick={() => setPage('ledger-explorer')}
                className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl transition-all glow-blue flex items-center space-x-2 cursor-pointer"
                id="services-to-explorer-btn"
              >
                <span>Launch Cryptographic Ledger Explorer</span>
              </button>
            </div>
          </div>

          <div className="relative h-48 rounded-2xl overflow-hidden bg-slate-950/60 border border-white/5 flex flex-col justify-center items-center p-6 text-center space-y-3">
            <Activity className="h-10 w-10 text-emerald-400 animate-pulse" />
            <h4 className="font-mono text-xs font-bold uppercase tracking-wider">ACTIVE EMERGENCY PROTOCOL</h4>
            <p className="text-[10px] text-slate-500 max-w-sm">
              During an SOS trigger, coordinates and medical profiles are instantly shared across police, hospital, and diplomatic portals for a cohesive search and rescue operation.
            </p>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center pt-8 border-t border-white/5 space-y-6">
          <h3 className="text-2xl font-extrabold">Ready to secure your travels?</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
            Register your tourist account, link your digital passport coordinates, and gain immediate coverage by our global responder networks.
          </p>
          <div className="flex justify-center gap-4">
            <button 
              onClick={() => setPage('register')}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition-all glow-blue cursor-pointer"
            >
              Issue Digital ID
            </button>
            <button 
              onClick={() => setPage('faq')}
              className={`px-6 py-3 font-bold rounded-xl border transition-all cursor-pointer ${isDark ? 'border-white/10 hover:bg-white/5' : 'border-slate-900/10 hover:bg-slate-900/5'}`}
            >
              Consult Security FAQ
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
