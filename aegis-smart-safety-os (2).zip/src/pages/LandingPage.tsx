import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Shield, Compass, Cpu, QrCode, TrendingUp, Database, 
  ArrowRight, Users, Bell, CloudRain, ShieldCheck, Zap, AlertTriangle
} from 'lucide-react';

// ==========================================
// 3D HOLOGRAPHIC GEOSPATIAL GLOBE COMPONENT
// ==========================================
function HolographicGlobe({ isDark }: { isDark: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let rotation = 0;
    const radius = 150;
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    // Tactical cities coordinates (latitude, longitude, name)
    const cities = [
      { lat: 48.8566, lng: 2.3522, name: 'PARIS (HQ)' },
      { lat: 40.7128, lng: -74.0060, name: 'NEW YORK' },
      { lat: 35.6762, lng: 139.6503, name: 'TOKYO' },
      { lat: -33.8688, lng: 151.2093, name: 'SYDNEY' },
      { lat: 51.5074, lng: -0.1278, name: 'LONDON' },
      { lat: 1.3521, lng: 103.8198, name: 'SINGAPORE' }
    ];

    // Flight paths connecting cities (origin index, destination index)
    const flightPaths = [
      { from: 1, to: 0 }, // New York -> Paris
      { from: 0, to: 4 }, // Paris -> London
      { from: 4, to: 2 }, // London -> Tokyo
      { from: 2, to: 3 }, // Tokyo -> Sydney
      { from: 3, to: 5 }, // Sydney -> Singapore
      { from: 5, to: 0 }  // Singapore -> Paris
    ];

    // Particle nodes orbiting globe
    const particles: Array<{ x: number; y: number; z: number; angle: number; speed: number; radius: number }> = [];
    for (let i = 0; i < 40; i++) {
      particles.push({
        x: 0,
        y: (Math.random() - 0.5) * 360,
        z: 0,
        angle: Math.random() * Math.PI * 2,
        speed: 0.005 + Math.random() * 0.01,
        radius: 1 + Math.random() * 2
      });
    }

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      rotation += 0.004; // rotation rate

      const mainColor = isDark ? '#2563EB' : '#1d4ed8'; // Royal Blue
      const safeColor = isDark ? '#10B981' : '#059669'; // Emerald Green
      const accentColor = isDark ? '#F59E0B' : '#d97706'; // Orange / Amber
      const gridOpacity = isDark ? 0.08 : 0.15;

      // 1. Draw glowing background grid aura
      const radialGlow = ctx.createRadialGradient(centerX, centerY, 5, centerX, centerY, radius + 80);
      radialGlow.addColorStop(0, isDark ? 'rgba(37, 99, 235, 0.12)' : 'rgba(37, 99, 235, 0.08)');
      radialGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = radialGlow;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // 2. Draw outer atmospheric protection ring
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius + 25, 0, Math.PI * 2);
      ctx.strokeStyle = isDark ? 'rgba(37, 99, 235, 0.15)' : 'rgba(37, 99, 235, 0.25)';
      ctx.lineWidth = 1;
      ctx.stroke();

      // Outer satellite nodes orbiting on outer ring
      for (let i = 0; i < 3; i++) {
        const satAngle = rotation * 1.5 + (i * Math.PI * 2) / 3;
        const satX = centerX + Math.cos(satAngle) * (radius + 25);
        const satY = centerY + Math.sin(satAngle) * (radius + 25);
        
        ctx.beginPath();
        ctx.arc(satX, satY, 3.5, 0, Math.PI * 2);
        ctx.fillStyle = safeColor;
        ctx.fill();

        ctx.beginPath();
        ctx.arc(satX, satY, 10, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(16, 185, 129, 0.3)';
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      // 3. Draw 3D wireframe Globe grid lines
      // Latitude grid loops (horizontal circles)
      for (let lat = -75; lat <= 75; lat += 15) {
        const theta = (lat * Math.PI) / 180;
        const r = radius * Math.cos(theta);
        const y = centerY + radius * Math.sin(theta);

        ctx.beginPath();
        // Project ellipse for the circle rotating in 3D
        ctx.ellipse(centerX, y, r, r * 0.25, 0, 0, Math.PI * 2);
        ctx.strokeStyle = isDark ? `rgba(96, 165, 250, ${gridOpacity})` : `rgba(37, 99, 235, ${gridOpacity})`;
        ctx.lineWidth = 0.8;
        ctx.stroke();
      }

      // Longitude grid loops (vertical circles rotating)
      for (let lon = 0; lon < 180; lon += 20) {
        const theta = ((lon + rotation * 57.29) * Math.PI) / 180;
        ctx.beginPath();
        ctx.ellipse(centerX, centerY, radius * Math.abs(Math.sin(theta)), radius, 0, 0, Math.PI * 2);
        ctx.strokeStyle = isDark ? `rgba(96, 165, 250, ${gridOpacity * 0.6})` : `rgba(37, 99, 235, ${gridOpacity * 0.6})`;
        ctx.lineWidth = 0.5;
        ctx.stroke();
      }

      // 3D Coordinate projection function
      const project = (lat: number, lng: number) => {
        const radLat = (lat * Math.PI) / 180;
        const radLng = ((lng + rotation * 57.29) * Math.PI) / 180;

        const x = radius * Math.cos(radLat) * Math.sin(radLng);
        const y = radius * Math.sin(radLat);
        const z = radius * Math.cos(radLat) * Math.cos(radLng);

        return {
          px: centerX + x,
          py: centerY - y,
          visible: z > 0 // point faces the camera
        };
      };

      // 4. Draw city pins and text details
      const projectedCities = cities.map(city => ({
        ...city,
        ...project(city.lat, city.lng)
      }));

      projectedCities.forEach(city => {
        if (!city.visible) return;

        // Draw outer pulsing safe ring
        const pulse = 4 + (Date.now() % 1000) / 150;
        ctx.beginPath();
        ctx.arc(city.px, city.py, pulse, 0, Math.PI * 2);
        ctx.strokeStyle = isDark ? 'rgba(16, 185, 129, 0.4)' : 'rgba(5, 96, 105, 0.3)';
        ctx.lineWidth = 1;
        ctx.stroke();

        // Core pin
        ctx.beginPath();
        ctx.arc(city.px, city.py, 3, 0, Math.PI * 2);
        ctx.fillStyle = safeColor;
        ctx.fill();

        // Name tag
        ctx.fillStyle = isDark ? '#ffffff' : '#0f172a';
        ctx.font = 'bold 8px monospace';
        ctx.fillText(city.name, city.px + 7, city.py + 3);
      });

      // 5. Draw Flight corridors connecting nodes
      flightPaths.forEach(path => {
        const fromCity = projectedCities[path.from];
        const toCity = projectedCities[path.to];

        if (fromCity.visible && toCity.visible) {
          ctx.beginPath();
          ctx.moveTo(fromCity.px, fromCity.py);
          
          // Draw quadratic curve for elegant arc path representation
          const midX = (fromCity.px + toCity.px) / 2;
          const midY = (fromCity.py + toCity.py) / 2 - 40; // curve upwards
          ctx.quadraticCurveTo(midX, midY, toCity.px, toCity.py);

          ctx.strokeStyle = isDark ? 'rgba(96, 165, 250, 0.2)' : 'rgba(37, 99, 235, 0.25)';
          ctx.lineWidth = 1;
          ctx.stroke();

          // Draw active signal packet traveling across flight arc
          const t = (Date.now() % 2500) / 2500;
          const packetX = (1 - t) * (1 - t) * fromCity.px + 2 * (1 - t) * t * midX + t * t * toCity.px;
          const packetY = (1 - t) * (1 - t) * fromCity.py + 2 * (1 - t) * t * midY + t * t * toCity.py;

          ctx.beginPath();
          ctx.arc(packetX, packetY, 2, 0, Math.PI * 2);
          ctx.fillStyle = accentColor;
          ctx.fill();
        }
      });

      // 6. Orbiting network AI particles
      particles.forEach(p => {
        p.angle += p.speed;
        const x = (radius + 15) * Math.cos(p.angle);
        const z = (radius + 15) * Math.sin(p.angle);
        
        // Tilt particle orbit slightly for dynamic 3D look
        const px = centerX + x;
        const py = centerY + z * 0.15 + p.y * 0.8;

        if (z > 0) { // Render only front particles (overlay)
          ctx.beginPath();
          ctx.arc(px, py, p.radius, 0, Math.PI * 2);
          ctx.fillStyle = isDark ? 'rgba(96, 165, 250, 0.45)' : 'rgba(37, 99, 235, 0.5)';
          ctx.fill();
        }
      });

      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isDark]);

  return (
    <div className="relative flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-radial-gradient from-blue-500/5 to-transparent pointer-events-none rounded-full"></div>
      <canvas 
        ref={canvasRef} 
        width={420} 
        height={420} 
        className="w-full max-w-[420px] aspect-square drop-shadow-[0_0_35px_rgba(37,99,235,0.15)] filter"
      />
    </div>
  );
}

export default function LandingPage() {
  const { setPage, theme } = useApp();
  const isDark = theme === 'dark';

  const [stats, setStats] = useState({
    activeTourists: 14209,
    emergenciesHandled: 2841,
    securedZones: 48,
    syncedBlocks: 15438321
  });

  // Numbers increment timer
  useEffect(() => {
    const timer = setInterval(() => {
      setStats(prev => ({
        activeTourists: prev.activeTourists + (Math.random() > 0.8 ? 1 : 0),
        emergenciesHandled: prev.emergenciesHandled + (Math.random() > 0.95 ? 1 : 0),
        securedZones: prev.securedZones,
        syncedBlocks: prev.syncedBlocks + 1
      }));
    }, 4500);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen pb-24">
      
      {/* ==========================================
          HERO UNIT - 3D GLOBAL COMMAND CENTER
         ========================================== */}
      <section className="relative overflow-hidden py-10 sm:py-16 px-4 sm:px-6 border-b border-white/5">
        
        {/* Subtle decorative vector mesh background */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-blue-500/5 rounded-full blur-3xl pointer-events-none"></div>

        <div className="max-w-7xl mx-auto grid lg:grid-cols-12 gap-8 items-center relative z-10">
          
          {/* Hero text branding */}
          <div className="lg:col-span-7 space-y-6 text-left">
            <div className="inline-flex items-center space-x-2 bg-blue-500/10 text-blue-400 px-4 py-1.5 rounded-full text-[10px] sm:text-xs font-mono tracking-widest uppercase border border-blue-500/20">
              <Zap className="h-3 w-3 text-amber-400 animate-pulse" />
              <span>Sovereign Security Framework Active</span>
            </div>
            
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-[1.05]">
              Smart Tourist Safety <br />
              <span className="text-gradient">Monitoring System</span>
            </h1>
            
            <p className="text-slate-400 text-xs sm:text-sm md:text-base max-w-xl leading-relaxed">
              Travel protected by decentralized intelligence. Aegis OS envelopes global tourists in a cryptographic sanctuary combining neural risk heuristics, live geofence triggers, and blockchain-sealed digital identity logs.
            </p>

            {/* Dynamic Stats Section */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-3xl border border-white/5 bg-slate-950/20 backdrop-blur-md">
              <div className="text-left">
                <p className="text-[10px] font-mono font-extrabold uppercase text-slate-500 tracking-wider">Active Patrols</p>
                <p className="text-lg font-black text-white mt-0.5">{stats.activeTourists.toLocaleString()}</p>
                <span className="text-[9px] text-emerald-400 font-bold">● Grid Live</span>
              </div>
              <div className="text-left">
                <p className="text-[10px] font-mono font-extrabold uppercase text-slate-500 tracking-wider">SOS Solved</p>
                <p className="text-lg font-black text-white mt-0.5">{stats.emergenciesHandled.toLocaleString()}</p>
                <span className="text-[9px] text-blue-400 font-bold">▲ 99.8% SLA</span>
              </div>
              <div className="text-left">
                <p className="text-[10px] font-mono font-extrabold uppercase text-slate-500 tracking-wider">Safe Sectors</p>
                <p className="text-lg font-black text-white mt-0.5">{stats.securedZones} zones</p>
                <span className="text-[9px] text-emerald-400 font-bold">✓ Monitored</span>
              </div>
              <div className="text-left">
                <p className="text-[10px] font-mono font-extrabold uppercase text-slate-500 tracking-wider">Ledger Block</p>
                <p className="text-lg font-black text-white mt-0.5 truncate font-mono text-gradient">{stats.syncedBlocks}</p>
                <span className="text-[9px] text-pink-400 font-bold">🔒 Cryptographic</span>
              </div>
            </div>

            {/* Interaction Call to Actions */}
            <div className="flex flex-wrap gap-3.5">
              <button 
                onClick={() => setPage('command-deck')}
                className="px-6 py-3.5 text-xs font-black uppercase tracking-wider bg-blue-600 hover:bg-blue-500 text-white rounded-xl shadow-xl hover:shadow-blue-500/20 transition-all cursor-pointer flex items-center space-x-2"
              >
                <span>Launch Tactical Map</span>
                <ArrowRight className="h-4 w-4" />
              </button>
              
              <button 
                onClick={() => {
                  const targetElement = document.getElementById('bento-portal-grid');
                  if (targetElement) {
                    targetElement.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
                className={`px-5 py-3.5 text-xs font-bold uppercase tracking-wider border rounded-xl cursor-pointer transition-colors ${isDark ? 'border-white/10 hover:bg-white/5 text-slate-300' : 'border-slate-900/10 hover:bg-slate-900/5 text-slate-700'}`}
              >
                Explore Modules
              </button>
              
              <button 
                onClick={() => {
                  setPage('command-deck');
                  setTimeout(() => {
                    const simBtn = document.getElementById('demo-shortcut-walk-trigger');
                    if (simBtn) {
                      simBtn.scrollIntoView({ behavior: 'smooth' });
                      simBtn.click();
                    }
                  }, 150);
                }}
                className="px-5 py-3.5 text-xs font-bold uppercase tracking-wider bg-red-600/10 border border-red-500/30 text-red-400 hover:bg-red-600 hover:text-white rounded-xl transition-all cursor-pointer"
              >
                Emergency Demo
              </button>
            </div>

          </div>

          {/* Interactive Globe column */}
          <div className="lg:col-span-5 flex justify-center items-center">
            <HolographicGlobe isDark={isDark} />
          </div>

        </div>
      </section>

      {/* ==========================================
          BENTO PORTAL GRID SECTIONS
         ========================================== */}
      <section id="bento-portal-grid" className="max-w-7xl mx-auto px-4 sm:px-6 py-12 space-y-8">
        
        <div className="text-left space-y-1">
          <p className="text-[10px] font-mono font-bold uppercase text-blue-400 tracking-widest">AEGIS MODULAR MATRIX</p>
          <h2 className="text-2xl sm:text-3.5xl font-black tracking-tight text-white">
            Futuristic Safety Command Modules
          </h2>
          <p className="text-slate-500 text-xs sm:text-sm max-w-xl">
            Select a specialized command module from our unified control room to interact with spatial simulations, neural algorithms, and blockchain records.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          {/* Card 1: Map & SOS Command Deck */}
          <div className={`p-6 rounded-[24px] border ${isDark ? 'glass-card hover:border-blue-500/40' : 'glass-card-light hover:border-blue-500/35'} transition-all hover:scale-[1.01] flex flex-col justify-between space-y-6 group`}>
            <div className="space-y-4">
              <div className="bg-blue-500/10 p-3.5 rounded-2xl text-blue-400 w-fit">
                <Compass className="h-6 w-6 animate-spin-slow" />
              </div>
              <div className="space-y-1.5 text-left">
                <h3 className="font-extrabold text-lg text-white">🌍 Interactive Geofence Map</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  High-contrast spatial monitoring grid of Paris. Simulate real tourist path walks, geofenced zone breaches, and trigger live police cruiser rescues.
                </p>
              </div>
            </div>
            
            <button 
              onClick={() => setPage('command-deck')}
              className="w-full py-3 bg-blue-600/10 border border-blue-500/35 text-blue-400 hover:bg-blue-600 hover:text-white rounded-xl text-xs font-black transition-all uppercase cursor-pointer flex items-center justify-center space-x-2"
            >
              <span>Explore Map Simulator</span>
              <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Card 2: AI Neural Control room */}
          <div className={`p-6 rounded-[24px] border ${isDark ? 'glass-card hover:border-purple-500/40' : 'glass-card-light hover:border-purple-500/35'} transition-all hover:scale-[1.01] flex flex-col justify-between space-y-6 group`}>
            <div className="space-y-4">
              <div className="bg-purple-500/10 p-3.5 rounded-2xl text-purple-400 w-fit">
                <Cpu className="h-6 w-6" />
              </div>
              <div className="space-y-1.5 text-left">
                <h3 className="font-extrabold text-lg text-white">🤖 Neural Risk AI Center</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Interact with Aegis AI. Real-time predictive risk parameters, localized weather adapters, and an embedded chatbot answering emergency translations.
                </p>
              </div>
            </div>
            
            <button 
              onClick={() => setPage('ai-control')}
              className="w-full py-3 bg-purple-600/10 border border-purple-500/35 text-purple-400 hover:bg-purple-600 hover:text-white rounded-xl text-xs font-black transition-all uppercase cursor-pointer flex items-center justify-center space-x-2"
            >
              <span>Access Neural Center</span>
              <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Card 3: Sovereign digital passport */}
          <div className={`p-6 rounded-[24px] border ${isDark ? 'glass-card hover:border-pink-500/40' : 'glass-card-light hover:border-pink-500/35'} transition-all hover:scale-[1.01] flex flex-col justify-between space-y-6 group`}>
            <div className="space-y-4">
              <div className="bg-pink-500/10 p-3.5 rounded-2xl text-pink-400 w-fit">
                <QrCode className="h-6 w-6" />
              </div>
              <div className="space-y-1.5 text-left">
                <h3 className="font-extrabold text-lg text-white">🆔 Decentralized DID Passport</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  View and sync your sovereign biometric passport card. Reveal medical allergies, test blockchain sealing nodes, and generate verification QR codes.
                </p>
              </div>
            </div>
            
            <button 
              onClick={() => setPage('digital-passport')}
              className="w-full py-3 bg-pink-600/10 border border-pink-500/35 text-pink-400 hover:bg-pink-600 hover:text-white rounded-xl text-xs font-black transition-all uppercase cursor-pointer flex items-center justify-center space-x-2"
            >
              <span>Seal Digital ID</span>
              <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Card 4: Security Telemetry Analytics */}
          <div className={`p-6 rounded-[24px] border ${isDark ? 'glass-card hover:border-emerald-500/40' : 'glass-card-light hover:border-emerald-500/35'} transition-all hover:scale-[1.01] flex flex-col justify-between space-y-6 group`}>
            <div className="space-y-4">
              <div className="bg-emerald-500/10 p-3.5 rounded-2xl text-emerald-400 w-fit">
                <TrendingUp className="h-6 w-6" />
              </div>
              <div className="space-y-1.5 text-left">
                <h3 className="font-extrabold text-lg text-white">📈 Live Response Analytics</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  High-fidelity telemetric monitoring dashboards. Track dispatcher response times, hourly geofence crossings, and incident metrics on custom SVG graphs.
                </p>
              </div>
            </div>
            
            <button 
              onClick={() => setPage('live-analytics')}
              className="w-full py-3 bg-emerald-600/10 border border-emerald-500/35 text-emerald-400 hover:bg-emerald-600 hover:text-white rounded-xl text-xs font-black transition-all uppercase cursor-pointer flex items-center justify-center space-x-2"
            >
              <span>Open Stats Dashboard</span>
              <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Card 6: Embedded safety guide ticker */}
          <div className={`p-6 rounded-[24px] border ${isDark ? 'border-white/5 bg-slate-950/40 text-white' : 'border-slate-900/5 bg-white text-slate-900'} flex flex-col justify-between space-y-5 text-left`}>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-[9px] font-mono font-bold uppercase tracking-wider text-slate-500">Security Bulletin</span>
                <Bell className="h-4 w-4 text-amber-500 animate-bounce" />
              </div>
              
              <div className="space-y-3">
                <div className="flex items-start space-x-3 text-xs">
                  <div className="mt-0.5 bg-red-500/10 text-red-500 p-1 rounded-lg">
                    <AlertTriangle className="h-3 w-3" />
                  </div>
                  <div>
                    <h5 className="font-extrabold text-[11px] text-red-400">Rain & Flood advisory</h5>
                    <p className="text-[10px] text-slate-400 mt-0.5">Torrents around Seine Banks, avoid low-lying metro corridors.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3 text-xs">
                  <div className="mt-0.5 bg-emerald-500/10 text-emerald-500 p-1 rounded-lg">
                    <ShieldCheck className="h-3 w-3" />
                  </div>
                  <div>
                    <h5 className="font-extrabold text-[11px] text-emerald-400">Louvre Safe corridor fully open</h5>
                    <p className="text-[10px] text-slate-400 mt-0.5">Heavy police presence guarantees immediate safe paths.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-white/5 text-center flex items-center justify-between text-[10px] font-mono font-bold text-emerald-500">
              <span>● PERIMETER STABLE</span>
              <span>GPS SYNCED</span>
            </div>
          </div>

        </div>

      </section>

    </div>
  );
}
