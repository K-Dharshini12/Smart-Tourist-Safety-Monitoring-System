import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Shield, QrCode, CheckCircle2, Navigation, Compass, AlertCircle, Copy, Check } from "lucide-react";
import { AppScreen, TouristProfile } from "../types";

interface TouristIDGeneratorProps {
  profile: TouristProfile;
  onNavigate: (screen: AppScreen) => void;
}

export default function TouristIDGenerator({ profile, onNavigate }: TouristIDGeneratorProps) {
  const [copied, setCopied] = useState(false);
  const [activationState, setActivationState] = useState<"idle" | "generating" | "active">("generating");
  const [scanValue, setScanValue] = useState(0);

  useEffect(() => {
    // Simulate high-security ID compilation
    const timer = setTimeout(() => {
      setActivationState("active");
    }, 2500);

    // Simulate matrix scanline motion
    const scanTimer = setInterval(() => {
      setScanValue((prev) => (prev >= 100 ? 0 : prev + 1.5));
    }, 50);

    return () => {
      clearTimeout(timer);
      clearInterval(scanTimer);
    };
  }, []);

  const handleCopyId = () => {
    navigator.clipboard.writeText(profile.touristId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative min-h-screen bg-white overflow-x-hidden text-gray-100 flex flex-col font-sans">
      {/* Background travel image with gradient overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-15 mix-blend-overlay pointer-events-none"
        style={{ backgroundImage: `url('/src/assets/images/travel_background_1784446490513.jpg')` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#020817]/95 via-[#03132e]/95 to-[#020817] pointer-events-none" />
      
      {/* Grid Pattern overlay */}
      <div className="absolute inset-0 grid-bg opacity-20 pointer-events-none" />

      {/* Passport-style digital identity watermark */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none select-none">
        <QrCode className="absolute -right-16 -bottom-16 h-96 w-96 text-cyan-600/[0.05]" strokeWidth={0.4} />
        <Shield className="absolute -left-12 -top-12 h-72 w-72 text-blue-800/[0.06] -rotate-12" strokeWidth={0.5} />
      </div>

      {/* Main Container */}
      <div className="flex-grow flex flex-col items-center justify-center px-6 py-12 relative z-10 max-w-4xl mx-auto w-full">
        <div className="text-center mb-10">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="inline-flex items-center space-x-2 bg-emerald-950/40 border border-emerald-500/20 px-3.5 py-1.5 rounded-full text-xs font-semibold tracking-wider text-emerald-400 mb-4"
          >
            <CheckCircle2 className="h-4.5 w-4.5 animate-pulse text-emerald-400" />
            <span>BIOMETRIC ENCRYPTION COMPILED</span>
          </motion.div>
          <h1 className="font-display text-3xl md:text-5xl font-extrabold text-white">Digital Tourist ID</h1>
          <p className="text-gray-400 text-xs md:text-sm mt-2 max-w-md mx-auto">
            Your secure travel shield is registered. Keep this ID accessible for international emergency checkpoints and automatic rescues.
          </p>
        </div>

        {activationState === "generating" ? (
          /* High-Tech compiling state */
          <div className="glass-card w-full max-w-md rounded-2xl p-8 text-center border border-cyan-600/20 shadow-2xl h-[420px] flex flex-col items-center justify-center relative">
            <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-cyan-500 to-transparent shadow-[0_0_8px_rgba(6, 182, 212,0.5)] animate-pulse" />
            
            {/* Spinning Radar Loader */}
            <div className="relative h-24 w-24 mb-6">
              <div className="absolute inset-0 rounded-full border-4 border-cyan-600/10" />
              <div className="absolute inset-0 rounded-full border-t-4 border-cyan-500 animate-spin" />
              <div className="absolute inset-3 rounded-full border-b-2 border-blue-400/30 animate-spin-reverse" />
              <div className="absolute inset-0 flex items-center justify-center">
                <Shield className="h-8 w-8 text-cyan-500 animate-pulse" />
              </div>
            </div>

            <p className="font-mono text-xs text-cyan-500 uppercase tracking-widest mb-1.5">
              Syncing Satellite Network...
            </p>
            <p className="text-gray-400 text-[11px] font-mono leading-relaxed max-w-[280px]">
              Formatting unique QR, embedding security badge, and establishing telemetry handshakes...
            </p>
          </div>
        ) : (
          /* Compiled Premium Holographic ID Card */
          <div className="w-full max-w-md flex flex-col space-y-8">
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              transition={{ type: "spring", stiffness: 100 }}
              className="relative w-full glass-card rounded-2xl border border-cyan-600/30 shadow-[0_15px_40px_rgba(6, 182, 212,0.15)] overflow-hidden"
            >
              {/* Sci-fi top header with radar sweep line */}
              <div className="bg-gradient-to-r from-cyan-950/80 to-[#020d20] px-6 py-4 border-b border-cyan-600/20 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Shield className="h-5 w-5 text-cyan-500 glow-cyan" />
                  <span className="font-display font-black tracking-wider text-white text-sm">AEGIS DEFENSE CARD</span>
                </div>
                <div className="flex items-center space-x-1">
                  <div className="h-1.5 w-1.5 rounded-full bg-cyan-500 animate-ping" />
                  <span className="text-[9px] font-mono text-cyan-500 font-bold uppercase tracking-wider">ACTIVE FEED</span>
                </div>
              </div>

              {/* Holographic glowing swipe */}
              <div className="absolute -inset-x-20 top-0 h-40 bg-gradient-to-tr from-cyan-500/5 via-blue-400/0 to-cyan-500/5 rotate-12 pointer-events-none" />

              {/* Card Body */}
              <div className="p-6 grid grid-cols-3 gap-6 relative">
                {/* Holographic Watermark Shield */}
                <div className="absolute right-4 bottom-4 opacity-[0.03] pointer-events-none">
                  <Shield className="h-44 w-44 text-cyan-500" />
                </div>

                {/* Left Side: Photo + QR Code */}
                <div className="col-span-1 flex flex-col items-center space-y-4">
                  {/* Photo Container */}
                  <div className="relative group">
                    <img
                      src={profile.avatarUrl}
                      alt={profile.name}
                      referrerPolicy="no-referrer"
                      className="h-24 w-20 object-cover rounded-md border border-cyan-500/40 shadow-inner"
                    />
                    {/* Holographic scanlines overlay on photo */}
                    <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/5 via-transparent to-cyan-500/5 rounded-md pointer-events-none" />
                  </div>

                  {/* QR Code with custom scanline */}
                  <div className="relative h-20 w-20 bg-white/95 p-1 rounded-md border border-cyan-600/20 overflow-hidden shadow-md flex items-center justify-center">
                    {/* Custom Vector Simulated QR Code */}
                    <QrCode className="h-full w-full text-slate-900" />
                    
                    {/* Laser scanning bar effect */}
                    <div 
                      className="absolute inset-x-0 h-[1.5px] bg-cyan-500 shadow-[0_0_6px_rgba(6, 182, 212,0.8)]"
                      style={{ top: `${scanValue}%` }}
                    />
                  </div>
                </div>

                {/* Right Side: Identity Details */}
                <div className="col-span-2 flex flex-col justify-between">
                  <div>
                    {/* Verified Badge */}
                    <div className="inline-flex items-center space-x-1.5 bg-cyan-950/80 border border-cyan-500/40 px-2 py-0.5 rounded-full text-[9px] font-mono text-cyan-500 font-extrabold uppercase tracking-widest mb-3">
                      <CheckCircle2 className="h-3 w-3 text-cyan-500 fill-cyan-950" />
                      <span>Biometric Verified</span>
                    </div>

                    <h2 className="font-display font-black text-lg text-white leading-tight uppercase tracking-wide">
                      {profile.name}
                    </h2>

                    <div className="mt-4 space-y-2 border-t border-cyan-600/10 pt-3">
                      <div>
                        <p className="text-[8px] font-mono text-cyan-500/60 uppercase">Nationality</p>
                        <p className="text-xs text-white font-medium">{profile.nationality}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <p className="text-[8px] font-mono text-cyan-500/60 uppercase">Passport ID</p>
                          <p className="text-xs text-white font-mono font-medium">{profile.passportNo}</p>
                        </div>
                        <div>
                          <p className="text-[8px] font-mono text-cyan-500/60 uppercase">Register Date</p>
                          <p className="text-xs text-white font-mono font-medium">{profile.registrationDate}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Unique ID Badge bar */}
                  <div className="mt-4 p-2 bg-cyan-950/40 border border-cyan-500/20 rounded flex items-center justify-between">
                    <div>
                      <p className="text-[8px] font-mono text-cyan-500/50 uppercase">AEGIS Tourist Token</p>
                      <p className="text-[10px] font-mono text-cyan-500 font-bold">{profile.touristId}</p>
                    </div>
                    <button
                      id="copy_tourist_id_btn"
                      onClick={handleCopyId}
                      className="p-1 text-cyan-500 hover:text-white transition-colors focus:outline-none cursor-pointer"
                      title="Copy Tourist Token"
                    >
                      {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Action buttons */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="flex flex-col space-y-4"
            >
              <button
                id="activate_satellite_sync_btn"
                onClick={() => onNavigate("dashboard")}
                className="w-full py-4 bg-gradient-to-r from-cyan-500 to-blue-900 hover:from-cyan-400 hover:to-blue-800 text-white font-display font-extrabold text-sm rounded-xl transition-all flex items-center justify-center space-x-2.5 shadow-[0_0_20px_rgba(6,182,212,0.25)] hover:shadow-[0_0_35px_rgba(6,182,212,0.4)] cursor-pointer"
              >
                <Navigation className="h-5 w-5 animate-pulse" />
                <span>SYNC TELEMETRY & START JOURNEY</span>
              </button>

              <button
                id="logout_id_generator_btn"
                onClick={() => onNavigate("auth")}
                className="w-full py-3 bg-gray-950/40 hover:bg-gray-900/40 text-gray-400 hover:text-white font-mono text-xs rounded-xl border border-gray-800 hover:border-cyan-600/20 transition-all cursor-pointer"
              >
                RETURN TO PRE-FLIGHT REGISTRY
              </button>
            </motion.div>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="py-6 text-center text-[10px] font-mono text-gray-600 border-t border-cyan-600/10 bg-[#020617]/50 mt-auto">
        AEGIS PRIVACY CORE | TELEMETRY TRANSMISSION SECURED BY QUANTUM ROTATIONAL ENCRYPTIONS
      </footer>
    </div>
  );
}
