import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { 
  ArrowLeft, TrendingUp, Clock, Users, Activity, Sliders, ShieldAlert, Sparkles
} from 'lucide-react';

export default function LiveAnalytics() {
  const { setPage, theme } = useApp();
  const isDark = theme === 'dark';

  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const [activeChartFilter, setActiveChartFilter] = useState<'24h' | '7d' | '30d'>('7d');

  // Interactive live metrics that shift slightly
  const [liveKpis, setLiveKpis] = useState({
    avgResponseTime: 124, // seconds
    activeScans: 2841,
    incidentReduction: 78.4, // percentage
    criticalPatrols: 48
  });

  useEffect(() => {
    const kpiTimer = setInterval(() => {
      setLiveKpis(prev => ({
        avgResponseTime: Math.max(110, prev.avgResponseTime + (Math.random() > 0.5 ? 1 : -1) * Math.floor(Math.random() * 3)),
        activeScans: prev.activeScans + (Math.random() > 0.6 ? Math.floor(Math.random() * 4) : 0),
        incidentReduction: Math.min(99.9, Number((prev.incidentReduction + (Math.random() > 0.5 ? 0.1 : -0.1)).toFixed(1))),
        criticalPatrols: prev.criticalPatrols
      }));
    }, 4000);
    return () => clearInterval(kpiTimer);
  }, []);

  // Datasets for different filters
  const hourlyData = [
    { label: '00:00', response: 180, traffic: 450, threat: 12 },
    { label: '04:00', response: 165, traffic: 220, threat: 8 },
    { label: '08:00', response: 140, traffic: 890, threat: 15 },
    { label: '12:00', response: 115, traffic: 1420, threat: 25 },
    { label: '16:00', response: 122, traffic: 1680, threat: 30 },
    { label: '20:00', response: 130, traffic: 1100, threat: 18 },
  ];

  const weeklyData = [
    { label: 'Mon', response: 142, traffic: 980, threat: 14 },
    { label: 'Tue', response: 135, traffic: 1120, threat: 18 },
    { label: 'Wed', response: 124, traffic: 1340, threat: 22 },
    { label: 'Thu', response: 120, traffic: 1450, threat: 28 },
    { label: 'Fri', response: 148, traffic: 1890, threat: 35 },
    { label: 'Sat', response: 152, traffic: 2100, threat: 42 },
    { label: 'Sun', response: 130, traffic: 1650, threat: 20 },
  ];

  const monthlyData = [
    { label: 'Jan', response: 195, traffic: 8200, threat: 120 },
    { label: 'Feb', response: 180, traffic: 9100, threat: 105 },
    { label: 'Mar', response: 165, traffic: 10400, threat: 98 },
    { label: 'Apr', response: 150, traffic: 12800, threat: 85 },
    { label: 'May', response: 138, traffic: 14500, threat: 74 },
    { label: 'Jun', response: 124, traffic: 18900, threat: 62 },
  ];

  const activeData = activeChartFilter === '24h' ? hourlyData : activeChartFilter === '7d' ? weeklyData : monthlyData;

  // Max calculations for clean relative heights on SVG charts
  const maxTraffic = Math.max(...activeData.map(d => d.traffic));
  const maxResponse = Math.max(...activeData.map(d => d.response));
  const maxThreat = Math.max(...activeData.map(d => d.threat));

  return (
    <div className={`min-h-screen py-12 px-6 transition-colors duration-300 ${isDark ? 'mesh-background text-white' : 'mesh-background-light text-slate-900'}`}>
      <div className="max-w-7xl mx-auto space-y-10">
        
        {/* Navigation Header */}
        <div className="flex items-center justify-between border-b border-white/5 pb-6">
          <button 
            onClick={() => setPage('landing')}
            className="inline-flex items-center space-x-2 text-sm font-semibold text-blue-500 hover:text-blue-400 cursor-pointer"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Return to Landing</span>
          </button>
          
          <div className="flex items-center space-x-3 text-xs font-mono">
            <span className="opacity-50">TELEMETRY GRID ENGINE:</span>
            <span className="text-pink-400 font-bold uppercase">LIVE FEED</span>
          </div>
        </div>

        {/* Title */}
        <div className="space-y-2">
          <div className="bg-emerald-600/10 text-emerald-400 px-3 py-1 rounded-full text-xs font-bold w-fit border border-emerald-500/20">
            SOVEREIGN STATS DECK
          </div>
          <h1 className="text-3xl md:text-5xl font-black tracking-tight">
            Security Telemetry <span className="text-gradient">& Analytics Console</span>
          </h1>
          <p className="text-slate-400 text-xs md:text-sm max-w-2xl">
            Real-time visual monitoring of police cruiser dispatch latencies, geofence border queries, and localized tourist safety scores.
          </p>
        </div>

        {/* KPI Sparkline Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          
          <div className={`p-6 rounded-2xl border ${isDark ? 'glass-card' : 'glass-card-light'} space-y-3`}>
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">Avg SOS Response Time</span>
              <Clock className="h-4 w-4 text-blue-400" />
            </div>
            <div>
              <p className="text-2xl font-black text-white">{liveKpis.avgResponseTime} Seconds</p>
              <p className="text-[9px] text-emerald-400 font-semibold mt-1">▲ 14.2% faster than municipal average</p>
            </div>
          </div>

          <div className={`p-6 rounded-2xl border ${isDark ? 'glass-card' : 'glass-card-light'} space-y-3`}>
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">Active Identity Scans</span>
              <Users className="h-4 w-4 text-pink-400" />
            </div>
            <div>
              <p className="text-2xl font-black text-white">{liveKpis.activeScans.toLocaleString()}</p>
              <p className="text-[9px] text-blue-400 font-semibold mt-1">🟢 Secure ledger nodes processing block hashes</p>
            </div>
          </div>

          <div className={`p-6 rounded-2xl border ${isDark ? 'glass-card' : 'glass-card-light'} space-y-3`}>
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">Crime Index Reduction</span>
              <TrendingUp className="h-4 w-4 text-emerald-400" />
            </div>
            <div>
              <p className="text-2xl font-black text-white">-{liveKpis.incidentReduction}%</p>
              <p className="text-[9px] text-pink-400 font-semibold mt-1">🛡️ Inside sovereign blue geofenced zones</p>
            </div>
          </div>

          <div className={`p-6 rounded-2xl border ${isDark ? 'glass-card' : 'glass-card-light'} space-y-3`}>
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">Dispatched Patrols</span>
              <Activity className="h-4 w-4 text-amber-400" />
            </div>
            <div>
              <p className="text-2xl font-black text-white">{liveKpis.criticalPatrols} units</p>
              <p className="text-[9px] text-slate-500 font-semibold mt-1">🚓 On active grid patrol coordinates</p>
            </div>
          </div>

        </div>

        {/* Chart Filter selection */}
        <div className="flex justify-end">
          <div className="flex p-1 bg-slate-950/40 border border-white/5 rounded-xl gap-1">
            {(['24h', '7d', '30d'] as const).map((filt) => (
              <button
                key={filt}
                onClick={() => setActiveChartFilter(filt)}
                className={`px-4 py-1.5 text-xs font-bold rounded-lg cursor-pointer transition-all ${activeChartFilter === filt ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
              >
                {filt === '24h' ? '24 Hours' : filt === '7d' ? '7 Days' : '30 Days'}
              </button>
            ))}
          </div>
        </div>

        {/* Charts block */}
        <div className="grid lg:grid-cols-2 gap-8">
          
          {/* Chart 1: Response Time Trend (Line chart) */}
          <div className={`p-6 rounded-[24px] border ${isDark ? 'glass-card' : 'glass-card-light'} space-y-4`}>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <h3 className="font-extrabold text-sm uppercase">Emergency response latency</h3>
                <p className="text-[10px] text-slate-500">Average seconds elapsed between biometric SOS and responder lock</p>
              </div>
              <Sparkles className="h-4 w-4 text-blue-400 animate-pulse" />
            </div>

            {/* SVG line chart */}
            <div className="h-[250px] relative bg-slate-950/40 border border-white/5 rounded-xl flex items-end justify-between p-4 pt-8">
              <svg className="absolute inset-0 w-full h-full p-4 pt-8" preserveAspectRatio="none">
                {/* SVG path lines calculated on indices */}
                <path 
                  d={activeData.map((d, i) => {
                    const xPercent = (i / (activeData.length - 1)) * 100;
                    const yPercent = 100 - (d.response / maxResponse) * 85;
                    return `${i === 0 ? 'M' : 'L'} ${xPercent}% ${yPercent}%`;
                  }).join(' ')}
                  fill="none"
                  stroke="#3b82f6"
                  strokeWidth="3.5"
                  strokeLinecap="round"
                />
              </svg>

              {/* Data points mapping */}
              {activeData.map((d, i) => {
                const heightPercent = (d.response / maxResponse) * 85;
                const isHovered = hoveredIndex === i;
                return (
                  <div 
                    key={i}
                    onMouseEnter={() => setHoveredIndex(i)}
                    onMouseLeave={() => setHoveredIndex(null)}
                    style={{ height: `${heightPercent}%` }}
                    className="flex-1 flex flex-col justify-end items-center relative group cursor-pointer"
                  >
                    {/* Tooltip on hover */}
                    {isHovered && (
                      <div className="absolute top-0 bg-slate-900 border border-white/10 rounded-lg p-2 text-[9px] text-white z-10 font-bold whitespace-nowrap shadow-xl">
                        {d.response} seconds
                      </div>
                    )}
                    <span className="text-[9px] font-mono text-slate-500 absolute -bottom-6">{d.label}</span>
                  </div>
                );
              })}
            </div>

            <div className="pt-4 flex justify-between text-[10px] text-slate-500 font-bold uppercase">
              <span>HIGHEST: {maxResponse}s</span>
              <span>LOWEST: {Math.min(...activeData.map(d => d.response))}s</span>
            </div>
          </div>

          {/* Chart 2: Sector Traffic Densities (Bar chart) */}
          <div className={`p-6 rounded-[24px] border ${isDark ? 'glass-card' : 'glass-card-light'} space-y-4`}>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <h3 className="font-extrabold text-sm uppercase">Tourist Geofence traffic density</h3>
                <p className="text-[10px] text-slate-500">Number of daily active safe ledger keys processing spatial verification requests</p>
              </div>
              <Activity className="h-4 w-4 text-pink-400" />
            </div>

            {/* SVG bar chart */}
            <div className="h-[250px] bg-slate-950/40 border border-white/5 rounded-xl flex items-end justify-between p-4 pt-8">
              {activeData.map((d, i) => {
                const heightPercent = (d.traffic / maxTraffic) * 85;
                const isHovered = hoveredIndex === i + 10;
                return (
                  <div 
                    key={i}
                    onMouseEnter={() => setHoveredIndex(i + 10)}
                    onMouseLeave={() => setHoveredIndex(null)}
                    style={{ height: `${heightPercent}%` }}
                    className="flex-1 flex flex-col justify-end items-center relative group cursor-pointer px-2"
                  >
                    <div className="w-full bg-gradient-to-t from-pink-600 to-indigo-500 rounded-t-lg transition-all duration-300 group-hover:from-pink-500 group-hover:to-indigo-400 h-full"></div>
                    {/* Tooltip */}
                    {isHovered && (
                      <div className="absolute top-0 bg-slate-900 border border-white/10 rounded-lg p-2 text-[9px] text-white z-10 font-bold whitespace-nowrap shadow-xl">
                        {d.traffic.toLocaleString()} keys
                      </div>
                    )}
                    <span className="text-[9px] font-mono text-slate-500 absolute -bottom-6">{d.label}</span>
                  </div>
                );
              })}
            </div>

            <div className="pt-4 flex justify-between text-[10px] text-slate-500 font-bold uppercase">
              <span>PEAK KEY SCANS: {maxTraffic.toLocaleString()}</span>
              <span>SECURED CORRIDORS: 48</span>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
