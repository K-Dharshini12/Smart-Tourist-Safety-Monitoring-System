import React from 'react';
import { useApp } from '../context/AppContext';
import { ArrowLeft, FileText, ShieldAlert, Check } from 'lucide-react';

export default function PrivacyTerms() {
  const { setPage, theme } = useApp();
  const isDark = theme === 'dark';

  return (
    <div className={`min-h-screen py-16 px-6 ${isDark ? 'mesh-background text-white' : 'mesh-background-light text-slate-900'}`}>
      <div className="max-w-4xl mx-auto space-y-12">
        <button 
          onClick={() => setPage('landing')}
          className="inline-flex items-center space-x-2 text-sm font-semibold text-blue-500 hover:text-blue-400 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Return Home</span>
        </button>

        <div className="space-y-4">
          <FileText className="h-10 w-10 text-blue-500" />
          <h2 className="text-3xl md:text-5xl font-black tracking-tight">Legal & Privacy Frameworks</h2>
          <p className="text-slate-400 text-sm max-w-2xl leading-relaxed">
            Please read our guidelines carefully to understand how your cryptographic digital identity and GPS location telemetry is managed in emergencies.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 pt-4">
          {/* Privacy Policy */}
          <div className={`p-8 rounded-2xl border space-y-4 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
            <h3 className="font-extrabold text-xl text-blue-500">Privacy Policy</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              We operate under a zero-telemetry-retention protocol. Your normal walking route logs are processed in-memory to trigger safety warnings and are never permanently saved.
            </p>
            <ul className="space-y-3 text-xs text-slate-300">
              <li className="flex items-start space-x-2">
                <Check className="h-4 w-4 text-emerald-400 shrink-0" />
                <span>**Sovereign Storage**: Passport records are encrypted locally before being signed into the blockchain ledger.</span>
              </li>
              <li className="flex items-start space-x-2">
                <Check className="h-4 w-4 text-emerald-400 shrink-0" />
                <span>**SOS Disclosures**: Medical files and active GPS coordinates are unlocked only during physical SOS activation.</span>
              </li>
              <li className="flex items-start space-x-2">
                <Check className="h-4 w-4 text-emerald-400 shrink-0" />
                <span>**Data Portability**: You have full control to purge your digital profile registration at any moment.</span>
              </li>
            </ul>
          </div>

          {/* Terms & Conditions */}
          <div className={`p-8 rounded-2xl border space-y-4 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
            <h3 className="font-extrabold text-xl text-purple-400">Terms & Conditions</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              By deploying Sentinel Tourist safety Net, you consent to automatic geofencing coordination and emergency telemetry release.
            </p>
            <ul className="space-y-3 text-xs text-slate-300">
              <li className="flex items-start space-x-2">
                <Check className="h-4 w-4 text-purple-400 shrink-0" />
                <span>**Emergency Authority Sync**: Triggering an SOS acts as an explicit waiver to share details with medical & police teams.</span>
              </li>
              <li className="flex items-start space-x-2">
                <Check className="h-4 w-4 text-purple-400 shrink-0" />
                <span>**Immutable Event Logs**: Incident histories accepted by first-responders are logged onto-chain and cannot be edited.</span>
              </li>
              <li className="flex items-start space-x-2">
                <Check className="h-4 w-4 text-purple-400 shrink-0" />
                <span>**Sovereign Responsibility**: Users are responsible for holding private keys for their blockchain identity credentials.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
