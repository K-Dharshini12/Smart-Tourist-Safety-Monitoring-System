import crypto from 'crypto';
import { Request, Response, NextFunction } from 'express';
import { db, User } from './store';

const JWT_SECRET = process.env.JWT_SECRET || 'smart_tourist_safety_blockchain_sec_key_2026';

// Extend Express Request type to include user information
export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    role: 'tourist' | 'admin' | 'police' | 'hospital' | 'embassy';
    name: string;
  };
}

/**
 * Custom JWT signing using native Node.js crypto (HMAC SHA256)
 * Produces fully compliant, signature-verified standard JWT strings
 */
export function signToken(payload: object, expiresInHours = 24): string {
  const header = {
    alg: 'HS256',
    typ: 'JWT'
  };

  const exp = Math.floor(Date.now() / 1000) + (expiresInHours * 3600);
  const fullPayload = {
    ...payload,
    exp
  };

  const base64Header = Buffer.from(JSON.stringify(header))
    .toString('base64url');
  const base64Payload = Buffer.from(JSON.stringify(fullPayload))
    .toString('base64url');

  const signatureInput = `${base64Header}.${base64Payload}`;
  const signature = crypto
    .createHmac('sha256', JWT_SECRET)
    .update(signatureInput)
    .digest('base64url');

  return `${signatureInput}.${signature}`;
}

/**
 * Custom JWT decoding & verification
 */
export function verifyToken(token: string): any {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;

    const [header, payload, signature] = parts;
    
    // Validate signature
    const signatureInput = `${header}.${payload}`;
    const expectedSignature = crypto
      .createHmac('sha256', JWT_SECRET)
      .update(signatureInput)
      .digest('base64url');

    if (signature !== expectedSignature) {
      return null;
    }

    // Decode and verify expiration
    const decodedPayload = JSON.parse(
      Buffer.from(payload, 'base64url').toString('utf-8')
    );

    if (decodedPayload.exp && decodedPayload.exp < Math.floor(Date.now() / 1000)) {
      console.log('Token expired.');
      return null;
    }

    return decodedPayload;
  } catch (e) {
    return null;
  }
}

/**
 * Express Authentication Middleware
 */
export function authenticateToken(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Authentication token missing.' });
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(403).json({ error: 'Authentication token is invalid or expired.' });
  }

  req.user = {
    id: decoded.id,
    email: decoded.email,
    role: decoded.role,
    name: decoded.name
  };

  next();
}

/**
 * Express Role Authorization Middleware
 */
export function authorizeRoles(...allowedRoles: Array<'tourist' | 'admin' | 'police' | 'hospital' | 'embassy'>) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized.' });
    }

    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Permission denied. Insufficient privileges.' });
    }

    next();
  };
}
