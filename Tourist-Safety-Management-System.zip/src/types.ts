export type AppScreen = "landing" | "auth" | "id-generator" | "dashboard" | "admin";

export interface TouristProfile {
  touristId: string;
  name: string;
  nationality: string;
  passportNo: string;
  email: string;
  phone: string;
  avatarUrl: string;
  verified: boolean;
  qrCodeData: string;
  registrationDate: string;
}

export interface JourneyState {
  active: boolean;
  startTime: string | null;
  lat: number;
  lng: number;
  centerLat: number;
  centerLng: number;
  geoFenceRadiusKm: number; // in kilometers (e.g. 5km)
  terrain: string; // "Mountain Peak Trekking" | "Coastal Shore Excursion" | "Historic Urban Core" | "Desert Safari Expedition"
  outOfBounds: boolean;
}

export interface AISafetyAssessment {
  status: "SAFE" | "WARNING" | "DANGER";
  riskLevel: number;
  summary: string;
  dangerDetails: string;
  environmentalHazards: string[];
  recommendations: string[];
  alertTitle: string;
}

export interface RescueStage {
  id: string;
  title: string;
  desc: string;
  active: boolean;
}

export interface RescueOperation {
  active: boolean;
  dispatchId: string | null;
  dispatchTime: string | null;
  stages: RescueStage[];
  currentStageIndex: number;
  etaSeconds: number;
}

export interface SOSBeacon {
  active: boolean;
  touristId: string | null;
  touristName: string | null;
  lat: number | null;
  lng: number | null;
  timestamp: string | null;
  passportNo: string | null;
  phone: string | null;
}

export interface TripHistoryItem {
  id: string;
  terrain: string;
  date: string;
  duration: string;
  distanceCoveredKm: number;
  maxRiskLevel: number;
  status: "SAFE" | "WARNING" | "DANGER";
}
