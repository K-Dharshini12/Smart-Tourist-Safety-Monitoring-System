import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini SDK with User-Agent telemetry
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// API endpoint for AI Tourist Safety evaluation
app.post("/api/safety-check", async (req, res) => {
  try {
    const { lat, lng, terrain, userStatus, outOfBounds } = req.body;

    if (lat === undefined || lng === undefined) {
      return res.status(400).json({ error: "Latitude and longitude are required." });
    }

    const systemPrompt = `You are the AEGIS AI Safety Core, an advanced tourist hazard and risk analysis system.
Analyze the following tourist status telemetry:
- Latitude: ${lat}
- Longitude: ${lng}
- Current Terrain/Context: ${terrain || "Unknown Area"}
- User Current Status: ${userStatus || "Exploring normally"}
- Geo-fencing boundary state: ${outOfBounds ? "OUTSIDE safe perimeter (DANGER ZONE)" : "INSIDE safe perimeter (SAFE ZONE)"}

Provide a comprehensive, high-quality, and structurally consistent safety assessment. The response must strictly be a valid JSON object matching this schema:
{
  "status": "SAFE" | "WARNING" | "DANGER",
  "riskLevel": number (from 0 to 100),
  "summary": "Short 1-sentence executive summary of safety state",
  "dangerDetails": "If warning/danger, specify why in detail. Otherwise, provide a reassuring safety confirmation.",
  "environmentalHazards": ["hazard 1", "hazard 2", ...],
  "recommendations": ["recommendation 1", "recommendation 2", ...],
  "alertTitle": "Short, striking emergency headline if danger/warning, otherwise 'AEGIS Secured'"
}

Keep descriptions contextual to the terrain. For example, mountains have hypothermia, landslide, navigation loss risks. Cities have pickpocketing, civil unrest, high congestion risks. Sea shores have riptide, high wave risks. Desert has dehydration, heat exhaustion. If outOfBounds is true, escalate the status to WARNING or DANGER depending on the terrain.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: systemPrompt,
      config: {
        responseMimeType: "application/json",
        systemInstruction: "You are the safety core of the AEGIS Smart Tourist Safety Monitoring System. You evaluate parameters and environment conditions to return clean, reliable, and precise tourist safety evaluations in JSON format.",
      },
    });

    const resultText = response.text || "{}";
    const resultJson = JSON.parse(resultText);
    res.json(resultJson);
  } catch (error: any) {
    console.error("Gemini API Safety Assessment Error:", error);
    res.status(500).json({
      error: "Failed to perform AI safety analysis",
      details: error.message || error,
      fallback: {
        status: req.body.outOfBounds ? "DANGER" : "SAFE",
        riskLevel: req.body.outOfBounds ? 85 : 12,
        summary: req.body.outOfBounds ? "Geo-fencing perimeter violated." : "Tourist is currently in a verified Safe Zone.",
        dangerDetails: req.body.outOfBounds ? "The tourist has exited the designated safe operational range for their selected activity. Immediate contact suggested." : "No immediate environmental hazards detected.",
        environmentalHazards: req.body.outOfBounds ? ["Boundary Violation", "Uncharted Terrain"] : ["Varying weather"],
        recommendations: req.body.outOfBounds ? ["Return to the safe perimeter immediately", "Standby for contact"] : ["Maintain active hydration", "Keep tracking enabled"],
        alertTitle: req.body.outOfBounds ? "Safety Boundary Exceeded" : "AEGIS Secured"
      }
    });
  }
});

// Endpoint to simulate rescue dispatch logging
app.post("/api/rescue-dispatch", (req, res) => {
  const { touristId, touristName, lat, lng } = req.body;
  
  // Create simulated rescue sequence data
  const dispatchTime = new Date().toISOString();
  const rescueStages = [
    { id: "signal_acquired", title: "Emergency Broadcast Received", desc: "SOS distress beacon verified and profile data downloaded.", active: true },
    { id: "triangulation", title: "Location Triangulation Complete", desc: `Coordinates resolved: ${lat.toFixed(5)}°, ${lng.toFixed(5)}°`, active: true },
    { id: "drone_launch", title: "Responder Drone Launched", desc: "Autonomous Scout Drone (AEGIS-Scout-4) routed to coordinates.", active: true },
    { id: "team_deployed", title: "Rescue Team Dispatched", desc: "Local ground rescue units dispatched with heavy medical and survival kit.", active: true },
    { id: "eta_active", title: "En Route to Target", desc: "ETA: 4 minutes 20 seconds. Drone live telemetry active.", active: true }
  ];

  res.json({
    success: true,
    dispatchId: `RESCUE-${Math.floor(100000 + Math.random() * 900000)}`,
    touristId,
    touristName,
    dispatchTime,
    rescueStages,
    etaSeconds: 260
  });
});

// Vite middleware integration
async function setupServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting server in development mode with Vite middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Starting server in production mode...");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`AEGIS Safety Server running on http://localhost:${PORT}`);
  });
}

setupServer();
