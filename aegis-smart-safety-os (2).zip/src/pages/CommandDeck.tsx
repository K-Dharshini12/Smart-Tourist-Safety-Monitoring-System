import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Shield, Compass, MapPin, AlertOctagon, Heart, 
  Check, ArrowLeft, RefreshCw, Bell, Volume2, ShieldAlert,
  Building, Phone, HeartPulse, ShieldCheck, Mail
} from 'lucide-react';

export default function CommandDeck() {
  const { setPage, theme, tourist, triggerSos, resolveSos } = useApp();
  const isDark = theme === 'dark';

  const [safetyScore, setSafetyScore] = useState(96);
  const [activeRouteMode, setActiveRouteMode] = useState<'idle' | 'safe' | 'shortcut'>('idle');
  const [touristPosition, setTouristPosition] = useState({ x: 100, y: 150 });
  const [locationPermission, setLocationPermission] = useState<'prompt' | 'granted' | 'denied'>('prompt');
  const [showPermissionModal, setShowPermissionModal] = useState(false);
  const [calculatedGps, setCalculatedGps] = useState<{ lat: number; lng: number; radius: number } | null>(null);
  const [pendingTouch, setPendingTouch] = useState<{ x: number; y: number; width: number } | null>(null);
  
  const [geofenceStatus, setGeofenceStatus] = useState<'idle' | 'warning' | 'safe'>('idle');
  const [geofenceMsg, setGeofenceMsg] = useState('');

  const handleRequestLocationPermission = (allow: boolean) => {
    setShowPermissionModal(false);
    if (allow) {
      setLocationPermission('granted');
      addNotification('📡 Satellite link initialized. Querying high-precision telemetry...', 'info');
      
      if (pendingTouch) {
        const { x, y, width } = pendingTouch;
        setTouristPosition({ x, y });
        const latOffset = (y - 170) * -0.0001;
        const lngOffset = (x - width / 2) * 0.0001;
        const newLat = 48.8566 + latOffset;
        const newLng = 2.3522 + lngOffset;
        const calculatedRadius = Math.round(10 + (Math.abs(x % 15) + Math.abs(y % 15)) / 2);
        
        setCalculatedGps({
          lat: newLat,
          lng: newLng,
          radius: calculatedRadius
        });
        setGeofenceStatus('idle');
        setGeofenceMsg('');
        addNotification(`🔒 GPS coordinates locked: ${newLat.toFixed(5)}° N, ${newLng.toFixed(5)}° E (Radius: ${calculatedRadius}m)`, 'success');
        setPendingTouch(null);
      } else {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(
            (position) => {
              const lat = position.coords.latitude;
              const lng = position.coords.longitude;
              const accuracy = Math.round(position.coords.accuracy || 15);
              setCalculatedGps({ lat, lng, radius: accuracy });
              addNotification(`🔒 GPS coordinates locked: ${lat.toFixed(5)}° N, ${lng.toFixed(5)}° E (Radius: ${accuracy}m)`, 'success');
            },
            (error) => {
              setCalculatedGps({ lat: 48.8566, lng: 2.3522, radius: 15 });
              addNotification('🔒 Simulated GPS locked: 48.8566° N, 2.3522° E (Radius: 15m)', 'success');
            },
            { enableHighAccuracy: true, timeout: 5000 }
          );
        } else {
          setCalculatedGps({ lat: 48.8566, lng: 2.3522, radius: 15 });
          addNotification('🔒 Simulated GPS locked: 48.8566° N, 2.3522° E (Radius: 15m)', 'success');
        }
      }
    } else {
      setLocationPermission('denied');
      addNotification('❌ Location permission denied. Geofencing services inactive.', 'warning');
      setPendingTouch(null);
    }
  };

  const handleCompareGeofencing = () => {
    if (locationPermission !== 'granted') {
      setShowPermissionModal(true);
      return;
    }
    
    const dangerX = 250;
    const dangerY = 250;
    const distance = Math.sqrt(Math.pow(touristPosition.x - dangerX, 2) + Math.pow(touristPosition.y - dangerY, 2));
    const isInsideDanger = distance <= 80;
    
    if (isInsideDanger) {
      setGeofenceStatus('warning');
      setGeofenceMsg(`🚨 WARNING: GEOFENCE BREACH DETECTED! Your GPS coordinates place you inside the 'Rue Saint-Denis Danger Sector' (radius 80m). Secure your valuables and passport ID immediately!`);
      setIsVibrating(true);
      addNotification('⚠️ GEOFENCE BREACH: High-risk pickpocketing sector!', 'danger');
    } else {
      setGeofenceStatus('safe');
      setGeofenceMsg(`✅ SAFE AREA: Your coordinates are verified outside any unpatrolled hazard sectors. Aegis geo-protection coverage active.`);
      setIsVibrating(false);
      addNotification('🛡️ Geofence clear: Safe area verified', 'success');
    }
  };

  const handleMapTouch = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    if (locationPermission !== 'granted') {
      setPendingTouch({ x: clickX, y: clickY, width: rect.width });
      setShowPermissionModal(true);
      return;
    }
    
    setTouristPosition({ x: clickX, y: clickY });
    
    const latOffset = (clickY - 170) * -0.0001;
    const lngOffset = (clickX - rect.width / 2) * 0.0001;
    const newLat = 48.8566 + latOffset;
    const newLng = 2.3522 + lngOffset;
    const calculatedRadius = Math.round(10 + (Math.abs(clickX % 15) + Math.abs(clickY % 15)) / 2);
    
    setCalculatedGps({
      lat: newLat,
      lng: newLng,
      radius: calculatedRadius
    });
    
    setGeofenceStatus('idle');
    setGeofenceMsg('');
    
    addNotification(`🎯 Position updated: ${newLat.toFixed(5)}° N, ${newLng.toFixed(5)}° E (Radius: ${calculatedRadius}m)`, 'success');
  };
  
  const [sosActive, setSosActive] = useState(false);
  const [sosProgress, setSosProgress] = useState({ police: 0, hospital: 0, embassy: 0, contact: 0 });
  const [dispatcherUnits, setDispatcherUnits] = useState<Array<{ id: string; type: 'police' | 'hospital'; x: number; y: number; label: string }>>([]);
  const [sirenFlash, setSirenFlash] = useState(false);
  const [isVibrating, setIsVibrating] = useState(false); // Phone vibration simulation
  
  // Custom dispatcher sliding cards
  const [slideAlerts, setSlideAlerts] = useState<Array<{ id: string; msg: string; type: 'info' | 'warn' | 'success' }>>([]);

  // Floating notifications state
  const [notifications, setNotifications] = useState([
    { id: '1', text: '🟢 GPS Telemetry Feed Sync: Secure Corridor L-89', type: 'success', time: 'Just now' },
    { id: '2', text: '🔵 Paris Municipal Geofence Active (3 safe havens loaded)', type: 'info', time: '2 min ago' }
  ]);

  const pathAnimationRef = useRef<number | null>(null);

  // Strobe sirens alert
  useEffect(() => {
    let interval: any;
    if (sosActive) {
      interval = setInterval(() => {
        setSirenFlash(prev => !prev);
      }, 250);
    } else {
      setSirenFlash(false);
    }
    return () => clearInterval(interval);
  }, [sosActive]);

  // Push new notification helper
  const addNotification = (text: string, type: 'success' | 'warning' | 'danger' | 'info') => {
    const newAlert = {
      id: Date.now().toString(),
      text,
      type,
      time: 'Just now'
    };
    setNotifications(prev => [newAlert, ...prev.slice(0, 4)]);
  };

  // Push dispatch sliding alert
  const addSlidingAlert = (msg: string, type: 'info' | 'warn' | 'success') => {
    const id = Date.now().toString() + Math.random();
    setSlideAlerts(prev => [...prev, { id, msg, type }]);
    setTimeout(() => {
      setSlideAlerts(prev => prev.filter(a => a.id !== id));
    }, 4500);
  };

  // --- Safe Route & Geofence Walk Animation ---
  const runRouteSimulation = (mode: 'safe' | 'shortcut') => {
    if (pathAnimationRef.current) {
      cancelAnimationFrame(pathAnimationRef.current);
    }
    setSosActive(false);
    setSosProgress({ police: 0, hospital: 0, embassy: 0, contact: 0 });
    setDispatcherUnits([]);
    setIsVibrating(false);
    
    setActiveRouteMode(mode);
    addNotification(`🧭 Calibrating ${mode === 'safe' ? 'Certified Safe Blue-Corridor' : 'Unchecked Secondary Alley'}...`, 'info');

    // Coordinates path sequence on the map canvas
    const safePath = [
      { x: 100, y: 150 }, // Louvre Museum
      { x: 180, y: 140 }, // Safe Avenue (under Alpha Safe Circle)
      { x: 260, y: 145 }, // Champs Safe Sector
      { x: 330, y: 150 }  // Arc de Triomphe
    ];

    const shortcutPath = [
      { x: 100, y: 150 }, // Louvre start
      { x: 160, y: 210 }, // Detouring south
      { x: 230, y: 250 }, // Entering RED Alert Geofence Danger Zone
      { x: 270, y: 260 }  // Danger Epicenter (Saint-Denis)
    ];

    const targetPath = mode === 'safe' ? safePath : shortcutPath;
    let pathIndex = 0;
    let progress = 0;

    const animate = () => {
      progress += 0.015; // speed pacing factor
      if (progress >= 1) {
        progress = 0;
        pathIndex++;
      }

      if (pathIndex < targetPath.length - 1) {
        const start = targetPath[pathIndex];
        const end = targetPath[pathIndex + 1];
        const curX = start.x + (end.x - start.x) * progress;
        const curY = start.y + (end.y - start.y) * progress;
        setTouristPosition({ x: curX, y: curY });

        if (mode === 'safe') {
          // Score rises or stays near perfect
          setSafetyScore(Math.floor(95 + (curX / 150)));
        } else {
          // Score drops dramatically as it enters danger
          const curDistToDanger = Math.sqrt(Math.pow(curX - 250, 2) + Math.pow(curY - 250, 2));
          if (curDistToDanger < 70) {
            // Entered red geofence! Trigger alert popup, phone vibration, and SOS flash
            if (!isVibrating) {
              setIsVibrating(true);
              triggerGeofenceViolation();
            }
            setSafetyScore(Math.max(8, Math.floor(curDistToDanger * 0.4)));
          } else {
            setSafetyScore(Math.max(45, Math.floor(96 - (curX * 0.2))));
          }
        }

        pathAnimationRef.current = requestAnimationFrame(animate);
      } else {
        const finalPoint = targetPath[targetPath.length - 1];
        setTouristPosition(finalPoint);
        setActiveRouteMode('idle');
        
        if (mode === 'safe') {
          setSafetyScore(98);
          addNotification('🟢 Destination Secured: Safety rating EXCELLENT.', 'success');
          addSlidingAlert('✓ Safe journey complete. Geofence coverage active.', 'success');
        } else {
          setSafetyScore(8);
          addNotification('🔴 GEOFENCE BREACH: High-risk danger sector detected.', 'danger');
          setIsVibrating(true);
          triggerAlarmSequence();
        }
      }
    };

    pathAnimationRef.current = requestAnimationFrame(animate);
  };

  const triggerGeofenceViolation = () => {
    addNotification('🚨 GEOFENCE ALERT: High-risk zone entered! Mobile device vibrating.', 'warning');
    addSlidingAlert('⚠️ WARNING: Exited monitored blue perimeter. Entering pickpocket alley!', 'warn');
  };

  const triggerAlarmSequence = async () => {
    setSosActive(true);
    setSafetyScore(5);
    addNotification('🚨 SOVEREIGN BIOMETRIC SOS ALARM ROUTED!', 'danger');
    addSlidingAlert('⚡ Critical SOS Packet received by Local Dispatcher!', 'warn');

    // Trigger on server backend via Context
    try {
      await triggerSos("EMERGENCY SIMULATION: Geofence violation & immediate distress beacon pressed.");
    } catch (e) {
      console.warn("Standard store SOS triggers locked.");
    }

    // Spawn police interceptor and hospital units in opposite corners of map
    setDispatcherUnits([
      { id: 'police-unit', type: 'police', x: 40, y: 40, label: 'Police Interceptor' },
      { id: 'hospital-unit', type: 'hospital', x: 340, y: 70, label: 'SAMU Medic-1' }
    ]);

    // Animate the dispatcher units converging on the tourist position
    setTimeout(() => {
      setDispatcherUnits(prev => prev.map(unit => {
        if (unit.id === 'police-unit') {
          return { ...unit, x: touristPosition.x - 25, y: touristPosition.y - 10 };
        } else {
          return { ...unit, x: touristPosition.x + 20, y: touristPosition.y + 15 };
        }
      }));
      addNotification('🚓 Interceptor police unit locked onto live GPS telemetry.', 'info');
      addSlidingAlert('🚓 Police unit and paramedic dispatched. En-route on green corridors!', 'info');
    }, 1500);

    // Dynamic up-counting progress bars for response nodes
    let prog = 0;
    const interval = setInterval(() => {
      prog += 5;
      if (prog <= 100) {
        setSosProgress({
          police: Math.min(prog * 1.3, 100),
          hospital: Math.min(prog * 1.1, 100),
          embassy: Math.min(prog * 0.85, 100),
          contact: Math.min(prog * 1.45, 100)
        });

        if (prog === 40) {
          addSlidingAlert('🏥 Trauma unit pre-authorized: Biometrics synced via blockDID.', 'info');
        }
        if (prog === 80) {
          addSlidingAlert('🏛 Embassy crisis logs open. Emergency passport document ready.', 'success');
        }
      } else {
        clearInterval(interval);
        addNotification('🛡️ Sovereign Protection bubble established. Rescuers arrived.', 'success');
        addSlidingAlert('🛡️ Tactical cordon secured at coordinates. Perimeter stable.', 'success');
      }
    }, 180);
  };

  const handleManualSos = () => {
    // Drop directly in Saint-Denis high-risk sector
    setTouristPosition({ x: 250, y: 250 });
    triggerAlarmSequence();
  };

  const handleResetSimulator = async () => {
    if (pathAnimationRef.current) cancelAnimationFrame(pathAnimationRef.current);
    setSosActive(false);
    setActiveRouteMode('idle');
    setTouristPosition({ x: 100, y: 150 });
    setSafetyScore(96);
    setDispatcherUnits([]);
    setIsVibrating(false);
    setSosProgress({ police: 0, hospital: 0, embassy: 0, contact: 0 });
    
    try {
      await resolveSos('sos-1'); // Reset emergency on server
    } catch (e) {}

    addNotification('🔄 Simulation vectors reset. Threat meters restored.', 'info');
    addSlidingAlert('🔄 Command deck restored to default monitoring status.', 'success');
  };

  return (
    <div className="min-h-screen pb-20 pt-6 px-4 sm:px-6 relative">
      
      {/* Inline styles for vibrating phone animation and pulsing waves */}
      <style>{`
        @keyframes CSSshake {
          0% { transform: translate(1px, 1px) rotate(0deg); }
          10% { transform: translate(-1px, -2px) rotate(-1deg); }
          20% { transform: translate(-3px, 0px) rotate(1deg); }
          30% { transform: translate(0px, 2px) rotate(0deg); }
          40% { transform: translate(1px, -1px) rotate(1deg); }
          50% { transform: translate(-1px, 2px) rotate(-1deg); }
          65% { transform: translate(-3px, 1px) rotate(0deg); }
          75% { transform: translate(2px, 1px) rotate(-1deg); }
          85% { transform: translate(-1px, -1px) rotate(1deg); }
          100% { transform: translate(2px, -2px) rotate(0deg); }
        }
        .vibrate-active {
          animation: CSSshake 0.35s infinite;
          border-color: rgba(239, 68, 68, 0.7) !important;
          box-shadow: 0 0 25px rgba(239, 68, 68, 0.4) !important;
        }
      `}</style>

      {/* Sirens peripheral alert ring */}
      {sosActive && (
        <div className={`fixed inset-0 pointer-events-none z-40 transition-all duration-300 ${sirenFlash ? 'bg-red-500/8 border-[14px] border-red-600/50' : 'bg-blue-500/4 border-[14px] border-blue-600/30'}`}>
          <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-red-600 text-white font-mono text-[10px] font-black px-6 py-2 rounded-full border border-red-500 shadow-xl animate-bounce">
            EMERGENCY INTERCEPT PROTOCOLS LOCKED
          </div>
        </div>
      )}

      {/* Floating sliding notification alerts */}
      <div className="fixed top-20 right-6 z-50 pointer-events-none space-y-3.5 w-full max-w-[340px]">
        {slideAlerts.map(alert => (
          <div 
            key={alert.id}
            className={`p-4 rounded-2xl border text-xs font-semibold shadow-2xl transition-all duration-500 transform translate-x-0 slide-in pointer-events-auto flex items-start space-x-3 backdrop-blur-xl ${alert.type === 'success' ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-300' : alert.type === 'warn' ? 'bg-red-950/80 border-red-500/40 text-red-300 animate-pulse' : 'bg-slate-900/95 border-blue-500/30 text-blue-300'}`}
          >
            <ShieldAlert className="h-5 w-5 shrink-0" />
            <p>{alert.msg}</p>
          </div>
        ))}
      </div>

      <div className="max-w-7xl mx-auto space-y-10">
        
        {/* Title */}
        <div className="text-left space-y-2">
          <div className="bg-blue-600/10 text-blue-400 px-3.5 py-1.5 rounded-full text-xs font-mono tracking-wider font-extrabold w-fit border border-blue-500/20">
            GEOPROTECTION DISPATCH DECK
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight">
            Spatial Geofencing & <span className="text-gradient">SOS Dispatcher</span>
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm max-w-2xl leading-relaxed">
            Real-time GPS boundary simulation, hazard corridor tracking, and emergency intercept routing. Click 'Take Shortcut' to trigger geofence vibrations or activate SOS manually.
          </p>
        </div>

        {/* Bento simulator layout */}
        <div className="grid lg:grid-cols-12 gap-8 items-start">
          
          {/* Telemetry sidebar metrics */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Safety index gauge */}
            <div className={`p-6 rounded-[24px] border text-center space-y-4 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
              <span className="text-[10px] font-mono font-black uppercase tracking-wider text-slate-500 block">Current Safety Score</span>
              
              <div className="relative flex justify-center items-center py-2">
                <svg className="w-28 h-28 transform -rotate-90">
                  <circle cx="56" cy="56" r="44" className={`stroke-current ${isDark ? 'text-slate-800' : 'text-slate-200'}`} strokeWidth="8" fill="transparent" />
                  <circle cx="56" cy="56" r="44" className={`stroke-current transition-all duration-300 ${safetyScore > 75 ? 'text-emerald-500' : safetyScore > 35 ? 'text-amber-500' : 'text-red-500 animate-pulse'}`} strokeWidth="8" fill="transparent" strokeDasharray="276.46" strokeDashoffset={276.46 - (276.46 * safetyScore) / 100} />
                </svg>
                <div className="absolute text-center flex flex-col justify-center">
                  <span className={`text-2xl font-black ${safetyScore < 40 ? 'text-red-500 scale-110 animate-pulse' : 'text-white'}`}>{safetyScore}%</span>
                </div>
              </div>

              <div className="border-t border-white/5 pt-3 text-center">
                <p className="text-[10px] font-mono font-bold text-slate-400">
                  {safetyScore > 75 ? '✓ OPTIMAL CORRIDORS STABLE' : safetyScore > 35 ? '⚠️ CAUTION: UNVERIFIED CORRIDOR' : '🚨 INTERCEPT INTERACTION ENGAGED'}
                </p>
              </div>
            </div>

            {/* CSS Vibration Mockup (Smartphone Widget) */}
            <div className={`p-6 rounded-[24px] border space-y-4 transition-all duration-300 ${isDark ? 'glass-card' : 'glass-card-light'} ${isVibrating ? 'vibrate-active' : ''}`}>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-black uppercase text-slate-500">Holder Smartphone Sim</span>
                <span className={`h-2.5 w-2.5 rounded-full ${isVibrating ? 'bg-red-500 animate-ping' : 'bg-emerald-500'}`}></span>
              </div>

              <div className="bg-slate-950/80 p-4 rounded-2xl border border-white/5 text-center space-y-3">
                <div className="h-10 w-6 mx-auto border-2 border-slate-700 rounded-lg flex flex-col justify-between p-1">
                  <div className="w-full bg-slate-700 h-1.5 rounded-full"></div>
                  <div className={`w-3 h-3 rounded-full mx-auto ${isVibrating ? 'bg-red-500 animate-pulse' : 'bg-blue-500'}`}></div>
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white uppercase">{isVibrating ? '⚡ VIBRATION PULSE active ⚡' : 'Phone Static'}</h4>
                  <p className="text-[9px] text-slate-500 mt-0.5">{isVibrating ? 'Tactile geofence warning broadcast' : 'Awaiting warning geofence breach'}</p>
                </div>
                {isVibrating && (
                  <button 
                    onClick={() => setIsVibrating(false)}
                    className="px-3 py-1 bg-red-600/20 text-red-400 text-[8px] font-mono uppercase tracking-widest rounded-lg border border-red-500/30 cursor-pointer"
                  >
                    Mute Vibe
                  </button>
                )}
              </div>
            </div>

            {/* Tactical system live logs */}
            <div className={`p-6 rounded-[24px] border ${isDark ? 'glass-card' : 'glass-card-light'} space-y-4`}>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-black uppercase text-slate-500">Security Telemetry Logs</span>
                <Volume2 className="h-4 w-4 text-slate-400" />
              </div>

              <div className="space-y-2.5 max-h-[160px] overflow-y-auto pr-1">
                {notifications.map((n) => (
                  <div key={n.id} className={`p-3 rounded-xl border text-[10px] space-y-1 ${n.type === 'success' ? 'border-emerald-500/20 bg-emerald-500/5 text-emerald-300' : n.type === 'warning' ? 'border-amber-500/20 bg-amber-500/5 text-amber-300' : n.type === 'danger' ? 'border-red-500/20 bg-red-500/5 text-red-300' : 'border-blue-500/20 bg-blue-500/5 text-blue-300'}`}>
                    <p className="font-semibold text-left">{n.text}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Reset simulator coordinates */}
            <div className="bg-slate-950/40 p-4 rounded-2xl border border-white/5 flex items-center justify-between text-left">
              <div>
                <h4 className="text-xs font-black text-white">Console Simulator</h4>
                <p className="text-[9px] text-slate-500 uppercase mt-0.5">Clear alert vectors</p>
              </div>
              <button 
                onClick={handleResetSimulator}
                className="p-2 bg-blue-600/10 border border-blue-500/30 text-blue-400 rounded-lg hover:bg-blue-600/25 text-[10px] font-black uppercase cursor-pointer transition-colors flex items-center space-x-1"
              >
                <RefreshCw className="h-3 w-3" />
                <span>Reset Map</span>
              </button>
            </div>

          </div>

          {/* Map & SOS Core interactive grids */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* The SVG Canvas Map */}
            <div className={`p-6 rounded-[24px] border ${isDark ? 'glass-card' : 'glass-card-light'} space-y-4`}>
              
              <div className="flex justify-between items-center">
                <h3 className="font-extrabold text-sm uppercase tracking-wider text-slate-400">Paris Sector-1 Grid Control</h3>
                <div className="flex items-center space-x-2">
                  <span className="h-2 w-2 bg-blue-500 rounded-full animate-ping"></span>
                  <span className="text-[10px] font-mono text-slate-400 uppercase">POS-LINK LIVE</span>
                </div>
              </div>

              {/* The Map Stage */}
              <div onClick={handleMapTouch} className="relative h-[340px] rounded-2xl bg-slate-950 border border-white/10 overflow-hidden shadow-inner flex items-center justify-center cursor-crosshair">
                
                {/* Background Radar grid patterns */}
                <div className="absolute inset-0 opacity-[0.03] bg-[linear-gradient(rgba(255,255,255,0.15)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.15)_1px,transparent_1px)] bg-[size:16px_16px]"></div>

                <svg className="absolute inset-0 w-full h-full pointer-events-none">
                  {/* Road Paths */}
                  {/* Safe road path - glows Green */}
                  <path 
                    d="M 100,150 L 180,140 L 260,145 L 330,150" 
                    fill="none" 
                    stroke={activeRouteMode === 'safe' ? '#10B981' : 'rgba(16,185,129,0.15)'} 
                    strokeWidth={activeRouteMode === 'safe' ? '6' : '3'} 
                    className={activeRouteMode === 'safe' ? 'glow-emerald' : ''}
                    strokeLinecap="round" 
                    strokeDasharray="4,4" 
                  />
                  {/* Dangerous shortcut path - glows Red */}
                  <path 
                    d="M 100,150 L 160,210 L 230,250 L 270,260" 
                    fill="none" 
                    stroke={activeRouteMode === 'shortcut' ? '#EF4444' : 'rgba(239,68,68,0.15)'} 
                    strokeWidth={activeRouteMode === 'shortcut' ? '6' : '3'} 
                    className={activeRouteMode === 'shortcut' ? 'glow-red' : ''}
                    strokeLinecap="round" 
                    strokeDasharray="4,4" 
                  />
                </svg>

                {/* Safe Geofence circle (green) */}
                <div className="absolute top-[80px] left-[150px] -translate-x-1/2 -translate-y-1/2">
                  <div className="h-28 w-28 rounded-full border-2 border-emerald-500/20 bg-emerald-500/5 flex items-center justify-center relative">
                    <span className="text-[8px] font-black text-emerald-400 uppercase tracking-widest block text-center">SAFE SECTOR<br />ALPHA</span>
                  </div>
                </div>

                {/* Danger Geofence Circle (red) */}
                <div className="absolute bottom-[20px] right-[140px] translate-x-1/2 translate-y-1/2">
                  <div className="h-32 w-32 rounded-full border-2 border-red-500/20 bg-red-500/5 flex items-center justify-center relative animate-pulse">
                    <div className="absolute inset-0 rounded-full border border-red-500/10 animate-ping"></div>
                    <span className="text-[8px] font-black text-red-500 uppercase tracking-widest text-center">DANGER ZONE<br />UNPATROLLED</span>
                  </div>
                </div>

                {/* City Landmarks pins */}
                <div className="absolute top-[150px] left-[100px] -translate-x-1/2 -translate-y-1/2 text-center select-none group cursor-pointer">
                  <div className="bg-blue-600/20 p-2 rounded-xl border border-blue-500/30 text-blue-400 hover:scale-115 transition-all">
                    <MapPin className="h-3.5 w-3.5" />
                  </div>
                  <span className="text-[8px] font-bold block mt-0.5 text-slate-400">Louvre (Start)</span>
                </div>

                <div className="absolute top-[150px] left-[330px] -translate-x-1/2 -translate-y-1/2 text-center select-none group cursor-pointer">
                  <div className="bg-emerald-600/20 p-2 rounded-xl border border-emerald-500/30 text-emerald-400 hover:scale-115 transition-all">
                    <MapPin className="h-3.5 w-3.5" />
                  </div>
                  <span className="text-[8px] font-bold block mt-0.5 text-slate-400">Arc de Triomphe</span>
                </div>

                {/* Active Dispatched Units Converging on Coordinates */}
                {dispatcherUnits.map(unit => (
                  <div 
                    key={unit.id} 
                    style={{ left: `${unit.x}px`, top: `${unit.y}px` }} 
                    className="absolute -translate-x-1/2 -translate-y-1/2 z-20 transition-all duration-1000 flex flex-col items-center select-none"
                  >
                    <div className={`p-1.5 rounded-full border text-white shadow-2xl ${unit.type === 'police' ? 'bg-indigo-600 border-indigo-400 animate-pulse' : 'bg-red-600 border-pink-400'}`}>
                      {unit.type === 'police' ? <Shield className="h-3.5 w-3.5" /> : <Heart className="h-3.5 w-3.5" />}
                    </div>
                    <span className="text-[7px] font-bold bg-slate-900 px-1.5 py-0.5 rounded text-white border border-white/10 mt-1 whitespace-nowrap">
                      {unit.label}
                    </span>
                  </div>
                ))}

                {/* Live Tourist Node */}
                <div 
                  style={{ left: `${touristPosition.x}px`, top: `${touristPosition.y}px` }} 
                  className="absolute -translate-x-1/2 -translate-y-1/2 z-30 transition-all duration-300 flex flex-col items-center select-none"
                >
                  <div className="relative">
                    <div className="h-7.5 w-7.5 bg-blue-600 rounded-full border-2 border-white flex items-center justify-center text-xs shadow-2xl glow-blue">
                      👤
                    </div>
                    <div className="absolute inset-0 bg-blue-500 rounded-full animate-ping opacity-50 pointer-events-none"></div>
                  </div>
                  <span className="text-[7px] font-extrabold bg-slate-900 text-white border border-white/10 px-1 py-0.5 rounded tracking-wide mt-1 whitespace-nowrap">
                    TOURIST COORDINATE
                  </span>
                </div>

              </div>

              {/* Calculated GPS telemetry panel */}
              {calculatedGps ? (
                <div className="p-4 bg-slate-900/90 border border-blue-500/30 rounded-2xl font-mono text-xs text-blue-300 space-y-1 text-left">
                  <div className="flex justify-between items-center text-slate-400 text-[10px] uppercase font-bold tracking-widest">
                    <span className="flex items-center space-x-1.5">
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-ping"></span>
                      <span>📡 Aegis Sat-Link Locked</span>
                    </span>
                    <span className="text-slate-500">Galileo/GPS Precision Mode</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 pt-2 text-center">
                    <div className="border-r border-white/5">
                      <p className="text-[9px] text-slate-500 uppercase font-bold">Latitude</p>
                      <p className="text-xs sm:text-sm font-black text-white">{calculatedGps.lat.toFixed(5)}° N</p>
                    </div>
                    <div className="border-r border-white/5">
                      <p className="text-[9px] text-slate-500 uppercase font-bold">Longitude</p>
                      <p className="text-xs sm:text-sm font-black text-white">{calculatedGps.lng.toFixed(5)}° E</p>
                    </div>
                    <div>
                      <p className="text-[9px] text-slate-500 uppercase font-bold">Precision Radius</p>
                      <p className="text-xs sm:text-sm font-black text-emerald-400">± {calculatedGps.radius}m</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-4 border border-dashed border-white/10 rounded-2xl text-center text-xs text-slate-500">
                  📡 Satellite telemetry inactive. Touch or click anywhere inside the map grid above to request location access and calculate latitude, longitude, and radius.
                </div>
              )}

              {/* Navigation pathway interactive simulator triggers */}
              <div className="bg-slate-950/40 p-4 rounded-xl border border-white/5 space-y-3 text-left">
                <span className="text-[10px] font-mono font-black text-slate-500 uppercase block">Spatial Pathway Simulator</span>
                <div className="grid sm:grid-cols-2 gap-4">
                  <button 
                    onClick={() => runRouteSimulation('safe')}
                    disabled={activeRouteMode !== 'idle'}
                    className={`py-3 px-4 rounded-xl text-xs font-bold transition-all cursor-pointer border ${activeRouteMode === 'safe' ? 'bg-emerald-600 border-emerald-500 text-white shadow-lg' : 'border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/5'}`}
                  >
                    Walk Green Safe Corridor
                  </button>
                  <button 
                    id="demo-shortcut-walk-trigger"
                    onClick={() => runRouteSimulation('shortcut')}
                    disabled={activeRouteMode !== 'idle'}
                    className={`py-3 px-4 rounded-xl text-xs font-bold transition-all cursor-pointer border ${activeRouteMode === 'shortcut' ? 'bg-red-600 border-red-500 text-white' : 'border-red-500/20 text-red-400 hover:bg-red-500/5 animate-pulse'}`}
                  >
                    Take Shortcut Detour (Breach Danger)
                  </button>
                </div>
              </div>

              {/* Geofence Comparison Panel */}
              <div className="bg-slate-950/40 p-4 rounded-xl border border-white/5 space-y-4 text-left">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-mono font-black text-slate-500 uppercase block">Aegis Geofencing Control</span>
                  <span className="text-[9px] bg-red-500/15 text-red-400 px-2 py-0.5 rounded font-bold tracking-wider uppercase">Active risk zone DB compare</span>
                </div>
                
                <button 
                  onClick={handleCompareGeofencing}
                  className="w-full py-3.5 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer text-center block shadow-lg shadow-blue-600/10"
                >
                  🎯 Touch to run Geofencing Comparison Check
                </button>

                {geofenceStatus !== 'idle' && (
                  <div className={`p-4 rounded-xl border animate-in fade-in slide-in-from-bottom-2 duration-200 ${geofenceStatus === 'warning' ? 'bg-red-500/10 border-red-500/20 text-red-200' : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-200'}`}>
                    <div className="flex items-start space-x-3">
                      <div className={`p-1.5 rounded-lg mt-0.5 ${geofenceStatus === 'warning' ? 'bg-red-500/20 text-red-400 animate-pulse' : 'bg-emerald-500/20 text-emerald-400'}`}>
                        {geofenceStatus === 'warning' ? <AlertOctagon className="h-4 w-4" /> : <Check className="h-4 w-4" />}
                      </div>
                      <div className="flex-1 space-y-1">
                        <p className="font-bold text-xs uppercase tracking-wider">
                          {geofenceStatus === 'warning' ? 'Geofence Intrusion Warning' : 'Safe Area Confirmed'}
                        </p>
                        <p className="text-xs text-slate-300 leading-relaxed">{geofenceMsg}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

            </div>

            {/* ==========================================
                🚨 BIOMETRIC SOS EMERGENCY BUTTON & RESPONDER STATUSES
               ========================================== */}
            <div id="sos-panic-beacon" className={`p-8 rounded-[24px] border ${isDark ? 'glass-card bg-red-950/5 border-red-500/25' : 'glass-card-light bg-red-50/5 border-red-500/15'} text-center space-y-6 relative overflow-hidden`}>
              
              <div className="max-w-md mx-auto space-y-2">
                <h3 className="text-xl font-black text-red-500 flex items-center justify-center space-x-2">
                  <AlertOctagon className="h-5 w-5 animate-pulse text-red-500" />
                  <span>Sovereign SOS Biometric Station</span>
                </h3>
                <p className="text-slate-400 text-xs">
                  A physical override button that connects live telemetry coordinates instantly with emergency trauma medical teams and police.
                </p>
              </div>

              {/* Glowing SOS Panic button */}
              <div className="flex justify-center py-3">
                <button 
                  onClick={handleManualSos}
                  className={`h-36 w-36 rounded-full flex flex-col justify-center items-center relative transition-all duration-300 hover:scale-105 active:scale-95 cursor-pointer shadow-2xl ${sosActive ? 'bg-red-600 border-4 border-white glow-red animate-pulse' : 'bg-gradient-to-tr from-red-600 via-red-500 to-pink-500 text-white'}`}
                >
                  <div className="absolute inset-0 rounded-full bg-red-500/20 animate-ping"></div>
                  <span className="text-[10px] font-mono tracking-widest text-white/70 uppercase">Press</span>
                  <span className="text-3xl font-black text-white">SOS</span>
                  <span className="text-[8px] font-mono tracking-wider text-white/80 uppercase mt-1">Sovereign Link</span>
                </button>
              </div>

              {/* Dynamic Emergency Intercept Dispatch Cards */}
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 text-left">
                
                {/* Responder A: Police */}
                <div className={`p-4 rounded-2xl border transition-all duration-500 ${sosActive ? 'border-indigo-500 bg-indigo-950/20' : 'border-white/5 bg-slate-900/10'}`}>
                  <div className="flex justify-between items-start">
                    <div className="bg-indigo-500/10 p-2 rounded-xl text-indigo-400">
                      <Building className="h-4 w-4" />
                    </div>
                    <span className={`text-[8px] font-black px-2 py-0.5 rounded-full ${sosActive ? 'bg-blue-500/20 text-blue-300 animate-pulse' : 'bg-slate-800 text-slate-500'}`}>
                      {sosActive ? 'DISPATCHED' : 'STANDBY'}
                    </span>
                  </div>
                  <div className="mt-4 space-y-1">
                    <h5 className="font-extrabold text-xs text-white">🚓 Police Cruiser</h5>
                    <p className="text-[9px] text-slate-500">Interceptor Unit Paris Central</p>
                    {sosActive && (
                      <div className="space-y-1 pt-1.5">
                        <div className="w-full bg-slate-800 rounded-full h-1">
                          <div style={{ width: `${sosProgress.police}%` }} className="bg-indigo-500 h-full transition-all"></div>
                        </div>
                        <span className="text-[8px] font-mono text-indigo-400">Arrived in {Math.max(0, Math.floor((100 - sosProgress.police) * 0.03))}s</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Responder B: Hospital */}
                <div className={`p-4 rounded-2xl border transition-all duration-500 ${sosActive ? 'border-red-500 bg-red-950/20' : 'border-white/5 bg-slate-900/10'}`}>
                  <div className="flex justify-between items-start">
                    <div className="bg-red-500/10 p-2 rounded-xl text-red-400">
                      <HeartPulse className="h-4 w-4" />
                    </div>
                    <span className={`text-[8px] font-black px-2 py-0.5 rounded-full ${sosActive ? 'bg-rose-500/20 text-rose-300 animate-pulse' : 'bg-slate-800 text-slate-500'}`}>
                      {sosActive ? 'INROUTE' : 'STANDBY'}
                    </span>
                  </div>
                  <div className="mt-4 space-y-1">
                    <h5 className="font-extrabold text-xs text-white">🏥 SAMU Medic</h5>
                    <p className="text-[9px] text-slate-500">Hôtel-Dieu Emergency Team</p>
                    {sosActive && (
                      <div className="space-y-1 pt-1.5">
                        <div className="w-full bg-slate-800 rounded-full h-1">
                          <div style={{ width: `${sosProgress.hospital}%` }} className="bg-red-500 h-full transition-all"></div>
                        </div>
                        <span className="text-[8px] font-mono text-red-400">Biometrics Intaked</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Responder C: Embassy */}
                <div className={`p-4 rounded-2xl border transition-all duration-500 ${sosActive ? 'border-purple-500 bg-purple-950/20' : 'border-white/5 bg-slate-900/10'}`}>
                  <div className="flex justify-between items-start">
                    <div className="bg-purple-500/10 p-2 rounded-xl text-purple-400">
                      <ShieldCheck className="h-4 w-4" />
                    </div>
                    <span className={`text-[8px] font-black px-2 py-0.5 rounded-full ${sosActive ? 'bg-purple-500/20 text-purple-300 animate-pulse' : 'bg-slate-800 text-slate-500'}`}>
                      {sosActive ? 'ALERTED' : 'STANDBY'}
                    </span>
                  </div>
                  <div className="mt-4 space-y-1">
                    <h5 className="font-extrabold text-xs text-white">🏛 National Embassy</h5>
                    <p className="text-[9px] text-slate-500">Consular Emergency Registry</p>
                    {sosActive && (
                      <div className="space-y-1 pt-1.5">
                        <div className="w-full bg-slate-800 rounded-full h-1">
                          <div style={{ width: `${sosProgress.embassy}%` }} className="bg-purple-500 h-full transition-all"></div>
                        </div>
                        <span className="text-[8px] font-mono text-purple-400">Crisis File #920-E</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Responder D: Emergency Contacts */}
                <div className={`p-4 rounded-2xl border transition-all duration-500 ${sosActive ? 'border-emerald-500 bg-emerald-950/20' : 'border-white/5 bg-slate-900/10'}`}>
                  <div className="flex justify-between items-start">
                    <div className="bg-emerald-500/10 p-2 rounded-xl text-emerald-400">
                      <Phone className="h-4 w-4" />
                    </div>
                    <span className={`text-[8px] font-black px-2 py-0.5 rounded-full ${sosActive ? 'bg-emerald-500/20 text-emerald-300 animate-pulse' : 'bg-slate-800 text-slate-500'}`}>
                      {sosActive ? 'CONNECTED' : 'STANDBY'}
                    </span>
                  </div>
                  <div className="mt-4 space-y-1">
                    <h5 className="font-extrabold text-xs text-white">👨‍👩‍👧 Family Hotlines</h5>
                    <p className="text-[9px] text-slate-500">Sovereign SMS Alert Ring</p>
                    {sosActive && (
                      <div className="space-y-1 pt-1.5">
                        <div className="w-full bg-slate-800 rounded-full h-1">
                          <div style={{ width: `${sosProgress.contact}%` }} className="bg-emerald-500 h-full transition-all"></div>
                        </div>
                        <span className="text-[8px] font-mono text-emerald-400">GPS Ping Broadcast</span>
                      </div>
                    )}
                  </div>
                </div>

              </div>

            </div>

          </div>

        </div>

      </div>

      {showPermissionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md">
          <div className="relative p-8 rounded-3xl border border-white/10 bg-slate-900 text-white space-y-6 max-w-md mx-4 shadow-2xl animate-in fade-in zoom-in duration-200 text-left">
            <div className="flex justify-between items-start">
              <div className="bg-blue-600/15 p-3 rounded-2xl text-blue-400">
                <Compass className="h-6 w-6 animate-spin" style={{ animationDuration: '3s' }} />
              </div>
              <span className="text-[10px] font-mono bg-blue-500/10 text-blue-400 px-2.5 py-0.5 rounded font-bold">PERMISSIONS SERVICE</span>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-lg font-black tracking-tight text-white uppercase">SATELLITE POSITIONING AUTHORIZATION</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Aegis Smart Safety OS requires access to your device's high-precision Galileo + GPS satellite telemetry feed to map real-time safety corridors and trigger geofence warning alarms.
              </p>
            </div>

            <div className="bg-slate-950/60 p-4 rounded-xl border border-white/5 text-[11px] text-slate-300">
              <span className="font-bold text-blue-400 block mb-1">Your privacy remains sovereign</span>
              Telemetry points are processed locally in memory and securely hashed under active on-chain session IDs.
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => handleRequestLocationPermission(false)}
                className="py-3 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-300 font-bold text-xs uppercase rounded-xl tracking-wider transition-all cursor-pointer text-center block"
              >
                Deny
              </button>
              <button
                onClick={() => handleRequestLocationPermission(true)}
                className="py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase rounded-xl tracking-wider transition-all cursor-pointer text-center block shadow-lg shadow-blue-600/20"
              >
                Allow Satellite Link
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
