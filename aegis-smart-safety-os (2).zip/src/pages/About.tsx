import React from 'react';
import { useApp } from '../context/AppContext';
import { ArrowLeft, Shield, Users, Target, Landmark, Award, Globe, Heart } from 'lucide-react';

export default function About() {
  const { setPage, theme } = useApp();
  const isDark = theme === 'dark';

  return (
    <div className={`min-h-screen py-16 px-6 transition-colors duration-300 ${isDark ? 'mesh-background text-white' : 'mesh-background-light text-slate-900'}`}>
      <div className="max-w-6xl mx-auto space-y-16">
        
        {/* Navigation back and header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-8">
          <button 
            onClick={() => setPage('landing')}
            className="inline-flex items-center space-x-2 text-sm font-semibold text-blue-500 hover:text-blue-400 cursor-pointer w-fit"
            id="back-to-home-btn"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Return Home</span>
          </button>
          
          <div className="flex items-center space-x-3">
            <span className="text-xs font-mono opacity-50">SYSTEM VERSION: 2.6.4</span>
            <span className="h-2 w-2 bg-emerald-500 rounded-full animate-pulse"></span>
            <span className="text-xs uppercase tracking-widest font-bold text-emerald-400">LEDGER ONLINE</span>
          </div>
        </div>

        {/* Hero Section */}
        <div className="grid lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-blue-600/10 text-blue-400 px-3 py-1 rounded-full text-xs font-bold w-fit border border-blue-500/20">
              SECURE GLOBAL FOUNDATION
            </div>
            <h1 className="text-4xl md:text-6xl font-black tracking-tight leading-tight">
              Sovereign Protection <br />
              <span className="text-gradient">For The Global Citizen</span>
            </h1>
            <p className={`text-base md:text-lg leading-relaxed ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
              Sentinel Tourist was founded in 2026 to address critical deficiencies in international traveler support. Traditional emergency services are isolated by municipal boundaries and dependent on physical paperwork. By placing blockchain credentials, smart geofences, and instant AI danger scoring in the hands of global tourists, we ensure immediate response from verified authorities wherever your journey takes you.
            </p>
          </div>

          <div className="lg:col-span-5 relative">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 to-purple-600 rounded-3xl blur-2xl opacity-20"></div>
            <div className={`relative p-8 rounded-3xl border text-center ${isDark ? 'glass-card' : 'glass-card-light'}`}>
              <div className="bg-blue-500/10 p-4 rounded-2xl text-blue-400 w-fit mx-auto mb-6">
                <Shield className="h-8 w-8" />
              </div>
              <p className="text-3xl font-black text-blue-500">2026</p>
              <p className="text-xs uppercase tracking-wider font-extrabold text-slate-400 mt-1">Foundation Year</p>
              
              <div className="grid grid-cols-2 gap-4 mt-6 pt-6 border-t border-white/5 text-left">
                <div>
                  <p className="text-xl font-bold text-purple-400">140k+</p>
                  <p className="text-[10px] uppercase text-slate-500 font-semibold">Registered IDs</p>
                </div>
                <div>
                  <p className="text-xl font-bold text-pink-400">100%</p>
                  <p className="text-[10px] uppercase text-slate-500 font-semibold">Crisis Audits Passed</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Core Values Section */}
        <div className="space-y-10 pt-8 border-t border-white/5">
          <div className="max-w-2xl space-y-4">
            <h2 className="text-3xl font-black tracking-tight">Our Core Directives</h2>
            <p className="text-sm text-slate-400 leading-relaxed">
              We operate under strict sovereign protocols that prioritize privacy, real-time tactical responder hotwires, and absolute accountability.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className={`p-8 rounded-2xl border ${isDark ? 'glass-card' : 'glass-card-light'}`}>
              <div className="bg-blue-600/15 p-3 rounded-xl text-blue-400 w-fit mb-5">
                <Target className="h-6 w-6" />
              </div>
              <h3 className="font-bold text-lg mb-2">Absolute Privacy First</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                We believe your location is yours alone. Live coordinates are evaluated in transient RAM. They are never written to disk or shared unless you explicitly command an emergency SOS broadcast.
              </p>
            </div>

            <div className={`p-8 rounded-2xl border ${isDark ? 'glass-card' : 'glass-card-light'}`}>
              <div className="bg-purple-600/15 p-3 rounded-xl text-purple-400 w-fit mb-5">
                <Landmark className="h-6 w-6" />
              </div>
              <h3 className="font-bold text-lg mb-2">Diplomatic Hotwires</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Sentinel builds direct API integrations into national embassies. If your passport is lost or compromised, your digital ledger ID verifies citizenship in milliseconds, not weeks.
              </p>
            </div>

            <div className={`p-8 rounded-2xl border ${isDark ? 'glass-card' : 'glass-card-light'}`}>
              <div className="bg-pink-600/15 p-3 rounded-xl text-pink-400 w-fit mb-5">
                <Heart className="h-6 w-6" />
              </div>
              <h3 className="font-bold text-lg mb-2">Heuristic Emergency Net</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                By automatically combining medical telemetry with location tracking, we ensure local response hospitals possess your life-saving medical background the exact second you arrive.
              </p>
            </div>
          </div>
        </div>

        {/* Global Infrastructure Section */}
        <div className={`p-12 rounded-3xl border ${isDark ? 'glass-card' : 'glass-card-light'} flex flex-col lg:flex-row gap-8 items-center`}>
          <div className="bg-blue-600/10 p-5 rounded-3xl text-blue-500 shrink-0">
            <Globe className="h-12 w-12 animate-pulse" />
          </div>
          <div className="space-y-3">
            <h3 className="text-xl font-bold text-slate-200">The Decentralized Sovereign Ledger</h3>
            <p className="text-xs text-slate-400 leading-relaxed max-w-3xl">
              Every identity registered on Sentinel is assigned an active cryptographic pocket on our distributed ledger. Verified medical officers, embassy personnel, and law enforcement can utilize our secure network verification tools to establish tourist integrity instantly during emergencies.
            </p>
            <div className="pt-2">
              <button 
                onClick={() => setPage('ledger-explorer')}
                className="text-xs text-blue-500 hover:text-blue-400 font-bold flex items-center space-x-1.5 cursor-pointer"
                id="view-blockchain-ledger-btn"
              >
                <span>Browse the Blockchain Safety Ledger</span>
                <span>→</span>
              </button>
            </div>
          </div>
        </div>

        {/* Action Call */}
        <div className="text-center pt-8 border-t border-white/5 space-y-6">
          <h3 className="text-2xl font-extrabold">Join the Sovereign Safety Network Today</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
            Get your sovereign digital passport verified, establish your secure medical profile, and unlock automated emergency coverage in seconds.
          </p>
          <div className="flex justify-center gap-4">
            <button 
              onClick={() => setPage('register')}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition-all glow-blue cursor-pointer"
              id="about-cta-register"
            >
              Issue My ID
            </button>
            <button 
              onClick={() => setPage('features')}
              className={`px-6 py-3 font-bold rounded-xl border transition-all cursor-pointer ${isDark ? 'border-white/10 hover:bg-white/5' : 'border-slate-900/10 hover:bg-slate-900/5'}`}
              id="about-cta-features"
            >
              See Capabilities
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
