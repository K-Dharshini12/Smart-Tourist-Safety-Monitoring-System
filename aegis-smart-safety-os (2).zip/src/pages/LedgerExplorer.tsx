import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { 
  ArrowLeft, Search, Cpu, QrCode, Shield, Check, Clock, Globe, Database, 
  ExternalLink, Layers, Terminal, Server, ArrowRight, AlertTriangle
} from 'lucide-react';

export default function LedgerExplorer() {
  const { setPage, ledger, verifyQR, token, theme } = useApp();
  const isDark = theme === 'dark';

  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [verificationResult, setVerificationResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  // Auto-generate some simulated ledger blocks if ledger is empty or for extra visual flair
  const [simulatedBlocks, setSimulatedBlocks] = useState<any[]>([]);

  useEffect(() => {
    // Generate realistic real-time transaction blocks
    const baseBlocks = [
      {
        txHash: '0x9d4a8e63b2f15c7a0d9e8f7c6b5a4d3c2b1a0f9e8d7c6b5a4f3e2d1c0b9a8f7e',
        blockNumber: 15438291,
        timestamp: new Date(Date.now() - 30000).toISOString(),
        type: 'IDENTITY_VERIFICATION',
        details: 'IDENTITY VERIFIED: Verified Tourist Sophia Martinez via QR Signature. Passport: US-48291X',
        walletAddress: '0x3f5c9e2d1b0a8f7e6d5c4b3a2f1e0d9c8b7a6f5e'
      },
      {
        txHash: '0xa4f2e1d0c9b8a7f6e5d4c3b2a1f0e9d8c7b6a5f4e3d2c1b0a9f8e7d6c5b4a3f2',
        blockNumber: 15438289,
        timestamp: new Date(Date.now() - 120000).toISOString(),
        type: 'SECURITY_ALERT',
        details: 'SECURITY RADAR RADIUS COMMIT: Active alert hazard generated near Seine River perimeter.',
        walletAddress: '0x1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b'
      },
      {
        txHash: '0x5b4c3b2a1f0e9d8c7b6a5f4e3d2c1b0a9f8e7d6c5b4a3f2e1d0c9b8a7f6e5d4c',
        blockNumber: 15438282,
        timestamp: new Date(Date.now() - 300000).toISOString(),
        type: 'ID_CREATION',
        details: 'ID REGISTERED & WALLET LINKED: Decentralized tourist ledger account established for user 0x72c... ',
        walletAddress: '0x72c1a0b9f8e7d6c5b4a3f2e1d0c9b8a7f6e5d4c3'
      },
      {
        txHash: '0xc7b6a5f4e3d2c1b0a9f8e7d6c5b4a3f2e1d0c9b8a7f6e5d4c3b2a1f0e9d8c7b6',
        blockNumber: 15438275,
        timestamp: new Date(Date.now() - 600000).toISOString(),
        type: 'SOS_LOG',
        details: 'SOS ALARM DISPATCH COMMIT: Verified GPS distress locked for tourist Alexis Carter. Police notified.',
        walletAddress: '0x9f8e7d6c5b4a3f2e1d0c9b8a7f6e5d4c3b2a1f0e'
      }
    ];

    setSimulatedBlocks(baseBlocks);

    // Dynamic block generation ticker to look alive
    const interval = setInterval(() => {
      const actions = ['IDENTITY_VERIFICATION', 'SECURITY_ALERT', 'SOS_LOG', 'ID_CREATION'];
      const action = actions[Math.floor(Math.random() * actions.length)];
      const names = ['Emma', 'Liam', 'Olivia', 'Noah', 'Mia', 'Lucas'];
      const name = names[Math.floor(Math.random() * names.length)];
      
      let details = '';
      if (action === 'IDENTITY_VERIFICATION') {
        details = `IDENTITY VERIFIED: Verified Tourist ${name} via QR Signature. Passport: EU-${Math.floor(Math.random()*90000)+10000}A`;
      } else if (action === 'SECURITY_ALERT') {
        details = `SECURITY RADAR RADIUS COMMIT: SafeZone geofence breached at Paris Central Sector ${Math.floor(Math.random()*9)+1}.`;
      } else if (action === 'SOS_LOG') {
        details = `SOS ALARM DISPATCH COMMIT: Coordinates locked for tourist ${name}. Emergency ambulance unit dispatched.`;
      } else {
        details = `ID REGISTERED & WALLET LINKED: Cryptographic sovereign wallet configured for active tourist.`;
      }

      const newBlock = {
        txHash: '0x' + Array.from({length: 64}, () => Math.floor(Math.random()*16).toString(16)).join(''),
        blockNumber: 15438291 + Math.floor(Math.random()*100),
        timestamp: new Date().toISOString(),
        type: action,
        details,
        walletAddress: '0x' + Array.from({length: 40}, () => Math.floor(Math.random()*16).toString(16)).join('')
      };

      setSimulatedBlocks(prev => [newBlock, ...prev.slice(0, 7)]);
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  const handleVerifySearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setLoading(true);
    setError(null);
    setVerificationResult(null);

    // If not logged in, simulate success with standard codes
    if (!token) {
      setTimeout(() => {
        if (searchQuery.toUpperCase().startsWith('SAFETY-ID-') || searchQuery.toUpperCase() === 'SAFETY-ID-TOURIST') {
          setVerificationResult({
            verified: true,
            timestamp: new Date().toISOString(),
            identity: {
              name: 'John Doe (Sovereign Guest)',
              nationality: 'United States',
              passportNumber: 'US-849201X',
              bloodType: 'O-Positive',
              walletAddress: '0x3f5c9e2d1b0a8f7e6d5c4b3a2f1e0d9c8b7a6f5e',
              status: 'active',
              medicalConditions: ['No Known Severe Allergies', 'Asthmatic (Carries inhaler)']
            }
          });
        } else {
          setError('Cryptographic ID signature verification failed. No tourist registered with this verification payload.');
        }
        setLoading(false);
      }, 1000);
      return;
    }

    try {
      const res = await verifyQR(searchQuery);
      setVerificationResult(res);
    } catch (e: any) {
      setError(e.message || 'Verification search rejected.');
    } finally {
      setLoading(false);
    }
  };

  const allBlocks = [...ledger, ...simulatedBlocks].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  return (
    <div className={`min-h-screen py-16 px-6 transition-colors duration-300 ${isDark ? 'mesh-background text-white' : 'mesh-background-light text-slate-900'}`}>
      <div className="max-w-7xl mx-auto space-y-12">
        
        {/* Navigation back and header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-8">
          <button 
            onClick={() => setPage('landing')}
            className="inline-flex items-center space-x-2 text-sm font-semibold text-blue-500 hover:text-blue-400 cursor-pointer w-fit"
            id="back-to-home-btn"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Return Home</span>
          </button>
          
          <div className="flex items-center space-x-3 text-xs font-mono">
            <span className="opacity-50">NODE STATUS:</span>
            <span className="h-2.5 w-2.5 bg-emerald-500 rounded-full animate-pulse"></span>
            <span className="font-extrabold text-emerald-400">SYNCED WITH BLOCK 15,438,321</span>
          </div>
        </div>

        {/* Heading */}
        <div className="grid lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-blue-600/10 text-blue-400 px-3 py-1 rounded-full text-xs font-bold w-fit border border-blue-500/20">
              LEDGER EXPLORER
            </div>
            <h1 className="text-4xl md:text-5xl font-black tracking-tight leading-none">
              Sovereign Safety <br />
              <span className="text-gradient">Ledger Explorer</span>
            </h1>
            <p className="text-slate-400 text-sm max-w-xl leading-relaxed">
              Browse transparent, tamper-proof audit trails of tourist validations, registration blocks, and SOS dispatches verified directly on our cryptographic safety net.
            </p>
          </div>

          <div className="lg:col-span-5 grid grid-cols-2 gap-4">
            <div className={`p-4 rounded-xl border ${isDark ? 'border-white/5 bg-slate-900/20' : 'border-slate-900/5 bg-white/50'}`}>
              <p className="text-[10px] uppercase font-mono text-slate-500">Total Validations</p>
              <p className="text-2xl font-black mt-1 text-blue-500">142,891</p>
            </div>
            <div className={`p-4 rounded-xl border ${isDark ? 'border-white/5 bg-slate-900/20' : 'border-slate-900/5 bg-white/50'}`}>
              <p className="text-[10px] uppercase font-mono text-slate-500">Active Validators</p>
              <p className="text-2xl font-black mt-1 text-purple-400">1,482</p>
            </div>
            <div className={`p-4 rounded-xl border ${isDark ? 'border-white/5 bg-slate-900/20' : 'border-slate-900/5 bg-white/50'}`}>
              <p className="text-[10px] uppercase font-mono text-slate-500">SOS Trigger Audits</p>
              <p className="text-2xl font-black mt-1 text-rose-500">100%</p>
            </div>
            <div className={`p-4 rounded-xl border ${isDark ? 'border-white/5 bg-slate-900/20' : 'border-slate-900/5 bg-white/50'}`}>
              <p className="text-[10px] uppercase font-mono text-slate-500">Avg block time</p>
              <p className="text-2xl font-black mt-1 text-emerald-400">2.1s</p>
            </div>
          </div>
        </div>

        {/* Cryptographic QR Code Search & Verification block */}
        <div className={`p-8 rounded-3xl border ${isDark ? 'glass-card' : 'glass-card-light'} space-y-6`}>
          <div className="space-y-2">
            <h2 className="text-xl md:text-2xl font-black">Search & Verify Cryptographic ID</h2>
            <p className="text-xs text-slate-400">
              Input a tourist card QR code signature (e.g., <code className="bg-white/5 px-2 py-0.5 rounded font-mono text-slate-200">SAFETY-ID-TOURIST</code>) to pull secure passport credentials directly from the blockchain state database.
            </p>
          </div>

          <form onSubmit={handleVerifySearch} className="flex gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-3.5 h-5 w-5 text-slate-500" />
              <input 
                type="text" 
                required
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3.5 bg-white/5 border border-white/10 rounded-2xl focus:border-blue-500 outline-none text-sm text-slate-200"
                placeholder="Enter validation QR payload..."
              />
            </div>
            <button 
              type="submit" 
              disabled={loading}
              className="px-6 py-3.5 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-800 text-white font-extrabold text-sm rounded-2xl transition-all flex items-center space-x-2 shrink-0 cursor-pointer glow-blue"
            >
              {loading ? <span>Querying Block...</span> : <><span>Verify QR Signature</span><QrCode className="h-4 w-4" /></>}
            </button>
          </form>

          {/* Search error display */}
          {error && (
            <div className="p-4 rounded-xl border border-red-500/20 bg-red-500/10 text-xs text-red-400 flex items-start space-x-3">
              <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Verification Result holographic card Certificate */}
          {verificationResult && (
            <div className="relative rounded-2xl border border-emerald-500/25 bg-emerald-500/5 p-6 md:p-8 overflow-hidden space-y-6">
              <div className="absolute top-0 right-0 p-8 opacity-5">
                <Check className="h-32 w-32" />
              </div>

              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-emerald-500/20 pb-5">
                <div className="flex items-center space-x-3">
                  <div className="bg-emerald-500/20 p-2 rounded-xl text-emerald-400 shrink-0">
                    <Shield className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-black text-slate-100 uppercase tracking-wide text-xs">SOVEREIGN VALIDATION PROTOCOL SUCCESS</h3>
                    <p className="text-[10px] text-emerald-400 font-mono">Status: Authenticated • Ledger Confirmed</p>
                  </div>
                </div>

                <div className="text-right text-[10px] font-mono text-slate-500">
                  <p>BLOCK CONFIRMATION: {Math.floor(Math.random() * 2000000) + 14000000}</p>
                  <p>TIMESTAMP: {new Date(verificationResult.timestamp).toLocaleTimeString()}</p>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-8 text-xs leading-relaxed">
                <div className="space-y-3">
                  <div>
                    <p className="text-[10px] uppercase font-mono text-slate-500">Tourist Name / Alias</p>
                    <p className="font-bold text-slate-200 mt-0.5">{verificationResult.identity.name}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase font-mono text-slate-500">Nationality</p>
                    <p className="font-bold text-slate-200 mt-0.5">{verificationResult.identity.nationality}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase font-mono text-slate-500">Passport Signature Hash</p>
                    <p className="font-mono text-slate-400 mt-0.5">{verificationResult.identity.passportNumber} (Encrypted Signature)</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <p className="text-[10px] uppercase font-mono text-slate-500">Sovereign Wallet Coordinates</p>
                    <p className="font-mono text-slate-400 mt-0.5">{verificationResult.identity.walletAddress}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase font-mono text-slate-500">Emergency Medical Data</p>
                    <p className="font-bold text-slate-200 mt-0.5">Blood Type: {verificationResult.identity.bloodType}</p>
                    {verificationResult.identity.medicalConditions && verificationResult.identity.medicalConditions.length > 0 && (
                      <p className="text-slate-400 text-[11px] mt-1">Conditions: {verificationResult.identity.medicalConditions.join(', ')}</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Live Block Ledger Stream */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Database className="h-6 w-6 text-blue-500 animate-pulse" />
              <h2 className="text-2xl font-black">Cryptographic Transaction Stream</h2>
            </div>
            <span className="text-[10px] font-mono bg-white/5 text-slate-400 px-3 py-1 rounded-full">REALTIME UPDATE TICK</span>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-white/5">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className={`border-b ${isDark ? 'border-white/5 bg-slate-900/40 text-slate-400' : 'border-slate-900/5 bg-slate-100 text-slate-600'} font-mono uppercase text-[10px] tracking-wider`}>
                  <th className="p-4">TX HASH</th>
                  <th className="p-4">BLOCK NO</th>
                  <th className="p-4">ACTION TYPE</th>
                  <th className="p-4">AUDIT PAYLOAD DETAILS</th>
                  <th className="p-4">TIMESTAMP (UTC)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-mono">
                {allBlocks.map((b, idx) => {
                  let typeColor = 'text-blue-400 bg-blue-500/10 border-blue-500/20';
                  if (b.type === 'SOS_LOG') typeColor = 'text-rose-400 bg-rose-500/10 border-rose-500/20';
                  if (b.type === 'SECURITY_ALERT') typeColor = 'text-amber-400 bg-amber-500/10 border-amber-500/20';
                  if (b.type === 'IDENTITY_VERIFICATION') typeColor = 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';

                  return (
                    <tr key={idx} className={isDark ? 'hover:bg-white/5 text-slate-300' : 'hover:bg-slate-900/5 text-slate-700'}>
                      <td className="p-4 font-mono text-blue-500 font-bold max-w-[120px] truncate" title={b.txHash}>
                        {b.txHash}
                      </td>
                      <td className="p-4 text-slate-400 font-bold">{b.blockNumber}</td>
                      <td className="p-4">
                        <span className={`px-2.5 py-1 rounded-full text-[9px] font-extrabold border uppercase tracking-wider ${typeColor}`}>
                          {b.type}
                        </span>
                      </td>
                      <td className="p-4 text-slate-200 text-xs font-sans font-medium leading-relaxed max-w-sm truncate" title={b.details}>
                        {b.details}
                      </td>
                      <td className="p-4 text-slate-500 text-[10px]">
                        {new Date(b.timestamp).toISOString().replace('T', ' ').substring(0, 19)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
}
