import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Shield, Heart, Activity, AlertTriangle, MapPin, Navigation, PhoneCall, LogOut } from 'lucide-react';

export default function HospitalDashboard() {
  const { 
    user, sosAlerts, acceptSos, resolveSos, logout, theme 
  } = useApp();

  const isDark = theme === 'dark';
  const [activeCaseId, setActiveCaseId] = useState<string | null>(null);

  const activeCases = sosAlerts.filter(s => s.status !== 'resolved');
  const activeCase = sosAlerts.find(s => s.id === activeCaseId);

  useEffect(() => {
    if (activeCases.length > 0 && !activeCaseId) {
      setActiveCaseId(activeCases[0].id);
    }
  }, [sosAlerts]);

  return (
    <div className={`min-h-screen flex flex-col md:flex-row transition-colors duration-300 ${isDark ? 'mesh-background text-white' : 'mesh-background-light text-slate-900'}`}>
      
      {/* Sidebar */}
      <aside className={`w-full md:w-64 border-b md:border-b-0 md:border-r flex flex-col justify-between ${isDark ? 'glass border-white/10' : 'glass-light border-slate-900/10'}`}>
        <div>
          <div className="p-6 border-b border-white/5 flex items-center space-x-3">
            <div className="bg-red-600 p-2 rounded-xl text-white">
              <Heart className="h-5 w-5" />
            </div>
            <div>
              <p className="font-extrabold text-sm tracking-tight text-gradient">AEGIS TOURIST</p>
              <span className="text-[9px] uppercase tracking-wider opacity-60">Hospital Desk</span>
            </div>
          </div>

          <div className="p-6 border-b border-white/5">
            <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Duty Nurse</p>
            <p className="text-sm font-extrabold mt-1 text-slate-200">{user?.name}</p>
            <span className="text-[10px] bg-red-500/10 text-red-400 px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider mt-2 inline-block">
              Trauma Triage
            </span>
          </div>

          <div className="p-4 space-y-2">
            <p className="text-[10px] text-slate-500 font-black uppercase tracking-wider px-2">Trauma Alarms ({activeCases.length})</p>
            <div className="space-y-1">
              {activeCases.map(c => (
                <button
                  key={c.id}
                  onClick={() => setActiveCaseId(c.id)}
                  className={`w-full text-left p-3 rounded-xl text-xs transition-all cursor-pointer ${activeCaseId === c.id ? 'bg-red-600 text-white font-extrabold glow-red' : 'text-slate-400 hover:bg-white/5'}`}
                >
                  <div className="flex justify-between items-center mb-1">
                    <span className="truncate max-w-[120px]">{c.touristName}</span>
                    <span className="text-[8px] uppercase bg-red-500/20 text-red-400 px-1.5 py-0.5 rounded font-black">
                      {c.medicalInfo.bloodType}
                    </span>
                  </div>
                  <p className="text-[10px] font-mono opacity-80">{c.nationality}</p>
                </button>
              ))}

              {activeCases.length === 0 && (
                <p className="text-[10px] text-slate-500 p-2 text-center">No current medical traumas active.</p>
              )}
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-white/5">
          <button 
            onClick={logout}
            className="w-full flex items-center justify-center space-x-2 py-3 bg-red-950/20 border border-red-500/20 rounded-xl hover:bg-red-950/30 text-red-400 text-xs font-bold transition-all cursor-pointer"
          >
            <LogOut className="h-4 w-4" />
            <span>End Session</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-y-auto p-8 space-y-8">
        
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-white/5 pb-6">
          <div>
            <h2 className="text-2xl font-black tracking-tight">Trauma & Emergency Center</h2>
            <p className="text-xs text-slate-400 mt-1">Direct cryptographic retrieval of patient blood groups and medical history during physical distress alarms.</p>
          </div>
        </header>

        {activeCase ? (
          <div className="grid md:grid-cols-2 gap-8 items-start">
            
            {/* Medical details card */}
            <div className={`p-8 rounded-3xl border space-y-6 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
              <div className="flex justify-between items-start border-b border-white/5 pb-4">
                <div className="space-y-1">
                  <span className="text-[10px] font-bold bg-red-500/10 text-red-400 px-2.5 py-1 rounded-full uppercase tracking-wider">
                    Trauma Record Retrieved
                  </span>
                  <h3 className="text-2xl font-black mt-2 text-slate-100">{activeCase.touristName}</h3>
                  <p className="text-xs text-slate-400">Passport Identity: {activeCase.nationality}</p>
                </div>
                
                <Activity className="h-6 w-6 text-red-500 animate-pulse glow-red" />
              </div>

              {/* Core Ledger Medical Record */}
              <div className="space-y-4">
                <h4 className="font-extrabold text-[11px] uppercase tracking-widest text-slate-400">Decrypted Health Dossier</h4>
                
                <div className="grid grid-cols-2 gap-4 text-xs font-semibold">
                  <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-xl">
                    <p className="text-[9px] uppercase text-slate-400 tracking-wider block mb-1">Blood Type</p>
                    <p className="text-2xl font-black text-red-400 font-mono">{activeCase.medicalInfo.bloodType}</p>
                  </div>

                  <div className="bg-white/5 border border-white/5 p-4 rounded-xl">
                    <p className="text-[9px] uppercase text-slate-400 tracking-wider block mb-1">Identified Allergies</p>
                    <p className="text-sm font-bold text-slate-200 truncate">{activeCase.medicalInfo.conditions?.join(', ') || 'No known conditions'}</p>
                  </div>
                </div>

                <div className="p-4 bg-slate-950/40 rounded-xl border border-white/5 text-xs text-slate-300">
                  <span className="text-[9px] text-slate-500 font-bold block uppercase mb-1">Incident Emergency Details</span>
                  "{activeCase.notes}"
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex space-x-4 pt-4 border-t border-white/5">
                {activeCase.status === 'pending' ? (
                  <button 
                    onClick={() => acceptSos(activeCase.id)}
                    className="w-full py-4 bg-red-600 hover:bg-red-500 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow-lg glow-red"
                  >
                    🚑 Deploy Trauma Ambulance
                  </button>
                ) : (
                  <button 
                    onClick={() => resolveSos(activeCase.id)}
                    className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow-lg glow-emerald"
                  >
                    ✅ Patient Stabilized & Resolved
                  </button>
                )}
              </div>
            </div>

            {/* Simulated Live ETA Navigation widget */}
            <div className={`p-8 rounded-3xl border space-y-6 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
              <div className="border-b border-white/5 pb-4">
                <h4 className="font-extrabold text-sm uppercase tracking-wider text-blue-400">Live Ambulance Route Telemetry</h4>
                <p className="text-[10px] text-slate-400 mt-1">Real-time GPS routing to coordinate dispatch center response times.</p>
              </div>

              <div className="space-y-4">
                <div className="p-4 bg-slate-950/40 rounded-xl border border-white/5 font-mono text-xs text-slate-300 space-y-2">
                  <p className="flex justify-between">
                    <span>PATIENT LATITUDE:</span>
                    <span className="text-blue-400 font-bold">{activeCase.lat.toFixed(5)}° N</span>
                  </p>
                  <p className="flex justify-between">
                    <span>PATIENT LONGITUDE:</span>
                    <span className="text-blue-400 font-bold">{activeCase.lng.toFixed(5)}° E</span>
                  </p>
                  <div className="border-t border-white/5 pt-2 flex justify-between font-sans font-bold">
                    <span>DISPATCH TEAM ETA:</span>
                    <span className="text-emerald-400 animate-pulse">4.5 MINS</span>
                  </div>
                </div>

                <div className="h-44 bg-slate-950 rounded-2xl relative border border-white/5 flex items-center justify-center overflow-hidden">
                  <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-40"></div>
                  
                  {/* Visualizing simple line route */}
                  <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
                    <line x1="20%" y1="80%" x2="80%" y2="20%" stroke="rgba(239, 68, 68, 0.4)" strokeWidth="2" strokeDasharray="5 5" />
                  </svg>
                  
                  <div className="absolute bottom-6 left-6 text-[10px] bg-slate-900 border border-white/10 px-2 py-1 rounded text-slate-300 font-bold">
                    🏥 Trauma Center (Start)
                  </div>

                  <div className="absolute top-6 right-6 text-[10px] bg-red-950 border border-red-500/20 px-2 py-1 rounded text-red-400 font-bold animate-pulse">
                    🚨 Tourist SOS (Patient)
                  </div>
                </div>
              </div>
            </div>

          </div>
        ) : (
          <div className="border border-dashed border-white/10 rounded-3xl p-16 text-center text-slate-500 text-sm flex flex-col justify-center items-center">
            <Heart className="h-10 w-10 text-slate-600 mb-3" />
            <p className="font-bold">Triage Queues Quiet</p>
            <p className="text-xs mt-1 max-w-sm">No active tourist trauma dispatches currently pending inside the hospital network.</p>
          </div>
        )}

      </main>
    </div>
  );
}
