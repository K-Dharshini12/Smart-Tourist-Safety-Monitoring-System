import React, { useState } from "react";
import { motion } from "motion/react";
import { Shield, User, Globe, FileText, Mail, Phone, Lock, ArrowLeft, CheckCircle2, ChevronRight, Camera, Plane } from "lucide-react";
import { AppScreen, TouristProfile } from "../types";

interface AuthPortalProps {
  onNavigate: (screen: AppScreen) => void;
  onRegisterSuccess: (profile: TouristProfile) => void;
}

export default function AuthPortal({ onNavigate, onRegisterSuccess }: AuthPortalProps) {
  const [isRegister, setIsRegister] = useState(true);
  const [name, setName] = useState("");
  const [nationality, setNationality] = useState("United States");
  const [passportNo, setPassportNo] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [selectedAvatar, setSelectedAvatar] = useState(0);

  const avatars = [
    "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80", // Female explorer
    "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80", // Male adventure
    "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80", // Female traveler
    "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80"  // Male explorer
  ];

  // Form submit handler
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (isRegister) {
      if (!name || !passportNo || !email || !phone) {
        alert("Please populate all secure fields.");
        return;
      }

      // Format registration
      const newProfile: TouristProfile = {
        touristId: `AEGIS-${Math.floor(10000 + Math.random() * 90000)}`,
        name,
        nationality,
        passportNo: passportNo.toUpperCase(),
        email,
        phone,
        avatarUrl: avatars[selectedAvatar],
        verified: true,
        qrCodeData: `AEGIS-ID:${passportNo}-${name.replace(/\s+/g, "")}-VERIFIED-2026`,
        registrationDate: new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" }),
      };

      onRegisterSuccess(newProfile);
    } else {
      // Simulate Login with defaults if none entered
      const mockProfile: TouristProfile = {
        touristId: "AEGIS-58291",
        name: name || "Elena Rostova",
        nationality: nationality || "Switzerland",
        passportNo: passportNo.toUpperCase() || "EP9403112",
        email: email || "elena.r@aegistravel.com",
        phone: phone || "+41 79 402 1102",
        avatarUrl: avatars[selectedAvatar],
        verified: true,
        qrCodeData: "AEGIS-ID:EP9403112-ElenaRostova-VERIFIED-2026",
        registrationDate: "July 12, 2026",
      };

      onRegisterSuccess(mockProfile);
    }
  };

  return (
    <div className="relative min-h-screen bg-white overflow-x-hidden text-gray-100 flex flex-col font-sans">
      {/* Background travel image with gradient overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-15 mix-blend-overlay pointer-events-none"
        style={{ backgroundImage: `url('/src/assets/images/travel_background_1784446490513.jpg')` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#020817]/95 via-[#03132e]/95 to-[#020817] pointer-events-none" />
      
      {/* Grid Pattern overlay */}
      <div className="absolute inset-0 grid-bg opacity-20 pointer-events-none" />

      {/* Screen-specific identity watermark: cyber-security shield/lock for Login, passport/globe/flight-route for Register */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none select-none">
        {isRegister ? (
          <>
            <FileText className="absolute -right-10 -top-10 h-72 w-72 text-cyan-600/[0.05] rotate-12" strokeWidth={0.7} />
            <Globe className="absolute -left-16 bottom-0 h-80 w-80 text-blue-800/[0.07]" strokeWidth={0.5} />
            <Plane className="absolute right-1/4 top-1/3 h-16 w-16 text-cyan-500/10 rotate-45" strokeWidth={0.8} />
          </>
        ) : (
          <>
            <Shield className="absolute -right-14 -bottom-14 h-96 w-96 text-cyan-600/[0.06]" strokeWidth={0.5} />
            <Lock className="absolute -left-10 top-10 h-56 w-56 text-blue-800/[0.08] -rotate-12" strokeWidth={0.6} />
          </>
        )}
      </div>

      {/* Top Bar Navigation */}
      <header className="relative z-10 max-w-7xl w-full mx-auto px-6 py-5 flex items-center justify-between">
        <button
          id="back_to_landing_btn"
          onClick={() => onNavigate("landing")}
          className="flex items-center space-x-2 text-xs font-mono text-cyan-500/80 hover:text-cyan-500 transition-colors cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>BACK TO HOME</span>
        </button>

        <div className="flex items-center space-x-2">
          <Shield className="h-5 w-5 text-cyan-500" />
          <span className="font-display font-black text-lg tracking-wider text-white">AEGIS</span>
        </div>
      </header>

      {/* Authentication Form Card */}
      <div className="flex-grow flex items-center justify-center px-6 py-10 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="w-full max-w-lg glass-card rounded-2xl border border-cyan-600/20 shadow-2xl overflow-hidden p-8 relative"
        >
          {/* Subtle radar glowing line animation at top of card */}
          <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-cyan-500 to-transparent shadow-[0_0_8px_rgba(6, 182, 212,0.5)]" />

          <div className="text-center mb-8">
            <h2 className="font-display text-3xl font-extrabold text-white">
              {isRegister ? "Secure Registry" : "Initialize Safety Core"}
            </h2>
            <p className="text-gray-400 text-xs mt-2">
              {isRegister 
                ? "Register biometric credentials to generate an encrypted tourist safety token" 
                : "Input your active travel credentials to sync your AEGIS Shield"}
            </p>
          </div>

          {/* Tab toggler login/register */}
          <div className="grid grid-cols-2 bg-cyan-950/40 rounded-lg p-1.5 mb-8 border border-cyan-600/10">
            <button
              id="toggle_register_tab_btn"
              type="button"
              onClick={() => setIsRegister(true)}
              className={`py-2 rounded-md font-display font-bold text-xs tracking-wider transition-all cursor-pointer ${
                isRegister 
                  ? "bg-cyan-600 text-black shadow-lg" 
                  : "text-gray-400 hover:text-white"
              }`}
            >
              REGISTER NEW TOURIST
            </button>
            <button
              id="toggle_login_tab_btn"
              type="button"
              onClick={() => setIsRegister(false)}
              className={`py-2 rounded-md font-display font-bold text-xs tracking-wider transition-all cursor-pointer ${
                !isRegister 
                  ? "bg-cyan-600 text-black shadow-lg" 
                  : "text-gray-400 hover:text-white"
              }`}
            >
              EXISTING SYSTEM LOG
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {isRegister && (
              /* Avatar Picker */
              <div>
                <label className="block text-[10px] font-mono text-cyan-500/80 mb-2 uppercase tracking-widest">
                  Secure Biometric Avatar
                </label>
                <div className="flex items-center space-x-4">
                  <div className="relative group">
                    <img
                      src={avatars[selectedAvatar]}
                      alt="Selected Profile"
                      referrerPolicy="no-referrer"
                      className="h-14 w-14 rounded-full object-cover border-2 border-cyan-500 shadow-[0_0_10px_rgba(6, 182, 212,0.2)]"
                    />
                    <div className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Camera className="h-4 w-4 text-white" />
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    {avatars.map((av, index) => (
                      <button
                        key={index}
                        id={`avatar_choice_btn_${index}`}
                        type="button"
                        onClick={() => setSelectedAvatar(index)}
                        className={`h-9 w-9 rounded-full overflow-hidden border-2 transition-all cursor-pointer ${
                          selectedAvatar === index 
                            ? "border-cyan-500 scale-105 shadow-[0_0_8px_rgba(6, 182, 212,0.3)]" 
                            : "border-gray-800 opacity-60 hover:opacity-100"
                        }`}
                      >
                        <img src={av} alt="Avatar Selection" referrerPolicy="no-referrer" className="h-full w-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Tourist Name */}
            <div>
              <label className="block text-[10px] font-mono text-cyan-500/80 mb-1.5 uppercase tracking-widest">
                Full Traveler Name
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                  <User className="h-4 w-4 text-cyan-500/60" />
                </div>
                <input
                  id="auth_name_input"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Elena Rostova"
                  className="w-full pl-10 pr-4 py-3 bg-[#0a182f]/50 border border-cyan-600/20 rounded-xl font-sans text-sm text-white placeholder-gray-600 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none transition-all"
                />
              </div>
            </div>

            {/* Nationality Selection */}
            <div>
              <label className="block text-[10px] font-mono text-cyan-500/80 mb-1.5 uppercase tracking-widest">
                Passport Nationality
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                  <Globe className="h-4 w-4 text-cyan-500/60" />
                </div>
                <select
                  id="auth_nationality_select"
                  value={nationality}
                  onChange={(e) => setNationality(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-[#0a182f]/80 border border-cyan-600/20 rounded-xl font-sans text-sm text-white focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none transition-all cursor-pointer"
                >
                  <option value="United States">United States (USA)</option>
                  <option value="Switzerland">Switzerland (CHE)</option>
                  <option value="Japan">Japan (JPN)</option>
                  <option value="Australia">Australia (AUS)</option>
                  <option value="Germany">Germany (DEU)</option>
                  <option value="United Kingdom">United Kingdom (GBR)</option>
                  <option value="Singapore">Singapore (SGP)</option>
                  <option value="India">India (IND)</option>
                </select>
              </div>
            </div>

            {/* Passport Number */}
            <div>
              <label className="block text-[10px] font-mono text-cyan-500/80 mb-1.5 uppercase tracking-widest flex justify-between">
                <span>Passport / Travel Document Number</span>
                <span className="text-cyan-500/40">Biometric Verified</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                  <FileText className="h-4 w-4 text-cyan-500/60" />
                </div>
                <input
                  id="auth_passport_input"
                  type="text"
                  required
                  value={passportNo}
                  onChange={(e) => setPassportNo(e.target.value)}
                  placeholder="EP948201A"
                  className="w-full pl-10 pr-4 py-3 bg-[#0a182f]/50 border border-cyan-600/20 rounded-xl font-sans text-sm text-white placeholder-gray-600 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none transition-all uppercase"
                />
              </div>
            </div>

            {isRegister && (
              <>
                {/* Email Address */}
                <div>
                  <label className="block text-[10px] font-mono text-cyan-500/80 mb-1.5 uppercase tracking-widest">
                    Secure Email Address
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                      <Mail className="h-4 w-4 text-cyan-500/60" />
                    </div>
                    <input
                      id="auth_email_input"
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="elena@example.com"
                      className="w-full pl-10 pr-4 py-3 bg-[#0a182f]/50 border border-cyan-600/20 rounded-xl font-sans text-sm text-white placeholder-gray-600 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none transition-all"
                    />
                  </div>
                </div>

                {/* Phone Number */}
                <div>
                  <label className="block text-[10px] font-mono text-cyan-500/80 mb-1.5 uppercase tracking-widest">
                    Emergency Phone contact
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                      <Phone className="h-4 w-4 text-cyan-500/60" />
                    </div>
                    <input
                      id="auth_phone_input"
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+41 79 123 4567"
                      className="w-full pl-10 pr-4 py-3 bg-[#0a182f]/50 border border-cyan-600/20 rounded-xl font-sans text-sm text-white placeholder-gray-600 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none transition-all"
                    />
                  </div>
                </div>
              </>
            )}

            <button
              id="auth_submit_btn"
              type="submit"
              className="w-full mt-6 py-4 bg-cyan-500 hover:bg-cyan-400 text-black font-display font-extrabold rounded-xl transition-all flex items-center justify-center space-x-2 text-sm shadow-[0_0_15px_rgba(6, 182, 212,0.2)] hover:shadow-[0_0_25px_rgba(6, 182, 212,0.4)] cursor-pointer"
            >
              <span>{isRegister ? "GENERATE SECURITY PROFILE" : "ESTABLISH SECURE CONNECT"}</span>
              <ChevronRight className="h-5 w-5" />
            </button>
          </form>

          {/* Secure disclaimer */}
          <div className="mt-6 flex items-center space-x-2 justify-center text-[10px] font-mono text-cyan-500/40 border-t border-cyan-600/10 pt-4">
            <CheckCircle2 className="h-3.5 w-3.5 text-cyan-500/50" />
            <span>AES-256 SYSTEM ENCRYPTION TERMINAL</span>
          </div>
        </motion.div>
      </div>

      {/* Footer */}
      <footer className="relative z-10 py-6 text-center text-[10px] font-mono text-gray-600 border-t border-cyan-600/10 bg-[#020617]/50 mt-auto">
        AEGIS PRIVACY CORE | COMPLIANT WITH INDEPENDENT WORLDWIDE EMBASSY TRAVEL PROTOCOLS
      </footer>
    </div>
  );
}
