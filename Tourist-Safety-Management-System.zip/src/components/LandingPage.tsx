import React, { useState } from "react";
import { motion } from "motion/react";
import { Shield, Map, Compass, Navigation, Globe, Eye, Server, Radio, HeartPulse, ChevronRight } from "lucide-react";
import { AppScreen } from "../types";

interface LandingPageProps {
  onNavigate: (screen: AppScreen) => void;
}

interface DestinationNode {
  id: string;
  name: string;
  region: string;
  lat: string;
  lng: string;
  status: "SECURE" | "MONITORED" | "ADVISORY";
  hazard: string;
  riskIndex: number;
  activeBeacons: number;
  x: number; // percentage coordinate on SVG
  y: number; // percentage coordinate on SVG
}

export default function LandingPage({ onNavigate }: LandingPageProps) {
  const [selectedDest, setSelectedDest] = useState<DestinationNode | null>(null);

  const destinations: DestinationNode[] = [
    {
      id: "alps",
      name: "Swiss Alps Trekking",
      region: "Switzerland",
      lat: "46.0207° N",
      lng: "7.7491° E",
      status: "MONITORED",
      hazard: "Sudden Fog & Snow Drift",
      riskIndex: 24,
      activeBeacons: 142,
      x: 48,
      y: 35,
    },
    {
      id: "reef",
      name: "Great Barrier Reef",
      region: "Australia",
      lat: "18.2871° S",
      lng: "147.6992° E",
      status: "SECURE",
      hazard: "Strong Riptide warnings in Sector 3B",
      riskIndex: 12,
      activeBeacons: 98,
      x: 85,
      y: 72,
    },
    {
      id: "grand-canyon",
      name: "Grand Canyon Explorer",
      region: "USA",
      lat: "36.0544° N",
      lng: "-112.1401° W",
      status: "SECURE",
      hazard: "Extreme afternoon heat index",
      riskIndex: 18,
      activeBeacons: 231,
      x: 18,
      y: 38,
    },
    {
      id: "sahara",
      name: "Sahara Desert Crossing",
      region: "Morocco",
      lat: "24.8864° N",
      lng: "-0.1276° W",
      status: "ADVISORY",
      hazard: "High dehydration risk & shifting dunes",
      riskIndex: 45,
      activeBeacons: 34,
      x: 45,
      y: 48,
    },
    {
      id: "fuji",
      name: "Mount Fuji Summit",
      region: "Japan",
      lat: "35.3606° N",
      lng: "138.7274° E",
      status: "SECURE",
      hazard: "High-altitude oxygen reduction",
      riskIndex: 15,
      activeBeacons: 189,
      x: 78,
      y: 40,
    }
  ];

  return (
    <div className="relative min-h-screen bg-white overflow-x-hidden text-gray-100 flex flex-col font-sans">
      {/* Background travel image with gradient overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-25 mix-blend-overlay pointer-events-none"
        style={{ backgroundImage: `url('/src/assets/images/travel_background_1784446490513.jpg')` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#020817]/90 via-[#03132e]/90 to-[#020817] pointer-events-none" />
      
      {/* Grid Pattern overlay */}
      <div className="absolute inset-0 grid-bg opacity-30 pointer-events-none" />

      {/* Header / Navbar */}
      <header className="relative z-10 max-w-7xl w-full mx-auto px-6 py-5 flex items-center justify-between border-b border-cyan-600/10 backdrop-blur-md">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <div className="absolute -inset-1 bg-cyan-600/30 rounded-lg blur opacity-75"></div>
            <div className="relative bg-[#0b1d3a] p-2 rounded-lg border border-cyan-500/30 flex items-center justify-center">
              <Shield className="h-6 w-6 text-cyan-500" />
            </div>
          </div>
          <div>
            <span className="font-display font-black text-2xl tracking-wider text-white glow-text-cyan flex items-center">
              AEGIS
              <span className="text-cyan-500 text-xs font-semibold ml-2 border border-cyan-500/30 px-1.5 py-0.5 rounded uppercase tracking-widest bg-cyan-950/40">
                v2.0
              </span>
            </span>
          </div>
        </div>
        
        <nav className="hidden md:flex items-center space-x-8 text-sm font-medium text-gray-300">
          <a href="#features" className="hover:text-cyan-500 transition-colors">Features</a>
          <a href="#interactive-map" className="hover:text-cyan-500 transition-colors">Safety Grid</a>
          <a href="#overview" className="hover:text-cyan-500 transition-colors">Global Network</a>
        </nav>

        <div className="flex items-center space-x-4">
          <button 
            id="admin_portal_btn"
            onClick={() => onNavigate("admin")}
            className="text-xs font-mono border border-red-500/30 text-red-400 px-3 py-2 rounded-md hover:bg-red-950/20 hover:border-red-500/60 transition-all cursor-pointer"
          >
            ADMIN DECK
          </button>
          <button 
            id="get_started_btn"
            onClick={() => onNavigate("auth")}
            className="relative group px-5 py-2.5 rounded-lg font-display font-bold text-sm text-black bg-cyan-500 hover:bg-cyan-400 transition-all shadow-[0_0_15px_rgba(6, 182, 212,0.3)] hover:shadow-[0_0_25px_rgba(6, 182, 212,0.5)] cursor-pointer"
          >
            START MONITORING
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <main className="relative z-10 flex-grow max-w-7xl w-full mx-auto px-6 py-12 md:py-24 flex flex-col items-center">
        <div className="text-center max-w-4xl mx-auto mb-16">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center space-x-2 bg-cyan-950/50 border border-cyan-600/20 px-3 py-1.5 rounded-full text-xs font-semibold tracking-wider text-cyan-500 uppercase mb-6"
          >
            <Radio className="h-3 w-3 animate-pulse text-cyan-500" />
            <span>Next-Gen Autonomous Travel Shield</span>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="font-display text-4xl md:text-7xl font-extrabold tracking-tight text-white mb-6 leading-tight"
          >
            Smart Safety <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 via-blue-500 to-white glow-text-cyan">
              For Global Tourists
            </span>
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-base md:text-xl text-gray-400 leading-relaxed max-w-2xl mx-auto mb-10"
          >
            Embark on any global journey secured by AEGIS. Generating an encrypted digital safety profile, live geo-fencing, and Gemini AI-powered hazard mitigation that deploys responsive aid within minutes.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <button
              id="hero_primary_btn"
              onClick={() => onNavigate("auth")}
              className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-cyan-600 to-blue-900 text-white font-display font-extrabold rounded-xl hover:from-cyan-500 hover:to-blue-800 transition-all duration-300 flex items-center justify-center space-x-3 shadow-lg hover:shadow-cyan-600/20 text-base border border-cyan-500/20 cursor-pointer"
            >
              <span>Setup Digital Safety ID</span>
              <ChevronRight className="h-5 w-5" />
            </button>
            <a
              id="hero_secondary_btn"
              href="#interactive-map"
              className="w-full sm:w-auto px-8 py-4 bg-gray-950/40 hover:bg-gray-900/60 text-gray-300 font-display font-medium rounded-xl border border-gray-800 hover:border-cyan-600/30 transition-all flex items-center justify-center space-x-2 text-base"
            >
              <Globe className="h-5 w-5 text-cyan-500" />
              <span>Explore Safety Grid</span>
            </a>
          </motion.div>
        </div>

        {/* Live Grid Stats Ticker */}
        <div className="w-full mb-20 overflow-hidden relative py-3 border-y border-cyan-600/10 bg-cyan-950/10 backdrop-blur-md">
          <div className="flex whitespace-nowrap animate-ticker text-xs font-mono tracking-widest text-cyan-500">
            <span className="mx-8 flex items-center gap-2">● SYSTEM STATUS: ONLINE</span>
            <span className="mx-8 flex items-center gap-2">● TOTAL ACTIVE GEOSHILDS: 14,892</span>
            <span className="mx-8 flex items-center gap-2">● AI RESPONSE LATENCY: 140MS</span>
            <span className="mx-8 flex items-center gap-2">● EMERGENCY CHANNELS: ACTIVE</span>
            <span className="mx-8 flex items-center gap-2">● GPS TRIANGULATION SATELLITES: 24/24 ONLINE</span>
            <span className="mx-8 flex items-center gap-2">● SYSTEM STATUS: ONLINE</span>
            <span className="mx-8 flex items-center gap-2">● TOTAL ACTIVE GEOSHILDS: 14,892</span>
            <span className="mx-8 flex items-center gap-2">● AI RESPONSE LATENCY: 140MS</span>
          </div>
        </div>

        {/* Interactive World Map Section */}
        <div id="interactive-map" className="w-full max-w-5xl mx-auto mb-24 scroll-mt-20">
          <div className="text-center mb-10">
            <h2 className="font-display text-3xl font-extrabold text-white">Interactive Global Safety Grid</h2>
            <p className="text-gray-400 mt-2 max-w-lg mx-auto text-sm">
              Click on active geographical coordinates below to query live geo-fencing barriers and AI safety advisory logs.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* World Map Container (2/3 width on large screens) */}
            <div className="lg:col-span-2 glass-card rounded-2xl p-4 flex flex-col justify-between relative overflow-hidden h-[400px]">
              {/* Scanline element */}
              <div className="absolute inset-x-0 h-[2px] bg-cyan-500/20 top-0 animate-scanline pointer-events-none" />
              
              <div className="flex items-center justify-between border-b border-cyan-600/10 pb-3 mb-2">
                <div className="flex items-center space-x-2">
                  <Globe className="h-4 w-4 text-cyan-500 animate-spin-slow" />
                  <span className="text-xs font-mono text-cyan-500 tracking-wider">LIVE PLANETARY SATELLITE OVERLAY</span>
                </div>
                <div className="flex space-x-1.5">
                  <div className="h-2 w-2 rounded-full bg-cyan-500 animate-ping" />
                  <div className="h-2 w-2 rounded-full bg-cyan-500" />
                </div>
              </div>

              {/* World SVG Map */}
              <div className="relative flex-grow flex items-center justify-center p-4">
                <svg viewBox="0 0 1000 500" className="w-full h-full opacity-60">
                  {/* Styled minimalist world outline background */}
                  <path 
                    fill="rgba(6, 182, 212, 0.05)" 
                    stroke="rgba(6, 182, 212, 0.15)" 
                    strokeWidth="1.2"
                    d="M150,150 Q180,130 200,160 T250,180 T300,140 T350,150 T400,200 T430,170 T480,180 T520,130 T600,160 T680,120 T750,140 T850,180 T920,220 L950,240 L900,320 L840,350 L800,310 L780,340 L710,380 L680,320 L650,330 L600,390 L580,350 L500,380 L440,320 L400,310 L340,380 L290,390 L240,310 L190,280 L120,250 L100,220 Z M220,380 Q250,420 280,390 Z M750,360 Q800,420 850,440 Z" 
                  />
                  {/* Swiss Alps Trekking coordinates */}
                  <line x1="500" y1="0" x2="500" y2="500" stroke="rgba(6, 182, 212, 0.04)" strokeDasharray="5" />
                  <line x1="0" y1="250" x2="1000" y2="250" stroke="rgba(6, 182, 212, 0.04)" strokeDasharray="5" />
                </svg>

                {/* Plotting Destination Nodes */}
                {destinations.map((dest) => (
                  <button
                    key={dest.id}
                    onClick={() => setSelectedDest(dest)}
                    style={{ left: `${dest.x}%`, top: `${dest.y}%` }}
                    className="absolute -translate-x-1/2 -translate-y-1/2 group z-20 focus:outline-none cursor-pointer"
                  >
                    <span className="absolute -inset-2 bg-cyan-500/20 rounded-full scale-0 group-hover:scale-100 transition-all duration-300"></span>
                    <span className="relative flex h-5 w-5 items-center justify-center">
                      <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                        dest.status === "ADVISORY" ? "bg-amber-400/40" : "bg-cyan-500/40"
                      }`} />
                      <span className={`relative inline-flex rounded-full h-3 w-3 border border-white/40 ${
                        dest.status === "ADVISORY" ? "bg-amber-400" : "bg-cyan-500"
                      }`} />
                    </span>
                    <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 bg-[#0a192f] border border-cyan-500/30 px-2 py-1 rounded text-[10px] font-mono text-white opacity-0 group-hover:opacity-100 whitespace-nowrap transition-all duration-300 pointer-events-none">
                      {dest.name}
                    </div>
                  </button>
                ))}
              </div>

              <div className="text-[10px] font-mono text-cyan-500/60 mt-2 flex justify-between">
                <span>RADAR AZIMUTH: 312° S</span>
                <span>GEO-RADIUS SCANNING ACTIVE</span>
              </div>
            </div>

            {/* Selected Node Telemetry Sidebar */}
            <div className="glass-card rounded-2xl p-6 flex flex-col justify-between">
              {selectedDest ? (
                <div className="flex flex-col h-full justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-[10px] font-mono bg-cyan-950 text-cyan-500 border border-cyan-500/20 px-2 py-0.5 rounded-full">
                        COORD LOCK
                      </span>
                      <span className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full font-bold ${
                        selectedDest.status === "ADVISORY" 
                          ? "bg-amber-950 text-amber-400 border border-amber-500/20" 
                          : "bg-emerald-950 text-emerald-400 border border-emerald-500/20"
                      }`}>
                        {selectedDest.status}
                      </span>
                    </div>

                    <h3 className="font-display font-extrabold text-xl text-white mb-1">
                      {selectedDest.name}
                    </h3>
                    <p className="text-gray-400 text-xs mb-4">{selectedDest.region}</p>

                    <div className="space-y-3.5 border-t border-cyan-600/10 pt-4">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-gray-400 font-mono">LATITUDE:</span>
                        <span className="text-white font-mono">{selectedDest.lat}</span>
                      </div>
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-gray-400 font-mono">LONGITUDE:</span>
                        <span className="text-white font-mono">{selectedDest.lng}</span>
                      </div>
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-gray-400 font-mono">SAFETY RATING:</span>
                        <span className="text-cyan-500 font-mono font-bold">{(100 - selectedDest.riskIndex)}%</span>
                      </div>
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-gray-400 font-mono">ACTIVE BEACONS:</span>
                        <span className="text-white font-mono">{selectedDest.activeBeacons} units</span>
                      </div>
                    </div>

                    <div className="mt-5 p-3 rounded-lg bg-cyan-950/30 border border-cyan-600/15">
                      <p className="text-[10px] font-mono text-cyan-500 mb-1">ACTIVE AI THREAT SCANNER:</p>
                      <p className="text-xs text-gray-300 leading-relaxed italic">
                        "{selectedDest.hazard}"
                      </p>
                    </div>
                  </div>

                  <button
                    id={`dest_deploy_btn_${selectedDest.id}`}
                    onClick={() => onNavigate("auth")}
                    className="w-full mt-6 py-3 bg-cyan-500/10 hover:bg-cyan-500 text-cyan-500 hover:text-black font-display font-bold text-xs rounded-lg border border-cyan-500/30 transition-all tracking-wider flex items-center justify-center space-x-2 uppercase cursor-pointer"
                  >
                    <Navigation className="h-4.5 w-4.5" />
                    <span>Deploy Shield Here</span>
                  </button>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-center py-10">
                  <div className="p-3 bg-cyan-950/30 rounded-full border border-cyan-500/20 mb-4 animate-bounce">
                    <Compass className="h-8 w-8 text-cyan-500" />
                  </div>
                  <h4 className="font-display font-bold text-white text-base">Select Telemetry Node</h4>
                  <p className="text-gray-400 text-xs max-w-[200px] mt-2">
                    Click a node on the planetary satellite scanner to unlock live telemetry feed.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Features Bento Grid */}
        <div id="features" className="w-full max-w-5xl mx-auto scroll-mt-20 mb-20">
          <div className="text-center mb-16">
            <h2 className="font-display text-3xl font-extrabold text-white">Full-Stack Safety Architecture</h2>
            <p className="text-gray-400 mt-2 max-w-lg mx-auto text-sm">
              Explore how AEGIS delivers bulletproof safety monitoring through edge sensors, AI diagnostics, and ground rescue.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="glass-card glass-card-hover rounded-2xl p-6 flex flex-col justify-between">
              <div className="p-3 bg-cyan-950/50 rounded-lg border border-cyan-500/30 w-fit mb-6">
                <Compass className="h-6 w-6 text-cyan-500" />
              </div>
              <div>
                <h3 className="font-display font-extrabold text-lg text-white mb-2">Digital Tourist ID</h3>
                <p className="text-gray-400 text-xs leading-relaxed">
                  Generate secure, blockchain-verified digital tourist passports complete with automated QR codes, profile credentials, and digital verified badges.
                </p>
              </div>
            </div>

            <div className="glass-card glass-card-hover rounded-2xl p-6 flex flex-col justify-between">
              <div className="p-3 bg-cyan-950/50 rounded-lg border border-cyan-500/30 w-fit mb-6">
                <Map className="h-6 w-6 text-cyan-500" />
              </div>
              <div>
                <h3 className="font-display font-extrabold text-lg text-white mb-2">Active Geo-Fencing</h3>
                <p className="text-gray-400 text-xs leading-relaxed">
                  Initialize active radar perimeters relative to current terrains. Track positions with precise simulated latitude and longitude and trigger instantaneous alerts on boundary exit.
                </p>
              </div>
            </div>

            <div className="glass-card glass-card-hover rounded-2xl p-6 flex flex-col justify-between">
              <div className="p-3 bg-cyan-950/50 rounded-lg border border-cyan-500/30 w-fit mb-6">
                <Server className="h-6 w-6 text-cyan-500" />
              </div>
              <div>
                <h3 className="font-display font-extrabold text-lg text-white mb-2">Gemini AI Engine</h3>
                <p className="text-gray-400 text-xs leading-relaxed">
                  Secure server-side API monitors live travel status. Gemini flash dynamically generates terrain risk factors and safety recommendations contextually.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-cyan-600/10 py-8 bg-[#020617] backdrop-blur-md text-xs text-gray-500 text-center w-full mt-auto px-6">
        <div className="max-w-7xl w-full mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <Shield className="h-4 w-4 text-cyan-500" />
            <span className="font-mono text-cyan-500/70 tracking-wider">AEGIS COGNITIVE DEFENSE NETWORK © 2026</span>
          </div>
          <div className="flex items-center space-x-6 font-mono">
            <span>SATELLITES: 24/24 ONLINE</span>
            <span>SECURE LINK: TLS 1.3</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
