import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Shield, Zap, AlertTriangle, Compass, ShieldAlert, Heart, Radio, MapPin, Loader2, ArrowLeft, Terminal, CheckCircle2, Navigation } from "lucide-react";
import { AppScreen, TouristProfile, SOSBeacon, RescueOperation, RescueStage } from "../types";

interface AdminPanelProps {
  onNavigate: (screen: AppScreen) => void;
  sosBeacon: SOSBeacon;
  rescueOperation: RescueOperation;
  onDispatchRescue: () => void;
  onDeescalate: () => void;
  touristProfile: TouristProfile | null;
}

export default function AdminPanel({
  onNavigate,
  sosBeacon,
  rescueOperation,
  onDispatchRescue,
  onDeescalate,
  touristProfile
}: AdminPanelProps) {
  const [operatorLog, setOperatorLog] = useState<string[]>([]);
  const [activeStage, setActiveStage] = useState(0);

  const addOperatorLog = (msg: string) => {
    const stamp = new Date().toLocaleTimeString();
    setOperatorLog(prev => [...prev, `[${stamp}] ${msg}`]);
  };

  // Log active state changes
  useEffect(() => {
    if (sosBeacon.active) {
      addOperatorLog(`🚨 INCOMING ALARM: SOS distress beacon triggered by ${sosBeacon.touristName || "Unknown Traveler"}!`);
      addOperatorLog(`📡 TELEMETRY LOCK: Lat ${sosBeacon.lat?.toFixed(5)}°, Lng ${sosBeacon.lng?.toFixed(5)}°`);
      addOperatorLog(`👤 PROFILE ID: ${sosBeacon.touristId} | PASSPORT: ${sosBeacon.passportNo}`);
    } else {
      addOperatorLog("ℹ STATUS: Planetary safety tracking grid nominal. Ready for distress signals.");
    }
  }, [sosBeacon.active]);

  // Handle stage ticking during active dispatch
  useEffect(() => {
    if (rescueOperation.active) {
      addOperatorLog(`🚀 DISPATCH AUTHORIZED: Incident ID #${rescueOperation.dispatchId}`);
      addOperatorLog("🚁 Drone Scout (AEGIS-Scout-4) launched and routed to coordinate lock.");
      addOperatorLog("🚒 Mountain / Coast Rescue Unit Alpha dispatched with emergency gear.");
    }
  }, [rescueOperation.active]);

  return (
    <div className={`relative min-h-screen bg-white text-gray-100 flex flex-col font-sans overflow-x-hidden ${
      sosBeacon.active && !rescueOperation.active ? "bg-red-950/20 animate-sos-flash" : ""
    }`}>
      {/* Sat Map Overlay in background */}
      <div className="absolute inset-0 grid-bg opacity-20 pointer-events-none" />
      <div className="absolute inset-0 overflow-hidden pointer-events-none select-none">
        <Terminal className="absolute -right-14 -top-14 h-80 w-80 text-cyan-600/[0.05] rotate-6" strokeWidth={0.4} />
        <Radio className="absolute -left-16 bottom-0 h-72 w-72 text-red-600/[0.05] -rotate-12" strokeWidth={0.4} />
      </div>

      {/* Admin header */}
      <header className="relative z-10 max-w-7xl w-full mx-auto px-6 py-4 flex items-center justify-between border-b border-red-500/20 backdrop-blur-md">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <div className={`absolute -inset-1 rounded-lg blur opacity-75 ${sosBeacon.active ? "bg-red-500" : "bg-cyan-600/30"}`} />
            <div className="relative bg-[#1a0e10] p-1.5 rounded-lg border border-red-500/30 flex items-center justify-center">
              <ShieldAlert className={`h-5 w-5 ${sosBeacon.active ? "text-red-400" : "text-cyan-500"}`} />
            </div>
          </div>
          <div>
            <span className="font-display font-black text-lg tracking-wider text-white">AEGIS HQ</span>
            <span className="text-[9px] font-mono block text-red-400/80 leading-none">RESCUE DISPATCH CENTER</span>
          </div>
        </div>

        <button
          id="admin_back_to_tourist_btn"
          onClick={() => onNavigate("dashboard")}
          className="flex items-center space-x-2 text-xs font-mono border border-cyan-600/20 px-3.5 py-1.5 bg-[#09182d] rounded-md text-cyan-500 hover:text-white hover:border-cyan-600/50 transition-all cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>RETURN TO TOURIST RADAR HUD</span>
        </button>
      </header>

      {/* Main Admin Dashboard */}
      <main className="relative z-10 flex-grow max-w-7xl w-full mx-auto px-6 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        
        {/* Left Side: Active Alarm Status & Dispatch Controls (7 cols) */}
        <div className="lg:col-span-7 flex flex-col space-y-8">
          
          {/* Main Command Monitor */}
          <div className="glass-card rounded-2xl p-6 border-red-500/20 flex flex-col justify-between relative overflow-hidden flex-grow">
            {/* Top scanning accent bar */}
            <div className={`absolute top-0 inset-x-0 h-[2.5px] ${
              sosBeacon.active ? "bg-red-500 shadow-[0_0_10px_#ef4444]" : "bg-cyan-500"
            }`} />

            <div>
              <div className="flex items-center justify-between border-b border-gray-800 pb-4 mb-6">
                <h3 className="font-display font-extrabold text-base tracking-wider flex items-center gap-2">
                  <Terminal className="h-4.5 w-4.5 text-red-400" />
                  INCIDENT COMMAND CONSOLE
                </h3>
                <span className="text-[10px] font-mono bg-[#160b0e] text-red-400 border border-red-500/20 px-2.5 py-0.5 rounded-full uppercase tracking-widest font-bold">
                  {sosBeacon.active ? "ALERT DETECTED" : "Nominal Scanning"}
                </span>
              </div>

              {/* Conditional Display of distress */}
              {!sosBeacon.active ? (
                <div className="py-20 text-center flex flex-col items-center justify-center">
                  <div className="p-4 bg-cyan-950/20 border border-cyan-500/20 rounded-full mb-4 animate-pulse">
                    <Radio className="h-8 w-8 text-cyan-500" />
                  </div>
                  <h4 className="font-display font-bold text-gray-400 text-sm">Planetary Tracking Nominal</h4>
                  <p className="text-gray-500 text-[11px] max-w-xs mt-1 leading-relaxed">
                    No active distress signals. Tourist safety beacons are actively streaming telemetry data into the planetary grid database.
                  </p>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Alarm summary banner */}
                  <div className="p-4 bg-red-950/40 border border-red-500/40 rounded-xl flex items-center space-x-4">
                    <div className="p-2.5 bg-red-900/40 border border-red-500/30 rounded-lg shrink-0">
                      <AlertTriangle className="h-7 w-7 text-red-400 animate-ping" />
                    </div>
                    <div>
                      <p className="text-[9px] font-mono text-red-400 uppercase tracking-wider font-bold">SOS DISTRESS ALARM BREACH</p>
                      <h4 className="font-display font-black text-base text-white">{sosBeacon.touristName}</h4>
                      <p className="text-[10px] text-gray-400 mt-1">
                        Biometric safety shield breached at coordinate Lat {sosBeacon.lat?.toFixed(5)}°, Lng {sosBeacon.lng?.toFixed(5)}°
                      </p>
                    </div>
                  </div>

                  {/* Active Incident Metadata table */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-950/40 p-4 rounded-xl border border-red-500/10">
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between font-mono">
                        <span className="text-gray-500 uppercase">Tourist Profile ID:</span>
                        <span className="text-white font-bold">{sosBeacon.touristId}</span>
                      </div>
                      <div className="flex justify-between font-mono">
                        <span className="text-gray-500 uppercase">Passport No:</span>
                        <span className="text-white font-bold">{sosBeacon.passportNo}</span>
                      </div>
                      <div className="flex justify-between font-mono">
                        <span className="text-gray-500 uppercase">Emergency Contact:</span>
                        <span className="text-white font-bold">{sosBeacon.phone}</span>
                      </div>
                    </div>
                    <div className="space-y-2 text-xs border-t md:border-t-0 md:border-l border-red-500/10 pt-2 md:pt-0 md:pl-4">
                      <div className="flex justify-between font-mono">
                        <span className="text-gray-500 uppercase">Distress Latitude:</span>
                        <span className="text-red-400 font-bold">{sosBeacon.lat?.toFixed(5)}°</span>
                      </div>
                      <div className="flex justify-between font-mono">
                        <span className="text-gray-500 uppercase">Distress Longitude:</span>
                        <span className="text-red-400 font-bold">{sosBeacon.lng?.toFixed(5)}°</span>
                      </div>
                      <div className="flex justify-between font-mono">
                        <span className="text-gray-500 uppercase">Time Triggered:</span>
                        <span className="text-white font-bold">{sosBeacon.timestamp}</span>
                      </div>
                    </div>
                  </div>

                  {/* Dispatch control buttons */}
                  <div className="pt-4 border-t border-red-500/10 space-y-4">
                    {rescueOperation.active ? (
                      <div className="space-y-4">
                        <div className="p-4 bg-emerald-950/20 border border-emerald-500/30 rounded-xl flex items-center space-x-3 text-emerald-200">
                          <CheckCircle2 className="h-6 w-6 text-emerald-400 animate-pulse shrink-0" />
                          <div>
                            <p className="text-[10px] font-mono tracking-wider opacity-60">HQ SECURE DISPATCH COMPLETED</p>
                            <h4 className="font-display font-black text-sm uppercase tracking-wider text-emerald-400">Rescue Team Dispatched.</h4>
                            <p className="text-[10px] opacity-80 leading-snug mt-0.5">Scout Drone is overhead. Ground response teams are making active speed to coordinates.</p>
                          </div>
                        </div>

                        <div className="flex space-x-3">
                          <button
                            id="deescalate_incident_btn"
                            onClick={onDeescalate}
                            className="flex-grow py-3 bg-slate-950 hover:bg-slate-900 border border-cyan-600/20 rounded-xl font-mono text-xs text-cyan-500 hover:text-white transition-all cursor-pointer font-bold"
                          >
                            RESOLVE & STAND DOWN INCIDENT ALARM
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col md:flex-row gap-4">
                        <button
                          id="authorize_dispatch_btn"
                          onClick={onDispatchRescue}
                          className="flex-grow py-4 bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white font-display font-black text-sm rounded-xl tracking-wider shadow-lg hover:shadow-red-500/25 transition-all flex items-center justify-center space-x-2 border border-red-500/30 cursor-pointer"
                        >
                          <Navigation className="h-5 w-5 animate-pulse" />
                          <span>AUTHORIZE EMERGENCY RESCUE TEAM DISPATCH</span>
                        </button>

                        <button
                          id="deescalate_early_btn"
                          onClick={onDeescalate}
                          className="py-4 px-6 bg-slate-950 border border-gray-800 hover:border-gray-700 text-gray-400 hover:text-white font-mono text-xs rounded-xl transition-all cursor-pointer"
                        >
                          DISMISS SIGNAL
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Operator tracking grid notes */}
            <div className="text-[9px] font-mono text-red-400/40 mt-4 flex justify-between border-t border-gray-900 pt-3">
              <span>RESPONSIBLE OFFICE: INTERNATION SECURE ALLIANCE</span>
              <span>AES-256 SYNC ACTIVE</span>
            </div>
          </div>
        </div>

        {/* Right Side: Biometric feed sync & active dispatch log stream (5 cols) */}
        <div className="lg:col-span-5 flex flex-col space-y-8">
          
          {/* Biometrics Scan Panel */}
          {sosBeacon.active && touristProfile ? (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="glass-card rounded-2xl p-6 border-red-500/10 space-y-4"
            >
              <h3 className="text-xs font-mono text-red-400 font-extrabold uppercase border-b border-red-500/10 pb-2 flex items-center gap-1.5">
                <Heart className="h-4 w-4 animate-pulse text-red-500" />
                Target Traveler Identity Verified
              </h3>

              <div className="flex items-center space-x-4 bg-[#0a0709] border border-red-500/10 p-3 rounded-xl">
                <div className="relative">
                  <img
                    src={touristProfile.avatarUrl}
                    alt={touristProfile.name}
                    referrerPolicy="no-referrer"
                    className="h-16 w-14 rounded-md object-cover border border-red-500/30"
                  />
                  <div className="absolute inset-x-0 h-[1.5px] bg-red-400 top-0 animate-scanline pointer-events-none" />
                </div>
                <div>
                  <h4 className="font-display font-black text-sm text-white uppercase tracking-wider">{touristProfile.name}</h4>
                  <p className="text-[10px] font-mono text-gray-400">PASSPORT: {touristProfile.passportNo}</p>
                  <p className="text-[9px] font-mono text-red-400/80 bg-red-950/40 px-2 py-0.5 rounded-full inline-block mt-1 font-bold">
                    BIOMETRIC RECONSTRUCT: OK
                  </p>
                </div>
              </div>

              {/* Coordinates visual pin marker */}
              <div className="p-3 bg-red-950/20 border border-red-500/10 rounded-xl space-y-2">
                <div className="flex items-center space-x-2 text-xs font-mono text-red-300">
                  <MapPin className="h-4.5 w-4.5 text-red-500 animate-pulse" />
                  <span>GPS COORDS LOCKED:</span>
                </div>
                <div className="bg-black/40 p-2 rounded text-center text-xs font-mono font-bold text-white tracking-widest border border-red-500/5">
                  LAT: {sosBeacon.lat?.toFixed(5)}° | LNG: {sosBeacon.lng?.toFixed(5)}°
                </div>
              </div>
            </motion.div>
          ) : (
            <div className="glass-card rounded-2xl p-6 border-cyan-600/10 space-y-4 flex flex-col items-center justify-center text-center py-12">
              <Compass className="h-8 w-8 text-cyan-500/40 animate-spin-slow" />
              <h4 className="font-display font-bold text-gray-400 text-sm">Target Identity Off-Line</h4>
              <p className="text-gray-500 text-[10px] max-w-[200px] mt-1 leading-relaxed">
                Biometric passport and profile information will synchronize dynamically here once a live SOS beacon is received.
              </p>
            </div>
          )}

          {/* Operator Action logs feed */}
          <div className="glass-card rounded-2xl p-6 border-cyan-600/10 flex flex-col h-full flex-grow">
            <h3 className="text-xs font-mono text-cyan-500 font-extrabold uppercase border-b border-cyan-600/10 pb-2 mb-3">
              📝 OPERATOR DISPATCH TRANSCRIPT
            </h3>
            
            <div className="flex-grow overflow-y-auto font-mono text-[9px] text-gray-400 space-y-2 scrollbar-thin scrollbar-thumb-cyan-900 pr-1 max-h-[220px]">
              {operatorLog.map((log, index) => (
                <div key={index} className="leading-relaxed pl-1.5 border-l border-red-500/10">
                  {log}
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="py-5 text-center text-[10px] font-mono text-gray-600 border-t border-red-500/10 bg-[#02050b] w-full mt-auto">
        AEGIS MISSION HQ CONTROLS | EMERGENCY COMMUNICATIONS OPERATED SECURELY BY INTERNATIONAL TELEMETRY GROUPS
      </footer>
    </div>
  );
}
