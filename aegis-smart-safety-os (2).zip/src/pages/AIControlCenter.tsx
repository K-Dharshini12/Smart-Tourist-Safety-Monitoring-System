import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { 
  ArrowLeft, Cpu, Sliders, Sun, Send, MessageSquare, 
  AlertTriangle, CloudRain, Wind, ShieldCheck, Heart,
  Activity, Navigation, Compass, AlertOctagon, CloudSun
} from 'lucide-react';

export default function AIControlCenter() {
  const { setPage, theme } = useApp();
  const isDark = theme === 'dark';

  // --- Neural Risk Factor Predictor States ---
  const [crowdDensity, setCrowdDensity] = useState(65);       // %
  const [policeDensity, setPoliceDensity] = useState(80);      // %
  const [timeOfDay, setTimeOfDay] = useState(14);              // Hour (24h format)
  const [localAlertness, setLocalAlertness] = useState(40);    // %
  const [calculatedThreat, setCalculatedThreat] = useState(12); // Threatened %

  // --- Safe Route states ---
  const [activeRouteCheck, setActiveRouteCheck] = useState<'louvre' | 'shortcut'>('louvre');

  // --- Weather States ---
  const [selectedWeatherLocation, setSelectedWeatherLocation] = useState<'Louvre' | 'Saint-Denis' | 'Notre-Dame'>('Louvre');

  // --- Crime Heatmap Stats ---
  const [crimeHeatFilter, setCrimeHeatFilter] = useState<'pickpocket' | 'physical' | 'scam'>('pickpocket');

  // --- AI Chat States ---
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState<Array<{ sender: 'user' | 'assistant'; text: string }>>([
    { sender: 'assistant', text: 'Aegis OS Neural Assistant ready. Adjust the neural parameters on the left, check localized crime indexes, or ask me for translations!' }
  ]);
  const [isTypingAI, setIsTypingAI] = useState(false);

  // Recalculate Threat Factor Heuristic when sliders change
  useEffect(() => {
    // Math model: high crowding increases pickpockets, low police spikes risk, night hour (22-4) spikes risk, high local alertness helps reduce risk.
    let baseThreat = (crowdDensity * 0.4) - (policeDensity * 0.5) + (localAlertness * 0.1);
    
    // Night penalty
    if (timeOfDay >= 20 || timeOfDay <= 5) {
      baseThreat += 30;
    } else if (timeOfDay >= 17) {
      baseThreat += 12;
    }

    const threatValue = Math.max(2, Math.min(99, Math.floor(baseThreat + 35)));
    setCalculatedThreat(threatValue);
  }, [crowdDensity, policeDensity, timeOfDay, localAlertness]);

  const handleAIChatQuestion = (presetText: string) => {
    setChatMessages(prev => [...prev, { sender: 'user', text: presetText }]);
    setIsTypingAI(true);

    setTimeout(() => {
      let answer = "Heuristic modeling shows low risks inside geofenced areas.";
      const lowerQ = presetText.toLowerCase();

      if (lowerQ.includes('louvre') || lowerQ.includes('perimeter')) {
        answer = "Louvre perimeter status: SECURED. Active patrol strength: 12 units. Local safe corridors are fully illuminated. Overall safety rate is 98%.";
      } else if (lowerQ.includes('emergency') || lowerQ.includes('help') || lowerQ.includes('trigger')) {
        answer = "IMMEDIATE PROTOCOL: Open the 'Tactical Map' tab and click the red 'SOS' button. It initiates emergency sirens, streams your live coordinates, and dispatches Police Interceptors and SAMU medics in under 180 seconds.";
      } else if (lowerQ.includes('translate') || lowerQ.includes('french')) {
        answer = "Standard Emergency French Phrases:\n- 'Aidez-moi, s'il vous plaît!' (Help me, please)\n- 'Où est l'hôpital?' (Where is the hospital?)\n- 'Voleur!' (Thief!)\n- 'Appelez la police!' (Call the police!)";
      } else if (lowerQ.includes('hospital') || lowerQ.includes('clinic') || lowerQ.includes('samu')) {
        answer = "SAMU Trauma Care at Hôtel-Dieu is 800m East. Your digital ledger profile is pre-authorized. Proceed via Quai de la Corse.";
      } else if (lowerQ.includes('route') || lowerQ.includes('saint-denis')) {
        answer = "Optimal Safe Route: Proceed strictly along Rue de Rivoli and Boulevard de Sébastopol. Avoid the unpatrolled alleys of Saint-Denis due to high crowd density and reduced police coverage.";
      } else if (lowerQ.includes('threat') || lowerQ.includes('risk')) {
        answer = `Current Threat Level calculated: ${calculatedThreat}%. Adjust the sliders on the left control deck to see how increasing Police density or reducing nighttime exposure lowers travel hazards!`;
      } else {
        answer = `Localized telemetry analysis complete. Under current parameter states (Time: ${timeOfDay}:00, Patrol density: ${policeDensity}%), our models suggest continuing on geofenced blue paths. Let me know if you need translation keys or hospital coordinates!`;
      }

      setChatMessages(prev => [...prev, { sender: 'assistant', text: answer }]);
      setIsTypingAI(false);
    }, 900);
  };

  const handleCustomChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    const txt = chatInput;
    setChatInput('');
    handleAIChatQuestion(txt);
  };

  return (
    <div className="min-h-screen pb-20 pt-6 px-4 sm:px-6 relative">
      <div className="max-w-7xl mx-auto space-y-10">
        
        {/* Title branding */}
        <div className="text-left space-y-2">
          <div className="bg-purple-600/10 text-purple-400 px-3.5 py-1.5 rounded-full text-xs font-mono tracking-wider font-extrabold w-fit border border-purple-500/20">
            AEGIS NEURAL DECK
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight">
            Aegis AI <span className="text-gradient">Control & Neural Engine</span>
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm max-w-2xl leading-relaxed">
            Configure raw neural safety heuristics, query the conversational translator, analyze sub-sector crime rates, and check travel weather advisories.
          </p>
        </div>

        {/* 3-Column Bento Grid */}
        <div className="grid lg:grid-cols-12 gap-8 items-start">
          
          {/* Column A: Neural Sliders & Weather (4 Columns) */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* 1. NEURAL RISK PREDICTOR SLIDERS */}
            <div className={`p-6 rounded-[24px] border text-left space-y-5 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
              <div className="flex items-center space-x-2.5 text-blue-400">
                <Cpu className="h-5 w-5 text-blue-400 animate-pulse" />
                <h4 className="font-extrabold text-xs uppercase tracking-wider text-white">Heuristic Threat Simulator</h4>
              </div>

              <div className="space-y-4">
                
                {/* Slider A: Crowds */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[10px] font-bold">
                    <span className="text-slate-400">Crowd Density</span>
                    <span className="text-white">{crowdDensity}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="10" 
                    max="100" 
                    value={crowdDensity} 
                    onChange={(e) => setCrowdDensity(Number(e.target.value))}
                    className="w-full accent-blue-600 bg-slate-800 h-1 rounded-lg outline-none"
                  />
                </div>

                {/* Slider B: Police Patrols */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[10px] font-bold">
                    <span className="text-slate-400">Police Grid Patrols</span>
                    <span className="text-emerald-400">{policeDensity}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="10" 
                    max="100" 
                    value={policeDensity} 
                    onChange={(e) => setPoliceDensity(Number(e.target.value))}
                    className="w-full accent-emerald-500 bg-slate-800 h-1 rounded-lg outline-none"
                  />
                </div>

                {/* Slider C: Hour of day */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[10px] font-bold">
                    <span className="text-slate-400">Time of Day (Hour)</span>
                    <span className="text-amber-500">{timeOfDay}:00</span>
                  </div>
                  <input 
                    type="range" 
                    min="0" 
                    max="23" 
                    value={timeOfDay} 
                    onChange={(e) => setTimeOfDay(Number(e.target.value))}
                    className="w-full accent-amber-500 bg-slate-800 h-1 rounded-lg outline-none"
                  />
                </div>

                {/* Slider D: Local Alert Level */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[10px] font-bold">
                    <span className="text-slate-400">Sector Alertness Factor</span>
                    <span className="text-purple-400">{localAlertness}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="10" 
                    max="100" 
                    value={localAlertness} 
                    onChange={(e) => setLocalAlertness(Number(e.target.value))}
                    className="w-full accent-purple-500 bg-slate-800 h-1 rounded-lg outline-none"
                  />
                </div>

              </div>

              {/* Real-time Threat Gauge result */}
              <div className="p-4 rounded-xl bg-slate-950/70 border border-white/5 space-y-2 text-center">
                <span className="text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider block">Real-time Predicted Risk Factor</span>
                <div className="flex items-center justify-center space-x-3">
                  <span className={`text-3xl font-black ${calculatedThreat > 60 ? 'text-red-500 animate-pulse' : calculatedThreat > 30 ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {calculatedThreat}%
                  </span>
                  <div className="text-left">
                    <p className="text-[9px] font-bold text-white uppercase">
                      {calculatedThreat > 60 ? '🔴 High Danger Threat' : calculatedThreat > 30 ? '🟡 Moderate Caution' : '🟢 Safe Environment'}
                    </p>
                    <p className="text-[8px] text-slate-500">Heuristic Neural evaluation</p>
                  </div>
                </div>
              </div>

            </div>

            {/* 2. WEATHER HAZARD ADVISOR WIDGET */}
            <div className={`p-6 rounded-[24px] border text-left space-y-4 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
              <div className="flex items-center space-x-2.5 text-amber-500">
                <Sun className="h-5 w-5 text-amber-400" />
                <h4 className="font-extrabold text-xs uppercase tracking-wider text-white">Weather Hazard Advisor</h4>
              </div>

              <div className="flex gap-1 bg-slate-950/40 p-1 border border-white/5 rounded-xl">
                {['Louvre', 'Saint-Denis', 'Notre-Dame'].map(loc => (
                  <button
                    key={loc}
                    onClick={() => setSelectedWeatherLocation(loc as any)}
                    className={`flex-1 py-1.5 text-[9px] font-black uppercase rounded-lg cursor-pointer ${selectedWeatherLocation === loc ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
                  >
                    {loc}
                  </button>
                ))}
              </div>

              {/* Weather parameters */}
              <div className="grid grid-cols-2 gap-3 text-center text-white">
                <div className="p-3 bg-slate-900/40 rounded-xl border border-white/5">
                  <CloudSun className="h-4 w-4 text-yellow-400 mx-auto mb-1" />
                  <p className="text-xs font-black">{selectedWeatherLocation === 'Saint-Denis' ? 'Heavy Showers' : '22°C Clear'}</p>
                  <p className="text-[8px] text-slate-500 uppercase">Condition</p>
                </div>
                <div className="p-3 bg-slate-900/40 rounded-xl border border-white/5">
                  <Wind className="h-4 w-4 text-blue-400 mx-auto mb-1" />
                  <p className="text-xs font-black">{selectedWeatherLocation === 'Saint-Denis' ? '28 km/h' : '6 km/h'}</p>
                  <p className="text-[8px] text-slate-500 uppercase">Wind Gusts</p>
                </div>
                <div className="p-3 bg-slate-900/40 rounded-xl border border-white/5">
                  <CloudRain className="h-4 w-4 text-purple-400 mx-auto mb-1" />
                  <p className="text-xs font-black">{selectedWeatherLocation === 'Saint-Denis' ? '84%' : '12%'}</p>
                  <p className="text-[8px] text-slate-500 uppercase">Rain Factor</p>
                </div>
                <div className="p-3 bg-slate-900/40 rounded-xl border border-white/5">
                  <Sun className="h-4 w-4 text-amber-500 mx-auto mb-1" />
                  <p className="text-xs font-black">{selectedWeatherLocation === 'Saint-Denis' ? 'UV 1' : 'UV 6'}</p>
                  <p className="text-[8px] text-slate-500 uppercase">UV index</p>
                </div>
              </div>

              {/* Custom weather recommendation */}
              <div className={`p-3.5 rounded-xl border text-[10px] space-y-1.5 ${selectedWeatherLocation === 'Saint-Denis' ? 'border-red-500/20 bg-red-500/5 text-red-300' : 'border-emerald-500/20 bg-emerald-500/5 text-emerald-300'}`}>
                <div className="flex items-center space-x-1.5 font-bold uppercase text-[9px]">
                  <AlertTriangle className="h-3 w-3" />
                  <span>Aegis Weather Advisory</span>
                </div>
                <p className="font-semibold text-left">
                  {selectedWeatherLocation === 'Saint-Denis' 
                    ? '⚠️ Torrents flood risk around secondary paths. Avoid open alleys, seek structural concrete cover.' 
                    : '✓ Optimal outdoor travel window. UV rating moderate, standard safety geofence completely green.'}
                </p>
              </div>

            </div>

          </div>

          {/* Column B: Active Safe Routes & Crime Heatmap (4 Columns) */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* 3. SAFE ROUTE SELECTOR */}
            <div className={`p-6 rounded-[24px] border text-left space-y-4 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
              <div className="flex items-center space-x-2.5 text-emerald-400">
                <Navigation className="h-5 w-5 text-emerald-400" />
                <h4 className="font-extrabold text-xs uppercase tracking-wider text-white">Neural Route Planner</h4>
              </div>

              <p className="text-slate-400 text-[10px] leading-relaxed">
                Check active city routes. Safe roads glow in green while risky roads appear in red.
              </p>

              {/* Route switch list */}
              <div className="space-y-3">
                <div 
                  onClick={() => setActiveRouteCheck('louvre')}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer ${activeRouteCheck === 'louvre' ? 'border-emerald-500/50 bg-emerald-500/5' : 'border-white/5 hover:bg-white/5'}`}
                >
                  <div className="flex justify-between items-center text-xs font-black">
                    <span className="text-white">Louvre Sanctuary Route</span>
                    <span className="text-emerald-400 uppercase text-[9px] font-mono">98% Secure</span>
                  </div>
                  <div className="flex items-center space-x-1 text-[8px] text-slate-400 mt-1">
                    <span className="text-emerald-400 font-bold">✓ Green path</span>
                    <span>• 12 active cruisers • Zero pickpocket reports</span>
                  </div>
                </div>

                <div 
                  onClick={() => setActiveRouteCheck('shortcut')}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer ${activeRouteCheck === 'shortcut' ? 'border-red-500/50 bg-red-500/5' : 'border-white/5 hover:bg-white/5'}`}
                >
                  <div className="flex justify-between items-center text-xs font-black">
                    <span className="text-white">Saint-Denis Shortcut</span>
                    <span className="text-red-400 uppercase text-[9px] font-mono">18% Risky</span>
                  </div>
                  <div className="flex items-center space-x-1 text-[8px] text-slate-400 mt-1">
                    <span className="text-red-500 font-bold">⚠ Red Hazards</span>
                    <span>• 1 cruiser • 4 active flood advisories</span>
                  </div>
                </div>
              </div>

              {/* Interactive path route steps list */}
              <div className="p-3 bg-slate-950/40 rounded-xl border border-white/5 space-y-2 text-[10px]">
                <span className="text-[8px] font-mono text-slate-500 uppercase tracking-widest block font-bold">Recommended Nav Steps:</span>
                {activeRouteCheck === 'louvre' ? (
                  <div className="space-y-1.5 text-slate-400 text-left">
                    <p className="font-semibold">🟢 Step 1: Depart Louvre via Rue de Rivoli (Secured)</p>
                    <p className="font-semibold">🟢 Step 2: Merge onto Bd de Sébastopol Blue Corridor</p>
                    <p className="font-semibold">🟢 Step 3: Arrive at Châtelet safe hub sanctuary</p>
                  </div>
                ) : (
                  <div className="space-y-1.5 text-slate-400 text-left">
                    <p className="font-semibold text-red-400">🔴 Warning: Detouring through unpatrolled Sector-4 Alley</p>
                    <p className="font-semibold">🔴 Step 2: Traverse Saint-Denis sewer banks (Flood Risk)</p>
                    <p className="font-semibold">🔴 Warning: Exited geofence protection loop</p>
                  </div>
                )}
              </div>

            </div>

            {/* 4. CRIME PREDICTION HEATMAP INDEX */}
            <div className={`p-6 rounded-[24px] border text-left space-y-4 ${isDark ? 'glass-card' : 'glass-card-light'}`}>
              <div className="flex items-center space-x-2.5 text-purple-400">
                <Activity className="h-5 w-5 text-purple-400" />
                <h4 className="font-extrabold text-xs uppercase tracking-wider text-white">Crime Heuristics Heatmap</h4>
              </div>

              {/* Crime category filter selection */}
              <div className="flex gap-1 p-1 bg-slate-950/40 border border-white/5 rounded-xl text-[9px] font-bold uppercase">
                {(['pickpocket', 'physical', 'scam'] as const).map(f => (
                  <button
                    key={f}
                    onClick={() => setCrimeHeatFilter(f)}
                    className={`flex-1 py-1 rounded-lg cursor-pointer ${crimeHeatFilter === f ? 'bg-purple-600 text-white' : 'text-slate-500'}`}
                  >
                    {f}
                  </button>
                ))}
              </div>

              {/* Heatmap subsectors */}
              <div className="space-y-2 text-xs">
                <div className="flex justify-between items-center p-2.5 bg-slate-900/40 rounded-lg border border-white/5">
                  <span className="font-bold text-white">Champs-Élysées</span>
                  <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold ${crimeHeatFilter === 'pickpocket' ? 'bg-amber-500/15 text-amber-400' : 'bg-emerald-500/15 text-emerald-400'}`}>
                    {crimeHeatFilter === 'pickpocket' ? 'MEDIUM RISK' : 'SECURE'}
                  </span>
                </div>

                <div className="flex justify-between items-center p-2.5 bg-slate-900/40 rounded-lg border border-white/5">
                  <span className="font-bold text-white">Saint-Denis (Sector 4)</span>
                  <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-red-500/15 text-red-400 animate-pulse">
                    CRITICAL WARNING
                  </span>
                </div>

                <div className="flex justify-between items-center p-2.5 bg-slate-900/40 rounded-lg border border-white/5">
                  <span className="font-bold text-white">Latin Quarter</span>
                  <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-500/15 text-emerald-400">
                    EXCELLENT SAFE
                  </span>
                </div>
              </div>

            </div>

          </div>

          {/* Column C: Fully Featured AI Chat Interface (4 Columns) */}
          <div className="lg:col-span-4">
            
            <div className={`p-6 rounded-[24px] border ${isDark ? 'glass-card' : 'glass-card-light'} space-y-4 h-[590px] flex flex-col justify-between`}>
              
              <div className="flex items-center justify-between border-b border-white/5 pb-3">
                <div className="flex items-center space-x-2">
                  <span className="h-2 w-2 bg-emerald-500 rounded-full animate-pulse"></span>
                  <span className="font-black text-xs tracking-wider text-slate-400 uppercase">Aegis Safety Companion</span>
                </div>
                <span className="text-[9px] bg-blue-500/15 text-blue-400 px-2.5 py-0.5 rounded-full font-mono font-bold">AI MODEL V4</span>
              </div>

              {/* Message scroll desk */}
              <div className="flex-1 overflow-y-auto space-y-4 pr-1 my-3 scrollbar-thin max-h-[310px]">
                {chatMessages.map((m, idx) => (
                  <div 
                    key={idx}
                    className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed text-left ${m.sender === 'user' ? 'bg-blue-600 text-white' : isDark ? 'bg-slate-900/80 text-slate-100 border border-white/5' : 'bg-white text-slate-800 border border-slate-900/5'}`}>
                      <p className="font-bold text-[8px] uppercase tracking-wider text-slate-500 mb-1">
                        {m.sender === 'user' ? 'Tourist profile' : 'Aegis Guard'}
                      </p>
                      <p className="whitespace-pre-line">{m.text}</p>
                    </div>
                  </div>
                ))}

                {isTypingAI && (
                  <div className="flex justify-start">
                    <div className="bg-slate-900/40 border border-white/5 rounded-2xl p-4 text-xs text-slate-400">
                      <p className="font-bold text-[8px] uppercase tracking-wider text-slate-500 mb-1">Aegis Guard</p>
                      <div className="flex items-center space-x-1">
                        <span className="h-1.5 w-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                        <span className="h-1.5 w-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                        <span className="h-1.5 w-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Presets query chips */}
              <div className="space-y-1.5 border-t border-white/5 pt-3">
                <p className="text-[8px] font-mono font-bold text-slate-500 uppercase tracking-widest text-left">Preset Tactical Prompts:</p>
                <div className="flex flex-wrap gap-1.5">
                  <button 
                    onClick={() => handleAIChatQuestion('Translate french emergency phrases')}
                    className="px-2.5 py-1 bg-purple-500/10 border border-purple-500/20 rounded-lg text-[9px] text-purple-400 hover:bg-purple-500/25 font-bold transition-all cursor-pointer"
                  >
                     Translate French Help
                  </button>
                  <button 
                    onClick={() => handleAIChatQuestion('Analyze Louvre security grid')}
                    className="px-2.5 py-1 bg-blue-500/10 border border-blue-500/20 rounded-lg text-[9px] text-blue-400 hover:bg-blue-500/25 font-bold transition-all cursor-pointer"
                  >
                     Louvre Security Level
                  </button>
                  <button 
                    onClick={() => handleAIChatQuestion('Where is the nearest SAMU hospital?')}
                    className="px-2.5 py-1 bg-rose-500/10 border border-rose-500/20 rounded-lg text-[9px] text-rose-400 hover:bg-rose-500/25 font-bold transition-all cursor-pointer"
                  >
                     SAMU Hospital Info
                  </button>
                  <button 
                    onClick={() => handleAIChatQuestion('What is my current threat risk score?')}
                    className="px-2.5 py-1 bg-amber-500/10 border border-amber-500/20 rounded-lg text-[9px] text-amber-400 hover:bg-amber-500/25 font-bold transition-all cursor-pointer"
                  >
                     Calculate Risk Heuristics
                  </button>
                </div>
              </div>

              {/* Chat Input form */}
              <form onSubmit={handleCustomChatSubmit} className="flex gap-2">
                <input 
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Query Aegis safety neural net..."
                  className="flex-1 bg-slate-950 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-blue-500"
                />
                <button 
                  type="submit"
                  className="px-3.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl transition-all cursor-pointer flex items-center justify-center shadow-lg"
                >
                  <Send className="h-4 w-4" />
                </button>
              </form>

            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
