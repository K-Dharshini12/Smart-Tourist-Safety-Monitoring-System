import React, { useState } from "react";
import { AppScreen, TouristProfile, SOSBeacon, RescueOperation, RescueStage } from "./types";
import LandingPage from "./components/LandingPage";
import AuthPortal from "./components/AuthPortal";
import TouristIDGenerator from "./components/TouristIDGenerator";
import Dashboard from "./components/Dashboard";
import AdminPanel from "./components/AdminPanel";

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>("landing");
  
  // Tourist Profile State
  const [touristProfile, setTouristProfile] = useState<TouristProfile | null>(null);

  // Fallback demo profile in case of direct access to Dashboard or Admin
  const defaultDemoProfile: TouristProfile = {
    touristId: "AEGIS-49102",
    name: "Elena Rostova",
    nationality: "Switzerland",
    passportNo: "CH-EP9824103",
    email: "elena.r@aegis-shield.com",
    phone: "+41 79 402 1102",
    avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
    verified: true,
    qrCodeData: "AEGIS-ID:CH-EP9824103-ElenaRostova-VERIFIED-2026",
    registrationDate: "July 19, 2026",
  };

  const activeProfile = touristProfile || defaultDemoProfile;

  // Active SOS Beacon state
  const [sosBeacon, setSosBeacon] = useState<SOSBeacon>({
    active: false,
    touristId: null,
    touristName: null,
    lat: null,
    lng: null,
    timestamp: null,
    passportNo: null,
    phone: null
  });

  // Active Rescue dispatch state
  const [rescueOperation, setRescueOperation] = useState<RescueOperation>({
    active: false,
    dispatchId: null,
    dispatchTime: null,
    stages: [],
    currentStageIndex: 0,
    etaSeconds: 260
  });

  // Handle registration success
  const handleRegisterSuccess = (profile: TouristProfile) => {
    setTouristProfile(profile);
    setCurrentScreen("id-generator");
  };

  // Trigger Distress SOS Beacon
  const handleTriggerSOS = async (lat: number, lng: number) => {
    const timestamp = new Date().toLocaleTimeString();
    
    setSosBeacon({
      active: true,
      touristId: activeProfile.touristId,
      touristName: activeProfile.name,
      lat,
      lng,
      timestamp,
      passportNo: activeProfile.passportNo,
      phone: activeProfile.phone
    });

    // Fire actual server API call to generate simulated Rescue Sequence logs
    try {
      const response = await fetch("/api/rescue-dispatch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          touristId: activeProfile.touristId,
          touristName: activeProfile.name,
          lat,
          lng
        })
      });

      const data = await response.json();
      
      // Seed rescue sequence data, but hold actual deployment until Admin authorizes
      if (data.success) {
        setRescueOperation(prev => ({
          ...prev,
          dispatchId: data.dispatchId,
          dispatchTime: data.dispatchTime,
          stages: data.rescueStages,
          currentStageIndex: 0,
          etaSeconds: data.etaSeconds
        }));
      }
    } catch (error) {
      console.error("Rescue setup error", error);
    }
  };

  // Dismiss / Cancel Distress Signal
  const handleCancelSOS = () => {
    setSosBeacon({
      active: false,
      touristId: null,
      touristName: null,
      lat: null,
      lng: null,
      timestamp: null,
      passportNo: null,
      phone: null
    });
    setRescueOperation({
      active: false,
      dispatchId: null,
      dispatchTime: null,
      stages: [],
      currentStageIndex: 0,
      etaSeconds: 260
    });
  };

  // Admin authorizes rescue team dispatch
  const handleDispatchRescue = () => {
    setRescueOperation(prev => ({
      ...prev,
      active: true,
      currentStageIndex: 3 // Set directly to "Rescue Team Deployed" stage for display
    }));

    // Trigger sequential visual stage tick
    const interval = setInterval(() => {
      setRescueOperation(prev => {
        if (!prev.active || prev.currentStageIndex >= prev.stages.length - 1) {
          clearInterval(interval);
          return prev;
        }
        return {
          ...prev,
          currentStageIndex: prev.currentStageIndex + 1
        };
      });
    }, 12000);
  };

  // Stand-down / De-escalate Alarm
  const handleDeescalate = () => {
    handleCancelSOS();
  };

  // Screen Routing Renderer
  const renderScreen = () => {
    switch (currentScreen) {
      case "landing":
        return <LandingPage onNavigate={setCurrentScreen} />;
      case "auth":
        return (
          <AuthPortal
            onNavigate={setCurrentScreen}
            onRegisterSuccess={handleRegisterSuccess}
          />
        );
      case "id-generator":
        return (
          <TouristIDGenerator
            profile={activeProfile}
            onNavigate={setCurrentScreen}
          />
        );
      case "dashboard":
        return (
          <Dashboard
            profile={activeProfile}
            onNavigate={setCurrentScreen}
            sosBeacon={sosBeacon}
            onTriggerSOS={handleTriggerSOS}
            onCancelSOS={handleCancelSOS}
            rescueOperation={rescueOperation}
          />
        );
      case "admin":
        return (
          <AdminPanel
            onNavigate={setCurrentScreen}
            sosBeacon={sosBeacon}
            rescueOperation={rescueOperation}
            onDispatchRescue={handleDispatchRescue}
            onDeescalate={handleDeescalate}
            touristProfile={activeProfile}
          />
        );
      default:
        return <LandingPage onNavigate={setCurrentScreen} />;
    }
  };

  return (
    <div className="min-h-screen bg-white text-gray-100 selection:bg-cyan-600 selection:text-black">
      {renderScreen()}
    </div>
  );
}
